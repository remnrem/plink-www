<?
include("xmltree.php");
$tree = new tree; 
$html = $tree->makeTree("display.xml");

// Print out Tree Html
print $html . "<br>";

// Make a page trail based upon a node name
print "Node trail to Node10:<br>";
for ($i=$tree->nodeCount; $i>=0; $i--) {
	if($tree->node[$i]["NAME"]=="Node10"){
		$trailEND = $tree->node[$i]["treeDepth"];
		$trail[] = $tree->node[$i]["NAME"];
		for($x=$i;$x>=0; $x--){
			if($tree->node[$x]["treeDepth"]<$trailEND){
				$trail[] = $tree->node[$x]["NAME"];
				$trailEND = $tree->node[$i]["treeDepth"]-1;
			}
			$i=$x;
		}
	}
}
$result = array_reverse ($trail);
foreach ($result as $value) {
    echo "$value > ";
}

print "<br><br>XML used: <a href=\"display.xml\">display.xml</a>";

?>
