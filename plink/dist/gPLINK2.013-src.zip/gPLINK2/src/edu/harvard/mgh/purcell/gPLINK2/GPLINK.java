package edu.harvard.mgh.purcell.gPLINK2;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JSplitPane;
import javax.swing.UIManager;

import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

import edu.harvard.mgh.purcell.gCLINE.PopUpMenu;
import edu.harvard.mgh.purcell.gCLINE.StartFrame;
import edu.harvard.mgh.purcell.gCLINE.data.Record;
import edu.harvard.mgh.purcell.gCLINE.pane.FileView;
import edu.harvard.mgh.purcell.gCLINE.pane.FolderView;
import edu.harvard.mgh.purcell.gCLINE.pane.OpView;
import edu.harvard.mgh.purcell.gPLINK2.data.Project;

/**
 * The entry class for gPLINK. Creates a frame from
 * which you can interact with the operations tree,
 * file list, and forms that compose gPLINK.
 * @author Kathe Todd-Brown
 *
 */
@SuppressWarnings("serial")
public final class GPLINK extends StartFrame {
	@Override
	protected void setVersion() {
		version = "2.013"; //never adds --gplink if it's already in
		//...the command line-9.26.07
			//"2.012"; //bug fix adding alternative phenotype - 9.26.07
		//"2.011"; //bug fix selecting remote file names - 9.26.07
		//"2.010"; //fix import so that it quotes filenames - 09.19.07
		//"2.009"; //fixed null pointer exception for
		//...short binary inport in forms (when it was empty) - 09.19.07
		//"2.008"; //file lists now go through a bubble sort
		//...to make sure they are lists alphabetically
		//"2.007";//fixed loading error
		//"2.006"; //can now launch Haploview 
		//...from gPLINK - 08.06.07
		//"2.005"; //add restore from backup option - 08.02.07
		//"2.004";// add time stamps to ops - 8.02.07
		//"2.003"; //added crtl+1/2 for updown on
		//optree - 8.02.07
		//"2.002"; //fixed downloading file and
		//...opening file in alt and default editors
		//"2.001";
	}
	
	/**
	 * Optionally log messages.
	 */
	private static Logger logger = Logger.getLogger(GPLINK.class);
	/**
	 * The current project we are looking at.
	 */
	public Project data;
	
	PlinkMenuBar menu;
	

	/**
	 * Create a windowListener that will properly
	 * close this class.
	 */
	WindowListener properClosing = new WindowListener(){

		public void windowActivated(WindowEvent e) {}
		public void windowClosed(WindowEvent e) {}
		public void windowClosing(WindowEvent e) {
			logger.info("GPLINK is closing (2)");
			if(data != null)
				data.properClosing();
			System.exit(0);
		}
		public void windowDeactivated(WindowEvent e) {}
		public void windowDeiconified(WindowEvent e) {}
		public void windowIconified(WindowEvent e) {}
		public void windowOpened(WindowEvent e) {}
	};
	/**
	 * Re-set the panels of based on given project.
	 * @param d A given Project we want the panels to
	 * reflect.
	 */
	public void layoutPanels(Project d){
		//set the old parameters to null to make
		//...sure that we don't get any memory leaks
		data = null;
		fileViewer = null;
		folderViewer = null;
		opViewer = null;
		
		//reset the data
		data = d;
		fileViewer = new FileView();
		folderViewer = new myFolderView(data);
		opViewer = new myOpView(data, fileViewer);
		//set up the menu bar
		menu = new PlinkMenuBar(this);
		
		//place everything in split panels to get
		//...things organized
		JSplitPane splitPaneHorz = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                opViewer.toJScrollPane(),
				fileViewer);
		JSplitPane splitPaneVert = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
				folderViewer.toJScrollPane(),
				splitPaneHorz);
		//remove everything
		getContentPane().removeAll();
		//add the split pane
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(splitPaneVert, BorderLayout.CENTER);
		getContentPane().add(statusBar, BorderLayout.PAGE_END);
		
		setJMenuBar(menu);
		//pack everything up
		pack();
	}

	
	@Override
	public void layoutPanels() {
		layoutPanels(new Project(this));
	}
	/**
	 * Create a new instance of gPLINK.
	 *
	 */
	public GPLINK(){
		super("gPLINK2");
		
		//deal with the loggers
		//this is configured in the original StartFrame
		//BasicConfigurator.configure();
		Logger.getLogger("com.sshtools").setLevel(Level.OFF);
		Logger gCLINELogger = Logger.getLogger("edu.harvard.mgh.purcell.gCLINE");
		Logger gPLINK2Logger = Logger.getLogger("edu.harvard.mgh.purcell.gPLINK2");
		gCLINELogger.setLevel(Level.OFF);
		gPLINK2Logger.setLevel(Level.OFF);

		//one flag to turn on the log file feature so that we
		//don't have to comment and uncomment stuff
		if(false){
			gCLINELogger.setLevel(Level.INFO);
			gPLINK2Logger.setLevel(Level.INFO);
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MMM-dd-HH-mm-ss");
	        java.util.Date date = new java.util.Date();
	        String logFile = System.getProperty("user.home") + File.separator + dateFormat.format(date)+"gplink.log";
			System.out.println(logFile);
			new File(logFile).delete();
			try {
				gPLINK2Logger.addAppender(new FileAppender(new PatternLayout("%r [%t] %-5p %c - %m%n"), logFile, true));
				gCLINELogger.addAppender(new FileAppender(new PatternLayout("%r [%t] %-5p %c - %m%n"), logFile, true));
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		
		filesInTransit = new Vector<String>();
		
		//add proper closing
		this.addWindowListener(properClosing);
	}	
	
	/**
	 * The main fuction that is where it all starts
	 * @param args
	 */
	public static void main(String[] args) {
		//try to create a system based look a feel
		try {
	        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	    } catch (Exception e) {
	    	System.err.println("Couldn't set \"system\" look and feel.");
	    	try {
				UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
			} catch (Exception e1) {
				System.err.println("Could not set \"cross platform\" look a feel. Going to default.");
			} 
	    }
	    
	    //create gPLINK
		GPLINK mw = new GPLINK();
		//pack everything up
		mw.pack();
		//set it to visible
		mw.setVisible(true);
	}
	
	class myOpView extends OpView{

		public myOpView(Record d, FileView f) {
			super(d, f);

			if(data.update != null){
				
				//Set the icon for leaf nodes.
		        ImageIcon sucessIcon = createImageIcon("images/success.gif");
		        ImageIcon failIcon = createImageIcon("images/fail.gif");
		        ImageIcon runningIcon = createImageIcon("images/running.gif");
		        ImageIcon fileInfoIcon = createImageIcon("images/fileInfoIcon.GIF");
		        //if these all exist then use our renderer
		        if (sucessIcon != null && failIcon != null && runningIcon != null) {
		            myTree.setCellRenderer(
		            		data.update.new MyRenderer(sucessIcon, failIcon, runningIcon, fileInfoIcon));
		        }
			}
		}

		@Override
		protected PopUpMenu createPopUp(StartFrame mf, Record d, String[] givenFiles, String[] givenOp) {
			return new myPopUpMenu(mf, d, givenFiles, givenOp);
		}
		
		/** 
		 * Intelligently create an image URL
		 * @return an ImageIcon, or null if the path was invalid.
		 */
	    public ImageIcon createImageIcon(String path) {
	    	java.net.URL imgURL = GPLINK.class.getResource(path);
	        if (imgURL != null) {
	            return new ImageIcon(imgURL);
	        } else {
	            System.err.println("Couldn't find file: " + path);
	            return null;
	        }
	    }
		
	}
	
	class myFolderView extends FolderView{

		public myFolderView(Record d) {
			super(GPLINK.this, d);
		}

		@Override
		protected PopUpMenu createPopUp(StartFrame mf, Record d, String[] givenFiles, String[] givenOp) {
			return new myPopUpMenu(mf, d, givenFiles, givenOp);
		}
		
	}
	
	class myPopUpMenu extends PopUpMenu{

		public myPopUpMenu(StartFrame mf, Record d, String[] givenFiles, String[] givenOp) {
			super(mf, d, givenFiles, givenOp);
			
			if(GPLINK.this.data.getHaploPath() != null &&
					!GPLINK.this.data.getHaploPath().matches("^\\s*$") &&
					fileNames != null){
				JMenuItem hapOpen = new JMenuItem("Open in Haploview");
				hapOpen.addActionListener(openHaploview());
				
				this.insert(hapOpen, 1);
			}
		}

		@Override
		protected ActionListener createExicute() {
			return new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					new PLINK_Execute(GPLINK.this, data.getOp(opnames[0]).getCline());
				}
			};
		}
		
		private ActionListener openHaploview(){
			return new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					if(fileNames != null){
						if(opnames != null)
							new OpenHapDialog(GPLINK.this, opnames[0], fileNames[0]);
						else
							new OpenHapDialog(GPLINK.this, null, fileNames[0]);
					}
				}
			};
		}
		
	}

	@Override
	public void setBrowseOnly(boolean state) {
		//set the browse
		isBrowseOnly = state;
		//check to see if we need to release a lock
		if(state 
				&& data != null 
				&& data.myLock != null
				&& data.myLock.hasLock()){
			//release the lock
			data.myLock.unlockFile();
		}

		
		if(data != null){
			data.saveConfig();
		}
		
		if(menu != null)
			//shift over the menu
			menu.setEnabledMenu();
		
	}
}
