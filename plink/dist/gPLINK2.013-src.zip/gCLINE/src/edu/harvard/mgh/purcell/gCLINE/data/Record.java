package edu.harvard.mgh.purcell.gCLINE.data;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.swing.JFrame;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.sshtools.common.authentication.KBIRequestHandlerDialog;
import com.sshtools.common.authentication.PasswordAuthenticationDialog;
import com.sshtools.common.hosts.AbstractHostKeyVerification;
import com.sshtools.j2ssh.SshClient;
import com.sshtools.j2ssh.authentication.AuthenticationProtocolException;
import com.sshtools.j2ssh.authentication.AuthenticationProtocolState;
import com.sshtools.j2ssh.authentication.KBIAuthenticationClient;
import com.sshtools.j2ssh.authentication.PasswordAuthenticationClient;
import com.sshtools.j2ssh.transport.InvalidHostFileException;
import com.sshtools.j2ssh.transport.TransportProtocolException;

import edu.harvard.mgh.purcell.gCLINE.StartFrame;
import edu.harvard.mgh.purcell.gCLINE.general.ErrorManager;

/**
 * This class manages the operation annotations.
 * Notes: All files are identified by their full file names.
 * All operation names are unique.
 * @author Kathe Todd-Brown
 *
 */
@SuppressWarnings("serial")
public abstract class Record extends DefaultTreeModel implements KeyWords{
	/**
	 * default editor
	 */
	static public String DEFAULT_EDITOR;
	static{
		String temp = System.getProperty("os.name");
		if(temp.matches(".*[wW]indow.*")){
			//you use window's you poor poor baby
			DEFAULT_EDITOR = "write";
		} else if(temp.matches(".*[mM]ac.*")){
			DEFAULT_EDITOR = "open -a /Applications/TextEdit.app";
		} 	
		else
			DEFAULT_EDITOR = "emacs";
	}
	
	/**
	 * A string that identifies the file extention
	 * for the operation log file. Note that this
	 * can be changed by the user
	 */
	public String OP_LOG_EXT = ".log";
	
	/**
	 * A JFrame that holds the main GUI
	 */
	public StartFrame frame;
	
	/**
	 * Holds the information for the remote connection.
	 * populated from info including: user name,
	 * host name, port number, remote project folder name
	 */
	protected Properties remoteConfig;

	/**
	 * Holds the global configuration data.
	 * Includes: 
	 * Alternative editor
	 */
	protected Properties globalConfig;
	
	/**
	 * Holds the local project configuration data.
	 * Includes: local project folder name, 
	 * home folder name
	 */
	protected Properties localConfig;
	
	public boolean isNew;
	
	/**
	 * A HashMap that carries the global file notes
	 */
	private HashMap<String, String> globalFileNotes;
	
	/**
	 * Locking information for the folder
	 */
	public Lock myLock;
	
	/**
	 * A String that holds the ssh connection.
	 */
	private SshClient conn;
	
	/**
	 * Automatically checks the home directory for
	 * new files and updates the displays.
	 */
	public AutoUpdater update;
	
	/**
	 * Optionally log messages.
	 */
	private static Logger logger = Logger.getLogger(Record.class);
	
	public void setUpdateSec(int sec){
		globalConfig.setProperty(UPDATE_INTERVAL_KEY, new Integer(sec).toString());	
	}
	/**
	 * This is mainly abstract to remind programers to initalize it
	 */
	public abstract void setAutoUpdater(AutoUpdater given);
	
	/**
	 * Set the log extention
	 * @param ext a string discribing the log extention
	 */
	public void setLog(String ext){
		OP_LOG_EXT = ext;
	}
	
	/**
	 * Set the connection data
	 * @param c the actual connection
	 * @param host a string holding the host name
	 * @param port a string holding the port number
	 * @param user a string holding the user name
	 */
	public void setConnData(SshClient c, 
			String host, String port, String user){
		conn = c;
		remoteConfig.setProperty(HOST_KEY, host);
		remoteConfig.setProperty(PORT_KEY, port);
		remoteConfig.setProperty(USER_KEY, user);
		
	}
	
	/**
	 * Set the alternative editor
	 */
	public void setAltEditor(String editor){
		globalConfig.setProperty(USER_EDITOR_KEY, editor);
	}
	
	/**
	 * Add the current project to our list so that we
	 * can launch the recent projects quickly from the
	 * associated menu bar.
	 *
	 */
	public void setLastProject(){
		//get the current name of the local directory
		String localFolderName = getLocalFolder().getAbsolutePath();
		//if the project is already at the top don't do
		//...anything
		if(getP1() != null 
				&& getP1().equals(localFolderName)){
			return;
		//else if it's in the second slot then move it
		//...to the top and more the first down
		} else if(getP2() != null 
				&& getP2().equals(localFolderName)){
			setP2(getP1());
			setP1(localFolderName);
		//if it's in the third slot then move it 
		//...to the top and more the first two down
		} else if(getP3() != null
				&& getP3().equals(localFolderName)){
			setP3(getP2());
			setP2(getP1());
			setP1(localFolderName);
		//otherwise sift everything down and
		//...put it at the top
		}else{
			setP4(getP3());
			setP3(getP2());
			setP2(getP1());
			setP1(localFolderName);
		}
	}
	/**
	 * Set the first project name if it's not equal
	 * to null.
	 * @param name The name of the project
	 */
	public void setP1(String name){
		if(name != null)
			globalConfig.setProperty(P1_KEY, name);
	}
	/**
	 * Set the second project name if it's not equal
	 * to null
	 * @param name The name of the project
	 */
	public void setP2(String name){
		if(name != null)
			globalConfig.setProperty(P2_KEY, name);
	}
	/**
	 * Set the third project name if it's not equal
	 * to null
	 * @param name The name of the project
	 */
	public void setP3(String name){
		if(name != null)
			globalConfig.setProperty(P3_KEY, name);
	}
	/**
	 * Set the forth project name if it's not
	 * equal to null
	 * @param name The name of the project
	 */
	public void setP4(String name){
		if(name != null)
			globalConfig.setProperty(P4_KEY, name);
	}
	private void setSavedBrowse(){
		if(frame.getBrowseOnly())
			globalConfig.setProperty(BROWSE_KEY, "T");
		else
			globalConfig.setProperty(BROWSE_KEY, "F");
	}
	public int getUpdateSec(){
		return new Integer(globalConfig.getProperty(UPDATE_INTERVAL_KEY, "30"));
	}
	
	/**
	 * Get the first project name
	 * @return The first project name, null if it's not
	 * set.
	 */
	public String getP1(){
		return globalConfig.getProperty(P1_KEY, null);
	}
	/**
	 * Get the second project name
	 * @return The second project name, null if it's
	 * not set
	 */
	public String getP2(){
		return globalConfig.getProperty(P2_KEY, null);
	}
	/**
	 * Get the third project name
	 * @return The third project name, null if it's
	 * not set
	 */
	public String getP3(){
		return globalConfig.getProperty(P3_KEY, null);
	}
	/**
	 * Get the forth project name
	 * @return The forth project name, null if it's
	 * not set.
	 */
	public String getP4(){
		return globalConfig.getProperty(P4_KEY, null);
	}
	/**
	 * Get the alternative editor
	 * @return The user defined alternative editor.
	 */
	public String getAltEditor(){
		return globalConfig.getProperty(USER_EDITOR_KEY, null);
	}

	/**
	 * Get the log extention
	 * @return a string that is the log extention
	 */
	public String getStatusExt(){
		return null;
	}
	
	/**
	 * get the connection to the remote directory
	 * @return the connection to the remote directory
	 */
	public SshClient getConn(){
		return conn;
	}
	
	/**
	 * Get the name of the remote file
	 * @return a string that discribes the remote file
	 */
	public String getRemoteFolder(){
		if(remoteConfig == null)
			return null;
		//get the remote folder and default to null
		return remoteConfig.getProperty(REMOTE_FOLDER_KEY, null);
	}
	
	/**
	 * Get the name of the local file
	 * @return a string that discribes the local file
	 */
	public File getLocalFolder(){
		if(localConfig == null)
			return null;
		String localFolder = localConfig.getProperty(LOCAL_FOLDER_KEY, null);
		if(localFolder == null)
			return null;
		else
			return new File(localFolder);
	}
	
	/**
	 * Get the home folder that the data is stored in.
	 * If the project is remote then this is the folder
	 * name on the remote server, otherwise it's
	 * the full name of the local folder.
	 * @return A string that holds the full name of the folder
	 * that holds the data.
	 */
	public String getHomeFolder(){
		if(isRemote())
			return getRemoteFolder();
		else if(getLocalFolder() != null)
			return getLocalFolder().getAbsolutePath();
		else
			return "";
	}
	
	/**
	 * Get a list of files that are in your working directory
	 * @return a vector of the files in your working directory
	 */
	public Vector <String> getHomeFiles(){
		Vector <String> ans = new Vector <String>();
		logger.info("[getHomeFiles()] getting files for");
		if(isRemote()){
			RunCommand getFileList = new RunCommand("ls " + getRemoteFolder(), this);
			getFileList.run();
			ans = getFileList.outputLines;
		}else{
			String [] temp = null;
			if(getLocalFolder() != null)
				temp = getLocalFolder().list();
			
			if(temp == null)
				return ans;
			
			Arrays.sort(temp);
			
			for(String f: temp){
				ans.add(f);
			}
		}
		
		return ans;
	}
	
	/**
	 * Get a specific file note
	 * @param filename A string that is the file name
	 * @return A global discription for this file.
	 */
	public String getGlobalNote(String filename){
		return globalFileNotes.get(filename);
	}
	
	/**
	 * Get a list of all the operations
	 * @return a vector of all the operations information
	 */
	public Vector <OperationInfo> getAllOp(){
		Vector <OperationInfo> ans = new Vector <OperationInfo>();
		DefaultMutableTreeNode root = (DefaultMutableTreeNode)this.getRoot();
		int numOp = root.getChildCount();
		for(int i = 0; i < numOp; i ++){
			ans.add((OperationInfo)root.getChildAt(i));
		}
		return ans;
		
	}
	
	/**
	 * Get the full information on an operation
	 * @param opName A string that is the name of the operation
	 * @return The full operation information
	 */
	public OperationInfo getOp(String opName){
		Vector <OperationInfo> allOperations = getAllOp();
		for(OperationInfo op: allOperations){
			if((op.getName()).equals(opName))
				return op;
		}
		return null;
	}
	/**
	 * Get the what browse option is saved in the global config
	 * file.
	 * @return true if it the browse is configured as true and false
	 * otherwise
	 */
	static public boolean getSavedBrowse(){
		logger.info("[getSavedBrowse()] Entering...");
		Properties config = new Properties();
		File globalFile = new File(GLOBAL_CONFIG);
		//load up any global configurations
		try {
			config.load(new FileInputStream(globalFile));
		} catch (FileNotFoundException e) {
			logger.error("[getSavedBrowse()] File not found exception.");
		} catch (IOException e) {
			logger.error("[getSavedBrowse()] IOException");
		}
		
		String state = config.getProperty(BROWSE_KEY, "F");
		if(state.equals("T")){
			logger.info("[getSavedBrowse()] ...exiting true");
			return true;
		}else if (state.equals("F")){
			logger.info("[getSavedBrowse()] ...exiting false");
			return false;
		}else{
			logger.warn("[getSavedBrowse()] can no read the property, ...exiting false");
			return false;
		}
		
	}
	
	/**
	 * Load the info document from xml file, otherwise
	 * set as default.
	 * @param metaFile the file that holds the xml document
	 * @param homefile the string that is our project root
	 * @return true if data was loaded from a file, false if 
	 * we had to create a empty Record
	 */
	public boolean loadData(File metaFile, String homefile, boolean remote){
		boolean ans = false;
		
		//let the logger know you are running
		logger.info("[loadData(File, String, boolean)] "+ 
			metaFile.getAbsolutePath() + " is being loaded with a " +
			" home file as: " + homefile + " and remote flag: " + remote);
		//set the local project folder
		localConfig.setProperty(LOCAL_FOLDER_KEY, metaFile.getParent());
		//log this as the most recent project
		setLastProject();
		//start create the tree model
		this.setRoot(new DefaultMutableTreeNode(homefile));
		
		//use xml document builders to create a new document from the xml
		//...log file
		Document info;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setIgnoringComments(true);
		DocumentBuilder parser = null;
		try {
			parser = factory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			frame.messanger.createError("Error trying to create a new " +
					"document builder.", "loadData@Record.java");
		}
		
		//check that the log file exists
		if(metaFile.exists() ){
			ans = true;
			try {
				info = parser.parse(metaFile);
			} catch (SAXException e) {
				frame.messanger.createError("Error trying to create project, " +
					"can not parse log file.\n Creating new " +
					"project, please import old operations.\n ",
					"loadData@Record.java");
				metaFile.delete();
				return loadData(metaFile, homefile, remote);
				
			} catch (IOException e) {
				frame.messanger.createError("Error trying to create project, " +
					"IOException.\n Creating new" +
					"project, please import old operations.\n ",
					"loadData@Report.java");
				metaFile.delete();
				return loadData(metaFile, homefile, remote);
				
			}
			//info.getDocumentElement().setAttribute(VS_KEY, version);
		}else{ //file doesn't exist
			ans = false;
			//create a new document
			info = parser.newDocument();
			
			Element root = 
				info.createElement("project");
			root.setAttribute(HOME_KEY, homefile);
			
			//apppend the root to the project
			info.appendChild(root);
			info.getDocumentElement().setAttribute(LOCAL_FOLDER_KEY, metaFile.getParent());
			Element globalDisc = info.createElement(FOLDER_KEY);
			root.appendChild(globalDisc);
		}
		
		if(remote){
			info.getDocumentElement().setAttribute(REMOTE_FOLDER_KEY, homefile);
		} else {
			info.getDocumentElement().removeAttribute(REMOTE_FOLDER_KEY);
		}
		
		//populate the nodes in Record
		populateNodes(info);
		
		logger.info("[loadData(File, String, boolean)] ... exiting");
		return ans;
	}
	
	/**
	 * Populate the operations and global file notes
	 * from a Document.
	 * @param info A document that holds all the global
	 * discriptions and operatoin nodes
	 */
	private void populateNodes(Document info){
		logger.info("[populateNodes(Document)] Entering...");
		localConfig.setProperty(HOME_KEY, info.getDocumentElement().getAttribute(HOME_KEY));
		
		//start at the first child
		Node opIndex = info.getDocumentElement().getFirstChild();
		//go until you are at the last child
		while(opIndex != null){
			if(opIndex.getNodeName().equals(FOLDER_KEY)){
				Node fileIndex = opIndex.getFirstChild();
				while(fileIndex != null){
					if(fileIndex.getNodeName().equals(FILE_KEY)){
						setGlobalFileDisc(
								((Element)fileIndex).getAttribute(NAME_KEY),
								fileIndex.getTextContent());
					}//file if
					fileIndex = fileIndex.getNextSibling();
				}//file while
			}//folder if
			if(opIndex.getNodeName().equals(OP_KEY)){
				String opName = ((Element)opIndex).getAttribute(NAME_KEY);
				String cline = ((Element)opIndex).getAttribute(CLINE_KEY);
				//String opDisc = opIndex.getTextContent();
				String opDisc = "";
				Vector<String[]> infiles = new Vector<String[]>();
				Vector<String[]> outfiles = new Vector<String[]>();
				
				Node fileGroupIndex = opIndex.getFirstChild();
				while(fileGroupIndex!=null){
					if(fileGroupIndex.getNodeType() == Node.TEXT_NODE){
						opDisc = fileGroupIndex.getNodeValue();
					} else {
						Node fileIndex = fileGroupIndex.getFirstChild();
						while(fileIndex != null){
							if(fileGroupIndex.getNodeName().equals(INFILE_KEY)){
								infiles.add(new String [] {((Element)fileIndex).getAttribute(NAME_KEY), 
										fileIndex.getTextContent()});
							}//input files if
							if(fileGroupIndex.getNodeName().equals(OUTFILE_KEY)){
								outfiles.add(new String []{((Element)fileIndex).getAttribute(NAME_KEY),
										fileIndex.getTextContent()});
							}//output files if
							fileIndex = fileIndex.getNextSibling();
						}//file while
					}//end if/else
					fileGroupIndex = fileGroupIndex.getNextSibling();
				}//fileGroup while
				//pull the time stamp for this operation
				String time = ((Element)opIndex).getAttribute(TIMESTAMP_KEY);
				//otherwise pull the time stamp for the log file
				if( time == null || time.matches("^\\s*$")){
					time = OperationInfo.DATEFORMAT.format(new Date(OperationInfo.getLog( getLocalFolder(), 
							OP_LOG_EXT, outfiles).lastModified()));
				}
				addOperation(opName, opDisc, cline, time, infiles, outfiles);
			}//op if
			opIndex = opIndex.getNextSibling();
		}//opIndex while loop
		
		logger.info("[populateNodes(Document)] ...exiting");
	}
	
	/**
	 * Create a Document from the operations and
	 * global file notes that we can then write as
	 * an xml document easily. Returns null if 
	 * unable to create a document.
	 * @return A Document containing all the global file
	 * notes and operation.
	 */
	private Document processNodes(){
		logger.info("[processNodes()] Entering...");
		//get the root of the record so we can go through
		//...the entire thing
		DefaultMutableTreeNode recordRoot = (DefaultMutableTreeNode)this.getRoot();
		//create a document builder so we can call a parser
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		//ignore any comments
		factory.setIgnoringComments(true);
		//Create a parser
		DocumentBuilder parser = null;
		//intialize the parser
		try {
			parser = factory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			logger.error("(processNodes()) Error trying to create a new " +
					"document builder.");
			frame.messanger.createError("Error trying to create a new " +
					"document builder.", "processNodes@Record.java");
			//we failed... return null
			return null;
		}
		//create a new document from the parser
		Document info = parser.newDocument();
		//xml root
		Element root = 
			info.createElement("project");
		//set the attributes of the overall project
		root.setAttribute(HOME_KEY, getHomeFolder());
		if(isRemote())
			root.setAttribute(REMOTE_FOLDER_KEY, getRemoteFolder());
		
		//note all the global discriptions
		Element globalNotes = info.createElement(FOLDER_KEY);
		for(String key: globalFileNotes.keySet()){
			Element fileNote = info.createElement(FILE_KEY);
			fileNote.setAttribute(NAME_KEY, key);
			fileNote.setTextContent(globalFileNotes.get(key));
			globalNotes.appendChild(fileNote);
		}
		root.appendChild(globalNotes);
		
		//note all the operations
		if(!recordRoot.isLeaf()){
			OperationInfo opIndex = (OperationInfo)recordRoot.getFirstChild();
			while(opIndex != null){
				root.appendChild(opIndex.asElement(info));
				opIndex = (OperationInfo)opIndex.getNextSibling();
			}
		}
		//add the root to the document
		info.appendChild(root);
		
		logger.info("[processNodes()] ...exiting");
		//return the document
		return info;
	}
	
	/**
	 * Load the config values from a Properties formated file.
	 *
	 */
	private void loadGlobalConfig(){
		logger.info("[loadGlobalConfig()] Entering...  [" + GLOBAL_CONFIG + "]");
		
		File globalFile = new File(GLOBAL_CONFIG);
		//load up any global configurations
		try {
			globalConfig.load(new FileInputStream(globalFile));
		} catch (FileNotFoundException e) {
			logger.error("(loadGlobalConfig) File not found exception.");
		} catch (IOException e) {
			logger.error("(loadGlobalConfig) IOException");
		}
			
		//local config file set in loadData() and popuateNodes(Document)
		logger.info("[loadGlobalConfig()] ...exiting");
		
	}
	protected abstract void loadRemoteConfig();
	
	protected abstract void saveRemoteConfig();
	/**
	 * Save the config values
	 *
	 */
	public void saveConfig(){
		logger.info("[saveConfig()] Entering...");
		File globalFile = new File(GLOBAL_CONFIG);
		
		setSavedBrowse();
		
		if(isRemote()){
			logger.info("[saveConfig()] data flaged as remote");
			try {
				remoteConfig.store(new FileOutputStream(
						new File(getLocalFolder(), REMOTE_CONFIG_FILE)), "Remote Configuretion");
			} catch (FileNotFoundException e) {
				logger.error("[saveConfig()] FileNotFoundException trying to " +
						"store remote config file.");
				frame.messanger.createError("Can not store remote information. File not found.",
						"saveConfig()@Record.java");
			} catch (IOException e) {
				logger.error("[saveConfig()] IOException trying to " +
						"store remote config file.");
				frame.messanger.createError("Can not store remote information.",
					"saveConfig()@Record.java");
			}
			saveRemoteConfig();
		}else{
			logger.info("(saveConfig) saving global configuration [" + GLOBAL_CONFIG + "]");
			try {
				globalConfig.store(new FileOutputStream(globalFile), "Global configuration for gCLINE");
			} catch (FileNotFoundException e) {
				logger.error("[saveConfig()] FileNotFoundException trying to " +
						"store global config file.");
				frame.messanger.createError("Can not store remote information. File not found.",
						"saveConfig()@Record.java");
			} catch (IOException e) {
				logger.error("[saveConfig()] IOException trying to " +
						"store global config file.");
				frame.messanger.createError("Can not store remote information.",
						"saveConfig()@Record.java");
			}
		}
		
		logger.info("[saveConfig()] ...exiting");
	}
	
	/**
	 * Add an operation to the info document, if there is an operation
	 * of that name then replace it with this new one.
	 * @param opName The operation name.
	 * @param opDisc The discription of the operation.
	 * @param cline The command line that is tied to the operaiton
	 * @param infiles A vector of the names of the input files.
	 * @param outfiles A vector of the names of the output files.
	 * @return a boolean flagging the success of the addition.
	 */
	public boolean addOperation(String opName, String opDisc, 
			String cline, String createTime,
			Vector <String []> infiles,
			Vector <String []> outfiles){
		DefaultMutableTreeNode root = (DefaultMutableTreeNode)this.getRoot();
		//check assumptions
		if(opName == null || opDisc == null || cline == null
				|| infiles == null || outfiles == null )
			return false;
		
		//take out the operation if it is already there
		int index = removeOperation(opName);
		OperationInfo newOp = getOp(opName);
		
		//create a new operation node
		newOp = new OperationInfo(opName, opDisc,
					cline, createTime);
				
		//add the files
		for(String[] file: infiles){
			newOp.addFile(INFILE_KEY, file[0], file[1], globalFileNotes.get(file[0]));
		}
		for(String[] file: outfiles){
			newOp.addFile(OUTFILE_KEY, file[0], file[1], globalFileNotes.get(file[0]));
		}
		
		//logger.info("(addOperation) Added an operation: " + opName);
		
		if(index == -1)
			//add it to the record
			root.add(newOp);
		else
			root.insert(newOp, index);
		
		if(update != null)
			//add it to the updater
			update.addOp(opName);
		reload();
		return true;
	}
	
	/**
	 * Remove an operation from the document.
	 * @param opName the name of the operation we are removing
	 * @return the index that this operation was at, -1 if the 
	 * operation was not found.
	 */
	public int removeOperation(String opName){
		
		OperationInfo oldOp = this.getOp(opName);
		
		DefaultMutableTreeNode root = (DefaultMutableTreeNode)this.getRoot();
		int ans = -1;
		if(oldOp != null){
			ans = root.getIndex(oldOp);
			this.removeNodeFromParent(oldOp);
			//root.remove(oldOp);
		}
		/*if(ans != -1){
			logger.info("Successfuly removed " + opName);
		}else{
			logger.info("Unsuccessfuly removed " + opName);
		}*/
		reload();
		return ans;
	}
	
	/**
	 * Set a global file discriptor
	 * @param fileName a string identifing the file (absolute path name)
	 * @param fileDisc a string for local file discription
	 */
	public void setGlobalFileDisc(String fileName, String fileDisc){
		globalFileNotes.put(fileName, fileDisc);
	}
	
	/**
	 * Is this record tied to a remote directory?
	 * @return true if it is false otherwise
	 */
	public boolean isRemote(){
		String ans = getRemoteFolder();
		logger.info("[isRemote()] the project is remote: "+ ans);
		return(ans != null);
	}
	
	public boolean saveInfo(){
		return saveInfo(new File(getLocalFolder(), META_FILE));
	}
	
	public boolean backupInfo(){
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MMM-dd-HH-mm-ss");
        java.util.Date date = new java.util.Date();
        File outputFile = new File(getLocalFolder(), "backup"+dateFormat.format(date)+".xml");
        return saveInfo(outputFile);
	}
	
	/**
	 * Write the information to the project file of the xml format.
	 * @return true if writing is sucessfull, false otherwise
	 */
	public boolean saveInfo(File metaFile){
		logger.info("(saveInfo(File)) Entering");
		if(frame.getBrowseOnly()){
			logger.warn("[saveInfo(File)] not saving project because we are browse only");
			return false;
		}
		
		if(myLock.availableLock())
			if(myLock.lockFile() == false){
				logger.warn("[saveInfo(File)] unable to lock file(1)");
				return false;
			}
		if(!myLock.hasLock()){
			if(!myLock.stealLock()){
				frame.setBrowseOnly(true);
				logger.warn("[saveInfo(File)] unable to steal the lock");
				return false;
			}
		}
			
		Document info = processNodes();
		if(isRemote()){
			try {
				remoteConfig.store(new FileOutputStream(
						new File(getLocalFolder(), REMOTE_CONFIG_FILE)), "Remote Configuretion");
			} catch (FileNotFoundException e) {
				//e.printStackTrace();
				frame.messanger.createError("Can not store remote information. File not found.",
						"saveInfo@Record.java");
			} catch (IOException e) {
				frame.messanger.createError("Can not store remote information.",
				"saveInfo@Record.java");
			}
		}
		
		// Use a Transformer for output
		TransformerFactory tFactory = TransformerFactory.newInstance();
		Transformer transformer = null;
		
		//configure the transformer
		try {
			transformer = tFactory.newTransformer();
		} catch (TransformerConfigurationException e1) {
			frame.messanger.createError("Error trying to create transformer."
					,"saveInfo@Record.java");
			logger.warn("[saveInfo(File)] error creating transformer, returning false");
			return false;
		}
		//set the source of the data
		DOMSource source = new DOMSource(info);
		//check the flags to see where we should output
		
		//set the recieving stream to the file specified by 
		//...rootfolder/logfile
		StreamResult ofile = null;
		try {
			logger.info("(saveInfo())Write the project info to: " 
				+ metaFile.getAbsolutePath()
				+ "in the file: " + getLocalFolder());
			ofile = new StreamResult(new FileWriter(metaFile));
		} catch (IOException e) {
			frame.messanger.createError("Error trying to create file stream.",
				"saveInfo@Record.java");
			logger.warn("[saveInfo(File)] error creating filestream, returning false");
			return false;
		}
		try {
			transformer.transform(source, ofile);
		} catch (TransformerException e) {
			frame.messanger.createError("Error trying to transform source to" +
			"file stream.", "saveInfo@Record.java");
			logger.warn("[saveInfo(File)] error transforming source to filestream, returning false");
			return false;
		}
		
		if(isRemote()){
			frame.new Upload(this, true, getRemoteFolder(), new File[]{metaFile});
		}
		
		logger.info("[saveInfo(File)] Exiting true");
		return true;
	}
	
	/**
	 * Print the home folder of the record. If the record
	 * is remote then the home folder is the pwd of the
	 * remote folder otherwise it is the full path name
	 * of the local folder.
	 * @return a string that is the path of the home folder
	 */
	@Override
	public String toString(){
		if(isRemote()){
			return getRemoteFolder();
		}
		else return getLocalFolder().getAbsolutePath();
	}
	
	/**
	 * This is a host key validator that automatically accepts any
	 * host key sent but doesn't actually save any of them.
	 * @author Kathe Todd-Brown
	 *
	 */
	private static class myHostKeyValidator extends AbstractHostKeyVerification{
		public myHostKeyValidator() throws InvalidHostFileException {super(null);}
		@Override
		public void onDeniedHost(String host) throws TransportProtocolException {
			new ErrorManager(null).createError("Access to '" + host + "' is denied.\n" +
                    "Verify the access granted/denied in the allowed hosts file.",
                    "onDenialHost(String)@myHostKeyValidator.Record.java");
		}
		@Override
		public void onHostKeyMismatch(String host, String allowedHostKey, 
				String actualHostKey) throws TransportProtocolException {
			allowHost(host, actualHostKey, false);}
		@Override
		public void onUnknownHost(String host, String hostKeyFingerprint) 
		throws TransportProtocolException {
			allowHost(host, hostKeyFingerprint, false);}
	}
	
	public boolean connect(){
		logger.info("[connect()] Entering...");
//		if the connection isn't null
		if(conn != null)
			//be sure that we are disconnected
			conn.disconnect();
		String host = remoteConfig.getProperty(HOST_KEY, "");
		int port = new Integer(remoteConfig.getProperty(PORT_KEY, "22"));
		String user = remoteConfig.getProperty(USER_KEY, "");
		conn = connect(frame.messanger, frame, host, user, port);
		logger.info("[connect()] ...exiting");
		return conn != null;
	}
	
	/**
	 * Connect the ssh client.
	 * @return false if an error that we can cetch happened (not always the case!)
	 * true otherwise.
	 */
	@SuppressWarnings("unchecked")
	static public SshClient connect( ErrorManager em, JFrame frame,
			String host, String user, int port){
		logger.info("[connect(ErrorManager, JFrame, String, String, int)] Entering...");
		//set the connection to something new
		SshClient conn = new SshClient();
		
		////////////
		///Establish connection
		////////////
		try {
			//conn.connect(host,port, new DialogHostKeyVerification(frame, null));
			conn.connect(host,port, new myHostKeyValidator());
		} catch (NumberFormatException e) {
			logger.error("[connect(ErrorManager, JFrame, String, String, int)] " +
					"Can not establish a connection: NumberFormatException");
			em.createError("Error trying to establish connection.",
					"connect():Record.java");
			return null;
		} catch (IOException e) {
			logger.error("([connect(ErrorManager, JFrame, String, String, int)] " +
					"Can not establish a connection: IOException " + e.getMessage() +
					"\n " + (e.getStackTrace()[0]).toString());
			em.createError("Error trying to establish " +
					"ssh connection " +
					"["+ user+"@"+host +":"+ port +"].",
					"connect:Project.java");
			return null;
		}
		
		///////////////
		/////authenticate the connection
		///////////////
		
		//flags if we have a key-board interactive
		boolean kyboardI = false;
		try {
			List <String> options = conn.getAvailableAuthMethods(user);
		
			String allOptions = "";
			for(String name: options){allOptions += " ["+ name + "]";}
			
			logger.info("(connect) We have the following auterization options:"+allOptions);
			//if there is a keyboard interactive option
			kyboardI = options.contains("keyboard-interactive");
		} catch (IOException e2) {
			logger.error("[connect(ErrorManager, JFrame, String, String, int)] " +
					"Can not establish ssh auth methods");
			em.createError("Error trying to establish " +
					"ssh auth methods" +
					"["+ user+"@"+host +":"+ port +"]",
					"connect():Project.java");
			return null;
		}
		
		//by detault we fail the autherization
		int result = AuthenticationProtocolState.FAILED;
		
		//create authenticators and authenticate the connection
		if(kyboardI){
			KBIAuthenticationClient kbi =
				new KBIAuthenticationClient();
			KBIRequestHandlerDialog dialog = 
	              new KBIRequestHandlerDialog(frame);
			kbi.setKBIRequestHandler(dialog);
			kbi.setUsername(user);
			
			//get the result
			try {
				result = conn.authenticate(kbi);
			} catch (IOException e) {
				logger.error("[connect(ErrorManager, JFrame, String, String, int)] " +
						"Can not authenticate " +
						"(keyboard-interative) ssh connection " +
						"["+ user + "@" +host+":"+ port+"]. \n");
				em.createError("Error trying to authenticate " +
						"(keyboard-interative) ssh connection " +
						"["+ user + "@" +host+":"+ port+"].",
						"launchLogin:ProjectDialog.java");
				return null;
			}
		} else {
			PasswordAuthenticationClient pwd = 
				new PasswordAuthenticationClient();
			PasswordAuthenticationDialog dialog =
				new PasswordAuthenticationDialog(frame);
			pwd.setUsername(user);
			
			try {
				pwd.setAuthenticationPrompt(dialog);
			} catch (AuthenticationProtocolException e) {
				logger.error("[connect(ErrorManager, JFrame, String, String, int)] " +
						"Can not set authenticate prompt" +
						"(password)" +
						"["+ user + "@" +host+":"+ port+"]. \n");
				em.createError("Can not set authenticate prompt" +
						"(password) ["+ user + "@" +host+":"+ port+"].",
						"launchLogin:ProjectDialog.java");
				return null;
			}
			try {
				result = conn.authenticate(pwd);
			} catch (IOException e) {
				logger.error("[connect(ErrorManager, JFrame, String, String, int)] " +
						"Can not authenticate " +
						"(password) ssh connection " +
						"["+ user + "@" +host+":"+ port+"]. \n");
				em.createError("Error trying to authenticate " +
						"(password) ssh connection " +
						"["+ user + "@" +host+":"+ port+"].",
						"launchLogin:ProjectDialog.java");
				return null;
			}
		}
		
		/////////////////
		////// Check the results.
		/////////////////
	  
		if(result==AuthenticationProtocolState.FAILED){
			logger.error("[connect(ErrorManager, JFrame, String, String, int)] " +
					"Error failure to " +
					"establish ssh connection"+
					"["+ user + "@" +host +":"+ port+"].");
			em.createError("Error failure to " +
					"establish ssh connection"+
					"["+ user + "@" +host +":"+ port+"].",
					"connect:Project.java");
			return null;
		}
		if(result==AuthenticationProtocolState.PARTIAL){
			logger.error("[connect(ErrorManager, JFrame, String, String, int)] " +
					" Error failure to " +
					"establish full ssh connection"+
					"["+ user + "@" +host +":"+ port+"].");
			em.createError("Error failure to " +
					"establish full ssh connection"+
					"["+ user + "@" +host +":"+ port+"].",
					"connect:Project.java");
		    return null;
		}
		
		if(result==AuthenticationProtocolState.COMPLETE){
			logger.info("[connect(ErrorManager, JFrame, String, String, int)] " +
					"Auth complete!");
			return conn;
		}
		logger.error("[connect(ErrorManager, JFrame, String, String, int)] " +
				"Didn't complete authorization!");
		//we don't know what happened if we get here but we don't like it!
		return null;
	}
	/**
	 * Create a Record with null or empty fields.
	 *
	 */
	public Record(){
		super(new DefaultMutableTreeNode());
		logger.info("[Record()] Entering...");
		frame = null;
		globalConfig = new Properties();
		//frame.messanger = new ErrorManager(null);
		remoteConfig = new Properties();
		localConfig = new Properties();
		globalFileNotes = new HashMap<String, String>();
		myLock = null;
		conn = null;
		update = null;
		loadGlobalConfig();
		logger.info("[Record()] ...exiting");
	}
	/**
	 * Create a Record initalized to a particular StartFrame.
	 * @param f The StartFrame we are attaching this Record to.
	 */
	public Record(StartFrame f){
		this();
		logger.info("[Record(StartFrame)] Entering...");
		frame = f;
		DefaultMutableTreeNode temp = new DefaultMutableTreeNode("");
		this.setRoot(temp);
		this.nodeChanged(temp);
		logger.info("[Record(StartFrame)] ...exiting");
	}
	/**
	 * Create a Record.
	 * @param f The StartFrame w are attaching this Record to.
	 * @param localName A String that is the name of the local 
	 * project folder for this project.
	 */
	public Record(StartFrame f, String localName){
		this(f);
		logger.info("[Record(StartFrame, String)] Entering...");
		frame.messanger = new ErrorManager(frame);
		remoteConfig = new Properties();
		
		localConfig = new Properties();
		
		isNew = loadData(new File(localName + File.separator + META_FILE),
				localName, false);
		
		myLock = new Lock(frame, this);
		if(!frame.getBrowseOnly()){
			if(myLock.availableLock())
				myLock.lockFile();
			else
				frame.setBrowseOnly(!myLock.stealLock());
		}
		logger.info("[Record(StartFrame, String)] ...exiting");
	}
	/**
	 * Create a Record.
	 * @param f The StartFrame w are attaching this Record to.
	 * @param localName A String that is the name of the local 
	 * project folder for this project.
	 * @param remoteFileName A String that is the name of the remote
	 * project folder for this project.
	 * @param hostname A String that is the name of the remote host
	 * @param username A String that is the name of the user on the
	 * remote host.
	 * @param portnum A String that is the port number we wish to
	 * connect to.
	 * @param c A SshClient that is used to connect to the remote
	 * host.
	 */
	public Record(StartFrame f, String localName, 
			String remoteFileName, String hostname,
			String username, String portnum,
			SshClient c){
		this(f);
		logger.info("[Record(StartFrame, String, String, String, " +
				"String , String, SshClient)] Entering...");
		conn = c;
		frame.messanger = new ErrorManager(frame);
		
		logger.info("[Record(StartFrame, String, String, String, " +
		"String , String, SshClient)] set properties");
		
		remoteConfig.setProperty(REMOTE_FOLDER_KEY, remoteFileName);
		remoteConfig.setProperty(HOST_KEY, hostname);
		remoteConfig.setProperty(USER_KEY, username);
		remoteConfig.setProperty(PORT_KEY, portnum);
		try {
			remoteConfig.store(new FileOutputStream(
					new File(getLocalFolder(), REMOTE_CONFIG_FILE)), "Remote Configuretion");
		} catch (FileNotFoundException e) {
			//e.printStackTrace();
			frame.messanger.createError("Can not store remote information. File not found.",
					"saveInfo@Record.java");
		} catch (IOException e) {
			frame.messanger.createError("Can not store remote information.",
			"saveInfo@Record.java");
		}
		
		localConfig.setProperty(LOCAL_FOLDER_KEY, localName);
		
		logger.info("[Record(StartFrame, String, String, String, " +
		"String , String, SshClient)] download and load metafile");
		
		new File(getLocalFolder(),META_FILE ).delete();
		
		frame.new Download(this, false, getLocalFolder(), new String [] {remoteFileName + "/" + META_FILE});
		
		isNew = loadData(new File(localName + File.separator + META_FILE),
				remoteFileName, true);
		
		logger.info("[Record(StartFrame, String, String, String, " +
			"String , String, SshClient)] locking");
		
		myLock = new Lock(frame, this);
		if(myLock.availableLock())
			myLock.lockFile();

		logger.info("[Record(StartFrame, String, String, String, " +
		"String , String, SshClient)] calling loadRemoteConfig()");
		
		loadRemoteConfig();
		
		logger.info("[Record(StartFrame, String, String, String, " +
		"String , String, SshClient)] ...exiting");
	}
	
	/**
	 * Close the Record up properly. Set everything to null.
	 *
	 */
	public void properClosing(){
		logger.info("[properClosing()] Entering...");
		saveConfig();
		if(update != null){
			update.cancel();
			update = null;
		}
		if(myLock != null && myLock.hasLock()){
			saveInfo();
			myLock.unlockFile();
			myLock = null;
		}
		if(conn != null)
			conn.disconnect();
		
		remoteConfig = null;
		globalConfig = null;
		localConfig = null;
		this.setRoot(null);
		logger.info("[properClosing()] ...exiting");
		
	}	
}
