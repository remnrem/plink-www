package edu.harvard.mgh.purcell.gCLINE.data;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Vector;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * A class that contains the information for a given
 * operation.
 * <p>This includes 1) a unique name 2) assocated command
 * line 3) a discription 4) input files 5) output files.
 * @author Kathe Todd-Brown
 *
 */
@SuppressWarnings("serial")
public class OperationInfo extends DefaultMutableTreeNode
							implements KeyWords{
	public static String INPUT_LABEL = "Input files";
	public static String OUTPUT_LABEL = "Output files";
	/**
	 * A String that uniquely identifies the operation.
	 */
	private String name;
	/**
	 * A String that discribes the operation.
	 */
	private String discription;
	/**
	 * A String that holds the command line for this 
	 * operation.
	 */
	private String cline;
	/**
	 * A DefaultMutableTreeName that holds the input files.
	 */
	private DefaultMutableTreeNode input;
	/**
	 * A DefaultMutableTreeNode that holds the output files.
	 */
	private DefaultMutableTreeNode output;
	
	private String timestamp;
	
	static public DateFormat DATEFORMAT = new SimpleDateFormat("yyyy-MMM-dd HH:mm");
    
	private DefaultTreeModel parentTree;
	
	/**
	 * Get the unique name of the operation.
	 * @return A String that is the operation's name.
	 */
	public String getName(){
		return name;
	}
	
	public String getDisc(){
		return discription;
	}
	
	public String getCline(){
		return cline;
	}
	
	public Vector<FileInfo> getInputFiles(){
		Vector <FileInfo> ans = new Vector<FileInfo>();
		
		if(input.isLeaf())
			return ans;
		
		FileInfo f = (FileInfo) input.getFirstChild();
		
		while(f != null){
			ans.add(f);
			f = (FileInfo)f.getNextSibling();
		}
		
		return ans;
	}
	
	public Vector<FileInfo> getOutputFiles(){
		Vector <FileInfo> ans = new Vector<FileInfo>();
		
		if(output.isLeaf())
			return ans;
		
		FileInfo f = (FileInfo) output.getFirstChild();
		
		while(f != null){
			ans.add(f);
			f = (FileInfo) f.getNextSibling();
		}
		
		return ans;
	}
	

	/**
	 * Get the log file associated with this operation
	 * @param localFolder A file reflecting the local 
	 * reference for this project
	 * @param suffix A String that is the log suffix (example: .log)
	 * @return A File that is the local log file, null if none found
	 */
	public File getLog(File localFolder, String suffix){
		Vector <FileInfo> allOutput = getOutputFiles();
		for(FileInfo f : allOutput){
			if(f.toString().endsWith(suffix))
				return new File(localFolder, f.toString());
		}
		return null;
	}
	
	static File getLog(File localFolder, 
			String suffix, Vector <String[]> outfiles){
		for(String [] f : outfiles){
			if(f[0].endsWith(suffix))
				return new File(localFolder, f.toString());
		}
		return null;
	}
	
	public String getTimeStamp(){
		return timestamp;
	}
	
	/**
	 * Removes a file from the operation. Note that this
	 * removes all instances of this file.
	 * @param filename A Stirng that is the file name we wish
	 * to remove from this operation.
	 */
	public void removeFile(String filename){
		//take it out of the input node
		FileInfo f = (FileInfo) input.getFirstChild();
		//go through all the files of the input node
		while(f != null){
			//check the file
			if(filename.equals(f.toString())){
					//remove the node
					f.removeFromParent();
					//notify the tree that the node
					//...has changed
					if(parentTree != null)
						parentTree.nodeStructureChanged(input);
			}
			//check the rest of the files
			f = (FileInfo)f.getNextSibling();
		}
		
		//take it out of the output note
		f = (FileInfo) output.getFirstChild();
		
		while(f != null){
			if(filename.equals(f.toString())){
				f.removeFromParent();
				if(parentTree != null)
					parentTree.nodeStructureChanged(output);
		
			}
			f = (FileInfo)f.getNextSibling();
		}
		
		
		
	}
	
	/**
	 * Add a file to one of the file nodes.
	 * @param type A String flag from KeyWords that flags
	 * this file as either an input or an output.
	 * @param given_name A String that holds the file name.
	 * @param localDisc A String that is the discription
	 * for this file local to this operation.
	 * @param globalDisc A String that is the discription
	 * for this file globally.
	 */
	public void addFile(String type, String given_name, 
			String localDisc, String globalDisc){
		
		//check the conditions
		if(globalDisc == null)
			globalDisc = "";
		if(localDisc == null)
			localDisc = "";
		if(given_name == null)
			return;
		
		//add the file to the appropreate node
		if(type.equals(INFILE_KEY)){
			addFileToFolder(input, new FileInfo(given_name, localDisc, globalDisc));
		}
		if(type.equals(OUTFILE_KEY)){
			addFileToFolder(output, new FileInfo(given_name, localDisc, globalDisc));
		}
	}
	
	/**
	 * Add a file to a given folder.
	 * @param folder A DefaultMutableTreeNode that represents either then input
	 * or output folder for this operation.
	 * @param givenFile A FileInfo that is the file we wish to add to the given
	 * folder.
	 */
	private void addFileToFolder(DefaultMutableTreeNode folder, FileInfo givenFile){
		//check that there are files in this folder
		if(!folder.isLeaf()){
			FileInfo index = (FileInfo) folder.getFirstChild();
			//look through all the files
			while(index != null){
				//if it's already there
				if((index.toString()).equals(givenFile.toString())){
					//FileInfo temp = (FileInfo)index.getPreviousSibling();
					//remove the old file	
					index.removeFromParent();
					//index = temp;
				}
				//move on to the next index
				index = (FileInfo) index.getNextSibling();
			}
		}
		//add it to the folder
		folder.add(givenFile);
		if(parentTree != null)
			parentTree.nodeStructureChanged(folder);
	}
	
	/**
	 * Get the name and discription of this
	 * operation.
	 * @return A String that is the name and discription
	 * of this operation seperated by ":".
	 */
	@Override
	public String toString(){
		return name + ": ("+ timestamp + ") " + discription;
	}
	
	/**
	 * Get the details of the operation 
	 * like the command line.
	 * @return a vector contianing the deals of the 
	 * operation
	 */
	public Vector <String> getOpDetails(){
		Vector <String> ans = new Vector <String> ();
		ans.add(cline);
		return ans;
	}
	
	/**
	 * Print out the operation to a string.
	 * @return The entire operation as a flat string.
	 */
	public String printfull(){
		String ans = this.toString() + " \n";
		
		Vector <String> details = getOpDetails();
		for(String d: details){
			ans = ans + d + " \n";
		}
		
		ans = ans + "Input Files:\n" ;
		FileInfo fileIndex = (FileInfo)input.getFirstChild();
		while(fileIndex != null){
			ans = ans + fileIndex.toString() + "\n";
			fileIndex = (FileInfo)fileIndex.getNextSibling();
		}//end input while
		
		
		ans = ans + "Output Files:\n";
		fileIndex = (FileInfo)output.getFirstChild();
		while(fileIndex != null){
			ans = ans + fileIndex.toString() + "\n";
			fileIndex = (FileInfo) fileIndex.getNextSibling();
		}//end output while
		return ans;
	}
	
	public Element asElement(Document d){
		Element op = d.createElement(OP_KEY);
		op.setAttribute(NAME_KEY, name);
		op.setAttribute(CLINE_KEY, cline);
		op.setAttribute(TIMESTAMP_KEY, timestamp);
		
		op.appendChild(d.createTextNode(discription));
		
		Element ins = d.createElement(INFILE_KEY);
		Element outs = d.createElement(OUTFILE_KEY);
		
		FileInfo fileIndex;
		if(!input.isLeaf()){
			fileIndex = (FileInfo)input.getFirstChild();
			while(fileIndex != null){
				ins.appendChild(fileIndex.asElement(d));
				fileIndex = (FileInfo)fileIndex.getNextSibling();
			}//end input while
		}
		if(!output.isLeaf()){
			fileIndex = (FileInfo)output.getFirstChild();
			while(fileIndex != null){
				outs.appendChild(fileIndex.asElement(d));
				fileIndex = (FileInfo) fileIndex.getNextSibling();
			}//end output while
		}
		op.appendChild(ins);
		op.appendChild(outs);
		return op;
	}
	public OperationInfo (DefaultTreeModel parentTree){
		this("","","", null, parentTree);		
	}
	
	public OperationInfo (String givenName, 
			String givenDisc, String command,
			String time, DefaultTreeModel givenParentTree){
		super(givenParentTree, true);
		parentTree = givenParentTree;
		name = givenName;
		discription = givenDisc;
		cline = command;
		add(new DefaultMutableTreeNode(cline));
		input = new DefaultMutableTreeNode(INPUT_LABEL);
		add(input);
		output = new DefaultMutableTreeNode(OUTPUT_LABEL);
		add(output);
		if(time == null){
			java.util.Date date = new java.util.Date();
	        timestamp = DATEFORMAT.format(date);
		} else
			timestamp = time;
	}
}
