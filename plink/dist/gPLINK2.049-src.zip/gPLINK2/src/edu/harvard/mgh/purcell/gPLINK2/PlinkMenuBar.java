package edu.harvard.mgh.purcell.gPLINK2;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import javax.swing.Box;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import org.apache.log4j.Logger;

import edu.harvard.mgh.purcell.gCLINE.RestoreDataDialog;
import edu.harvard.mgh.purcell.gPLINK2.data.Project;
import edu.harvard.mgh.purcell.gPLINK2.forms.AlleleAssoc;
import edu.harvard.mgh.purcell.gPLINK2.forms.AlleleFreq;
import edu.harvard.mgh.purcell.gPLINK2.forms.Basic;
import edu.harvard.mgh.purcell.gPLINK2.forms.CCAssoc;
import edu.harvard.mgh.purcell.gPLINK2.forms.Clustering;
import edu.harvard.mgh.purcell.gPLINK2.forms.CondHaploAssoc;
import edu.harvard.mgh.purcell.gPLINK2.forms.FamAssoc;
import edu.harvard.mgh.purcell.gPLINK2.forms.GenFileSet;
import edu.harvard.mgh.purcell.gPLINK2.forms.HapCCAssoc;
import edu.harvard.mgh.purcell.gPLINK2.forms.HapTDTAssoc;
import edu.harvard.mgh.purcell.gPLINK2.forms.HaploFreq;
import edu.harvard.mgh.purcell.gPLINK2.forms.HaploPhase;
import edu.harvard.mgh.purcell.gPLINK2.forms.HardyWinEq;
import edu.harvard.mgh.purcell.gPLINK2.forms.HomozRuns;
import edu.harvard.mgh.purcell.gPLINK2.forms.IBSdist;
import edu.harvard.mgh.purcell.gPLINK2.forms.IndHetz;
import edu.harvard.mgh.purcell.gPLINK2.forms.MendelErr;
import edu.harvard.mgh.purcell.gPLINK2.forms.Merge;
import edu.harvard.mgh.purcell.gPLINK2.forms.Missing;
import edu.harvard.mgh.purcell.gPLINK2.forms.NearNeigh;
import edu.harvard.mgh.purcell.gPLINK2.forms.ProxyAssoc;
import edu.harvard.mgh.purcell.gPLINK2.forms.QuantTrtInt;
import edu.harvard.mgh.purcell.gPLINK2.forms.Regression;
import edu.harvard.mgh.purcell.gPLINK2.forms.SetAssoc;
import edu.harvard.mgh.purcell.gPLINK2.forms.StratAnaly;
import edu.harvard.mgh.purcell.gPLINK2.forms.Validate;

/**
 * A Menu Bar that is specific to PLINK.
 * @author Kathe Todd-Brown
 *
 */
@SuppressWarnings("serial")
public class PlinkMenuBar extends JMenuBar{
	/**
	 * A logger for this class
	 */
	private Logger logger = Logger.getLogger(PlinkMenuBar.class);
	
	/**
	 * A Project that we are going to pass
	 * ...to the form dialogs.
	 */
	private Project data;
	/**
	 * A GPLINK that this menu bar is attached to.
	 */
	private GPLINK frame;
	
	//These are needed as class variables because
	//...we access them from within on the fly action
	//...listeners.
	/**
	 * A String holding the most recent project that
	 * have been opened.
	 */
	private String project1;
	/**
	 * A String holding the second most recent project that
	 * have been opened.
	 */
	private String project2;
	/**
	 * A String holding the third most recent project that
	 * have been opened.
	 */
	private String project3;
	/**
	 * A String holding the forth most recent project that
	 * have been opened.
	 */
	private String project4;
	
	private JMenu plink;
	private JMenu advplink;
	private JMenuItem config;
	private JMenuItem save;
	private JMenuItem backup;
	private JMenuItem restore;
	
	void setEnabledMenu(){
		boolean state = data != null
						&& data.getLocalFolder() != null
						&& frame.getBrowseOnly() == false;
		logger.info("[setEnabledMenu()] setting the items: " + state);
		plink.setEnabled(state);
		advplink.setEnabled(state);
		config.setEnabled(state);
		save.setEnabled(state);
		backup.setEnabled(state);
		restore.setEnabled(state);
	}
	
	/**
	 * Create the menu for command specific forms.
	 * @return A JMenu that has the command specific forms.
	 */
	private JMenu createFormsMenu(){
		plink = new JMenu("PLINK");
		
		JMenu dataMang = new JMenu("Data Management");
		plink.add(dataMang);
		
		JMenuItem filesets = new JMenuItem(GenFileSet.name);
		filesets.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new GenFileSet(frame);
			}
		});
		dataMang.add(filesets);
		
		JMenuItem merge = new JMenuItem(Merge.name);
		merge.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new Merge(frame);
			}
		});
		dataMang.add(merge);
		
		JMenu summery = new JMenu("Summary Statistics");
		plink.add(summery);
		
		
		JMenuItem validate = new JMenuItem(Validate.name);
		validate.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new Validate(frame);
			}
		});
		summery.add(validate);
		
		JMenuItem miss = new JMenuItem(Missing.name);
		miss.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new Missing(frame);
			}
		});
		summery.add(miss);
		
		JMenuItem hwe = new JMenuItem(HardyWinEq.name);
		hwe.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new HardyWinEq(frame);
			}
		});
		summery.add(hwe);
		
		JMenuItem mendel = new JMenuItem(MendelErr.name);
		mendel.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new MendelErr(frame);
			}
		});
		summery.add(mendel);
		
		JMenuItem alleleFreq = new JMenuItem(AlleleFreq.name);
		alleleFreq.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new AlleleFreq(frame);
			}
		});
		summery.add(alleleFreq);
		
		JMenuItem hapFreq = new JMenuItem(HaploFreq.name);
		hapFreq.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new HaploFreq(frame);
			}
		});
		summery.add(hapFreq);
		
		JMenuItem hapPhase = new JMenuItem(HaploPhase.name);
		hapPhase.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new HaploPhase(frame);
			}
		});
		summery.add(hapPhase);
		
		JMenu strat = new JMenu("Stratification");
		plink.add(strat);
		
		JMenuItem ibs = new JMenuItem(IBSdist.name);
		ibs.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new IBSdist(frame);
			}
		});
		strat.add(ibs);
		
		JMenuItem clust = new JMenuItem(Clustering.name);
		clust.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new Clustering(frame);
			}
		});
		strat.add(clust);
		
		JMenuItem neigh = new JMenuItem(NearNeigh.name);
		neigh.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new NearNeigh(frame);
			}
		});
		strat.add(neigh);
		
		JMenu assoc = new JMenu("Association");
		plink.add(assoc);
		
		JMenuItem alleleA = new JMenuItem(AlleleAssoc.name);
		alleleA.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new AlleleAssoc(frame);
			}
		});
		assoc.add(alleleA);
		
		JMenuItem caseControl =  new JMenuItem(CCAssoc.name);
		caseControl.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new CCAssoc(frame);
			}
		});
		assoc.add(caseControl);
		
		JMenuItem famAssoc = new JMenuItem(FamAssoc.name);
		famAssoc.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new FamAssoc(frame);
			}
		});
		assoc.add(famAssoc);

		JMenuItem stratAnaly = new JMenuItem(StratAnaly.name);
		stratAnaly.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				new StratAnaly(frame);
			}
		});
		assoc.add(stratAnaly);

		JMenuItem qti = new JMenuItem(QuantTrtInt.name);
		qti.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new QuantTrtInt(frame);
			}
		});
		assoc.add(qti);

		JMenuItem regress = new JMenuItem(Regression.name);
		regress.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new Regression(frame);
			}
		});
		assoc.add(regress);
		
		JMenuItem setAssoc = new JMenuItem(SetAssoc.name);
		setAssoc.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new SetAssoc(frame);
			}
		});
		assoc.add(setAssoc);
		
		JMenuItem haplotypeCC = new JMenuItem(HapCCAssoc.name);
		haplotypeCC.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new HapCCAssoc(frame);
			}
		});
		assoc.add(haplotypeCC);
		
		JMenuItem haplotypeTDT = new JMenuItem(HapTDTAssoc.name);
		haplotypeTDT.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new HapTDTAssoc(frame);
			}
		});
		assoc.add(haplotypeTDT);
		
		JMenuItem condHap = new JMenuItem(CondHaploAssoc.name);
		condHap.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new CondHaploAssoc(frame);
			}
		});
		assoc.add(condHap);
		
		JMenuItem proxy = new JMenuItem(ProxyAssoc.name);
		proxy.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new ProxyAssoc(frame);
			}
		});
		assoc.add(proxy);
		
		JMenu ibdEst = new JMenu("IBD Estimation");
		plink.add(ibdEst);

		JMenuItem hetz = new JMenuItem(IndHetz.name);
		hetz.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new IndHetz(frame);
			}
		});
		ibdEst.add(hetz);
		
		JMenuItem homoz = new JMenuItem(HomozRuns.name);
		homoz.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent e) {
				new HomozRuns(frame);
			}
			
		});
		ibdEst.add(homoz);
		
		
		
		return plink;
	}
	
	/**
	 * Open up a project with the appropreate remote configurations.
	 * @param folder A String that is the name of the local project
	 * folder.
	 */
	
	private void launchOldProject(String folder){
		File remoteConfig = new File(folder, Project.REMOTE_CONFIG_FILE);
		if(remoteConfig.exists()){
			Properties remote = new Properties();
			try {
				remote.load(new FileInputStream(remoteConfig));
			} catch (FileNotFoundException e1) {
				logger.error("[launchOldProject()] FileNotFoundException " +
						"occured when trying to load remote config file");
			} catch (IOException e1) {
				logger.error("[launchOldProject()] IOException " +
					"occured when trying to load remote config file");
			}
			String remoteName = remote.getProperty(Project.REMOTE_FOLDER_KEY);
			String host = remote.getProperty(Project.HOST_KEY);
			String user = remote.getProperty(Project.USER_KEY);
			String port = remote.getProperty(Project.PORT_KEY);
			if(remoteName != null 
					&& host != null 
					&& user != null 
					&& port != null){
				new PLINK_Open(frame, folder, remoteName, host, user, port);
			} else{
				new PLINK_Open(frame, folder);
			}
		}else
			new PLINK_Open(frame, folder);
	}
	
	/**
	 * Create the menu for general project operatoins.
	 * This includes: Open, Save, Export, Rescan, Configure,
	 * previous projects and Exit.
	 * @return JMenu that holds the general options.
	 */
	private JMenu createProjectMenu(){
		logger.info("[creatingProjectMenu()] Entering");
		JMenu ans = new JMenu("Project");
		
		//open a project file, save this as "folderName.gCLINE"
		JMenuItem open = new JMenuItem("Open");
		open.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				logger.info("open is clicked!");
				new PLINK_Open(frame);
			}
		});
		
		
		
		//save the project file
		save = new JMenuItem("Save");
		save.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if(!data.saveInfo()){
					logger.info("save is clicked!");
					frame.messanger.createError(
							"Can not save information.", "createProjectMenu");
				}
			}
		});
		
		//backup the project to xml
		backup = new JMenuItem("Save As XML");
		backup.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if(!data.backupInfo()){
					logger.info("[createProjectMenu()] Can no create backup file");
					frame.messanger.createError(
							"Can not backup information.", "createProjectMenu");
				}
			}
		});
		
		restore = new JMenuItem("Restore from XML");
		restore.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new RestoreDataDialog(frame, data);
			}
		});
		
		//export the project to text
		
		//open the configureation dialog
		config = new JMenuItem("Configure");
		config.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				logger.info("config is clicked!");
				new PLINK_Config(frame).makeVisible();
			}
		});
		
		//add these to the menu
		ans.add(open);
		//ans.add(browse);
		ans.addSeparator();
		ans.add(save);
		ans.add(backup);
		ans.add(restore);
		ans.addSeparator();
		ans.add(config);
		if(data != null){
			project1 = data.getP1();
			if(project1 != null && !project1.matches("^\\s*$")){
				ans.addSeparator();
				JMenuItem firstProject = new JMenuItem(project1);
				logger.info("adding " + project1);
				firstProject.addActionListener(new ActionListener(){
					
					public void actionPerformed(ActionEvent e) {
						logger.info(project1 + 
								" is firing opening dialog Param:" 
								+ e.paramString() 
								+" ID:"
								+ e.getID()
								);
						launchOldProject(project1);
					}
				});
				ans.add(firstProject);
			}
			
			project2 = data.getP2();
			if(project2 != null&& !project2.matches("^\\s*$")){
				JMenuItem secondProject = new JMenuItem(project2);
				secondProject.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e) {
						logger.info(project2+ " is firing opening dialog");
						launchOldProject(project2);
					}
				});
				ans.add(secondProject);
			}
			
			project3 = data.getP3();
			if(project3 != null && !project3.matches("^\\s*$")){
				JMenuItem thirdProject = new JMenuItem(project3);
				thirdProject.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e) {
						logger.info(project3 + " is firing opening dialog");
						launchOldProject(project3);
					}
				});
				ans.add(thirdProject);
			}
			
			project4 = data.getP4();
			if(project4 != null && !project4.matches("^\\s*$")){
				JMenuItem forthProject = new JMenuItem(project4);
				forthProject.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e) {
						logger.info(project4 + " is firing opening dialog");
						launchOldProject(project4);
					}
				});
				ans.add(forthProject);
			}
		}
		//add an exit
		JMenuItem exit = new JMenuItem("Exit");
		exit.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				logger.info("GPLINK is closing (1)");
				if(data != null)
					data.properClosing();
				System.exit(0);
			}});
		ans.addSeparator();
		ans.add(exit);
		
		return ans;
		
	}
	
	private JMenu createAdvMenu(){
		advplink = new JMenu("Advanced");
		
		JMenuItem importOp = new JMenuItem("Import PLINK operation");
		importOp.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new PLINK_Import(frame, data);
			}
		});
		advplink.add(importOp);
		
		JMenuItem basicCLine = new JMenuItem("Create PLINK command");
		basicCLine.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new Basic(frame);
			}
		});
		advplink.add(basicCLine);
		
		JMenuItem inputNonPlink = new JMenuItem("Add non-PLINK command");
		inputNonPlink.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new AddGenericOp(frame);
			}
		});
		advplink.add(inputNonPlink);
		
		return advplink;
	}
	
	/**
	 * Create an instance of this plink specific menu
	 * bar.
	 * @param givenFrame The gPLINK instance that this
	 * is attached to.
	 */
	public PlinkMenuBar(GPLINK givenFrame){
		super();
		logger.info("[PlinkMenuBar(GPLINK)] Entering...");
		//inialize most of the fields
		this.data = givenFrame.data;
		frame = givenFrame;

		//layout the menu bar
		add(createProjectMenu());
		add(createFormsMenu());
		add(createAdvMenu());
		setEnabledMenu();
		add(Box.createHorizontalGlue());
		
		JMenuItem about = new JMenuItem("About");
		about.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent e) {
				frame.messanger.createMessage(
						"gPLINK vs" + frame.version +
						"\n Released under GNU GPLv2\n" +
						" Writen by: Kathe Todd-Brown, Shaun Purcell\n" +
						"http://pngu.mgh.harvard.edu/~purcell/plink/", "");
			}
		});
		about.setMaximumSize(new Dimension(
				about.getPreferredSize().width, about.getMaximumSize().height));
		
		add(about);
		

		logger.info("[PlinkMenuBar(GPLINK)] ...exiting");
	}
	
}
