package edu.harvard.mgh.purcell.gPLINK2;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.log4j.Logger;

import edu.harvard.mgh.purcell.gCLINE.data.FileInfo;
import edu.harvard.mgh.purcell.gCLINE.data.RunCommand;

/**
 * Create a dialog that will pass the plink
 * command to either a local or remote computer
 * depending on weather the project is flagged as
 * remote or local.
 * @author Kathe Todd-Brown
 *
 */
@SuppressWarnings("serial")
public class PLINK_Execute extends JDialog {
	/**
	 * Optionally log messages.
	 */
	private static Logger logger = Logger.getLogger(PLINK_Execute.class);
	/**
	 * A JTextField that holds the command we
	 * wish to pass to the computer.
	 */
	private JTextField command;
	/**
	 * A JTextField that holds the discription
	 * of the operation.
	 */
	private JTextField discription;
	/**
	 * The GPLINK instance we want to store the
	 * operation in.
	 */
	private GPLINK frame;
	/**
	 * Create an instance of this dialog.
	 * @param givenFrame A GPLINK instance we want
	 * to store the operation in
	 * @param cmd A String that is the command, note that
	 * filenames with spaces must be quoted [\"\"]
	 */
	public PLINK_Execute(GPLINK givenFrame, String cmd){
		super(givenFrame,"Execute Command");
		//Check that there is a flag on the end of the
		//...command. If it isn't there then put it on.
		if(!cmd.matches(".*\\-\\-gplink.*")){
			logger.info("[PLINK_Execute(GPLINK,String)] adding \"--gplink\" to the end");
			cmd += " --gplink";
		}
		//initialize the fields
		frame = givenFrame;
		command = new JTextField(80);
		command.setText(cmd);
		discription = new JTextField(30);
		getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 0;
		getContentPane().add(new JLabel("PLINK command:"), c);
		c.gridx = 1;
		c.weightx = 1;
		getContentPane().add(command, c);
		c.gridy = 1;
		c.gridx = 0;
		c.weightx = 0;
		getContentPane().add(new JLabel("Command description"), c);
		c.gridx = 1;
		c.weightx = 1;
		getContentPane().add(discription, c);
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 2;
		c.weightx = 0;
		JPanel buttons = new JPanel();
		//set up the ok button
		JButton ok = new JButton("OK");
		ok.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				//try to parse the command to an operation
				//...if it doesn't parse then dispose the dialog
				if(addOperation()){
					new Thread(new RunCommand(command.getText(), frame.data)).start();
				} else {
					logger.warn("[PLINK_Execute(GPLINK, String)]" +
							" can not add operation, not executing command.");
					new PLINK_Execute(frame, command.getText());
				}
				//dispose the exicute dialog
				PLINK_Execute.this.dispose();
			}
		});
		buttons.add(ok);
		//set up the cancel button
		JButton cancel = new JButton("Cancel");
		cancel.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				PLINK_Execute.this.dispose();
			}
		});
		buttons.add(cancel);
		getContentPane().add(buttons, c);
		//pack it all up and show it
		pack();
		setVisible(true);
	}
	/**
	 * Parse the command and try to add it to the
	 * GPLINK instance.
	 * @return True if we successed in adding the operation
	 * and false otherwise.
	 */
	private boolean addOperation(){
		//split the command based on spaces outside of quotes
		String [] parsedCmd = RunCommand.stripAndSplit(command.getText());
		//grab the command line
		String cline = command.getText();
		//grab the discription
		String opDisc = discription.getText();
		//get the vector of output files, we haven't generated
		//...anything yet so give it an empty vector
		Vector <String[]> outfiles = new Vector <String[]> ();
		//initalize a vector of input files
		Vector <String[]> infiles = new Vector <String[]> ();
		//intialize the operation name to null
		String opName = null;
		
		//////////////
		//So we have a slightly clever algorithm here.
		//...We run through each element of the parsed
		//...command. If we run across a file flag then
		//...we set this, pick up the appropreate
		//...file names on the next pass and reset the
		//...flag.
		//////////////
		boolean flag_bfile = false;
		boolean flag_file = false;
		boolean flag_out = false;
		for(String element: parsedCmd){
			if(flag_out){
				opName = FileInfo.fileName(element);
				flag_out = false;
			}else if(flag_bfile){
				infiles.add(new String[] {element + ".bim", ""});
				infiles.add(new String[] {element + ".bed", ""});
				infiles.add(new String[] {element + ".fam", ""});
				flag_bfile = false;
			}else if(flag_file){
				infiles.add(new String[] {element + ".map", ""});
				infiles.add(new String[] {element + ".ped", ""});
				flag_file = false;
			} else if(element.contains(".")
					&& !element.endsWith(".exe")
					&& !element.endsWith(".exe\"")
					&& !element.endsWith("plink")
					&& !element.endsWith("plink\"")){
				infiles.add(new String[] {element, ""});
			}
			flag_file = element.equals("--file");
			flag_bfile = element.equals("--bfile");
			flag_out = element.equals("--out");
		}
		
		//if we found an operation name then
		//...inform the logger and add it to
		//...our data structure and return true.
		if(opName != null && frame.data.getOp(opName) == null){
			logger.info("(addOperation) " + opName);
			frame.data.addOperation(opName, opDisc, cline, null, infiles, outfiles);
			return true;
		} else {
			//otherwise pass a warning to the logger and 
			//...return false
			logger.warn("(addOperation) no operation name found or " +
					"the operation name is not unique!");
			frame.messanger.createError("Command line must " +
					"specify a unique output root via the --out flag.", 
					"addOperation()@PLINK_Execute.java");
			
			return false;
		}
	}
}
