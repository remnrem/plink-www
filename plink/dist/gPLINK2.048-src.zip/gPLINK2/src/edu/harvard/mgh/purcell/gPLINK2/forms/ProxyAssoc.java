package edu.harvard.mgh.purcell.gPLINK2.forms;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import edu.harvard.mgh.purcell.gCLINE.data.FileInfo;
import edu.harvard.mgh.purcell.gPLINK2.GPLINK;
import edu.harvard.mgh.purcell.gPLINK2.baseForm.Form;

/*
 * Form for Proxy association
 */
@SuppressWarnings("serial")
public class ProxyAssoc extends Form {

	public static String name = "Proxy association";
	/**
	 * The JRadioButton that flags the '--proxy-assoc'
	 * option.
	 */
	private JRadioButton assocRadioButton;
	/**
	 * The JRadioButton that flags the '--proxy-impute'
	 * option.
	 */
	private JRadioButton imputeRadioButton;
	/**
	 * The JRadioButton that flags the 
	 * '(SNP)' option
	 */
	private JRadioButton snpRadioButton;
	/**
	 * The JTextField that holds the snp
	 * reference for the '(SNP)'
	 */
	private JTextField snpField;
	/**
	 * The JRadioButton that flags the
	 * 'all --proxy-list (file)' option
	 */
	private JRadioButton allRadioButton;
	/**
	 * The JTextField that flags the 
	 * optional proxy list association with
	 * '--proxy-list (file)'
	 */
	private JTextField allField;
	/**
	 * The JCheckBox that flags the optional
	 * argument '--proxy-window (int)'
	 */
	private JCheckBox windowCheckBox;
	/**
	 * The JTextField that gets the integer
	 * for '--proxy-window (int)'
	 */
	private JTextField windowField;
	/**
	 * The JCheckBox that flags the optional
	 * argument '--proxy-kb (int)'
	 */
	private JCheckBox kbCheckBox;
	/**
	 * The JTextField that gets the integer
	 * for '--proxy-kb (int)'
	 */
	private JTextField kbField;
	/**
	 * The JCheckBox that flags the optional
	 * argument '--proxy-r2-filters (double x3)'
	 */
	private JCheckBox r2CheckBox;
	/**
	 * The JTextField that gets the double
	 * for '--proxy-r2-filters (double x3)'
	 */
	private JTextField r2Field1;
	/**
	 * The JTextField that gets the double
	 * for '--proxy-r2-filters (double x3)'
	 */
	private JTextField r2Field2;
	/**
	 * The JTextField that gets the double
	 * for '--proxy-r2-filters (double x3)'
	 */
	private JTextField r2Field3;
	/**
	 * The JCheckBox that flags the optional
	 * argument '--proxy-glm --covar (file)'
	 */
	private JCheckBox glmCheckBox;
	/**
	 * The JTextField that gets the file
	 * for '--proxy-glm --covar(file)'
	 */
	private JTextField glmField;
	/**
	 * The JCheckBox that flags the optional
	 * argument '--proxy-drop'
	 */
	private JCheckBox dropCheckBox;
	/**
	 * The JCheckBox that flags the optional
	 * argument '--proxy-dosage'
	 */
	private JCheckBox dosageCheckBox;
	/**
	 * The JCheckBox that flags the optional
	 * argument '--proxy-snp-filter (number)'
	 */
	private JCheckBox snpFilterCheckBox;
	/**
	 * The JTextField that gets the number for
	 * '--proxy-snp-filter (number)'
	 */
	private JTextField snpFilterField;
	/**
	 * 
	 * @param p
	 */
	public ProxyAssoc(GPLINK p) {
		super(p, name);
		
		snpRadioButton.setSelected(true);
		
		pack();
		setVisible(true);
	}

	@Override
	protected JPanel createBody() {
		JPanel body = new JPanel();
		//body.setBorder(new TitledBorder("body"));
		body.setLayout(new GridBagLayout());
		GridBagConstraints c0 = new GridBagConstraints();
		c0.fill = GridBagConstraints.BOTH;
		c0.weightx = 1;
		
		//holds the required options
		snpRadioButton = new JRadioButton("Basic snp");
		snpRadioButton.addActionListener(validateBodyAL);
		snpField = new JTextField(10);
		snpField.getDocument().addDocumentListener(validateBodyDL);
		bundel(snpRadioButton, snpField);
		allRadioButton = new JRadioButton("All Snps with a proxy list (--proxy-list)");
		allRadioButton.addActionListener(validateBodyAL);
		allField = new JTextField(15);
		allField.getDocument().addDocumentListener(validateBodyDL);
		BrowseButton allBrowse = new BrowseButton(allField);
		bundel(allRadioButton, allField, allBrowse);
		ButtonGroup g1 = new ButtonGroup();
		g1.add(snpRadioButton);
		g1.add(allRadioButton);
		JPanel req = new JPanel();
		req.setBorder(new TitledBorder("Required snp flags"));
		req.setLayout(new GridBagLayout());
		GridBagConstraints c2 = new GridBagConstraints();
		c2.fill = GridBagConstraints.BOTH;
		req.add(snpRadioButton,c2);
		c2.weightx = 1;
		c2.gridx = 1;
		req.add(snpField,c2);
		c2.gridx = 2;
		c2.gridwidth = 2;
		req.add(new JLabel(), c2);
		c2.weightx = 0;
		c2.gridwidth =1 ;
		c2.gridx = 0;
		c2.gridy = 1;
		req.add(allRadioButton, c2);
		c2.weightx = 1;
		c2.gridx = 1;
		req.add(new JLabel("Optional list: (--proxy-list)"), c2);
		c2.gridx = 2;
		req.add(allField, c2);
		c2.gridx = 3;
		c2.weightx = 0;
		req.add(allBrowse, c2);
		c0.gridy = 0;
		body.add(req, c0);
		
		JPanel req2 = new JPanel();
		req2.setBorder(new TitledBorder("Required test flags"));
		req2.setLayout(new GridBagLayout());
		c2 = new GridBagConstraints();
		c2.fill = GridBagConstraints.BOTH;
		c2.gridy ++;
		c2.weightx = 1;
		assocRadioButton = new JRadioButton("--proxy-assoc");
		req2.add(assocRadioButton, c2);
		JPanel temp = new JPanel();
		temp.setLayout(new GridBagLayout());
		GridBagConstraints c1 = new GridBagConstraints();
		c1.fill = GridBagConstraints.HORIZONTAL;
		c1.weightx = 0;
		c1.gridx++;
		temp.add(glmCheckBox, c1);
		c1.gridx ++;
		c1.weightx = 1;
		temp.add(new JLabel(), c1);
		
		c2.gridwidth = 1;
		c2.gridy ++;
		c2.insets = new Insets(0,20,0,0);  //left padding
		c2.weightx = 1;
		c2.gridx = 0;
		glmCheckBox = new JCheckBox("--proxy-glm");
		req2.add(glmCheckBox, c2);
		c2.gridx ++;
		c2.insets = new Insets(0,0,0,0);  //no padding
		req2.add(new JLabel("(optional: --covar)"), c2);
		c2.gridx ++;
		glmField = new JTextField(15);
		req2.add(glmField, c2);
		c2.gridx = 0;
		c2.gridy ++;
		c2.gridx = 0;
		c2.weightx = 1;
		c2.insets = new Insets(0,20,0,0);  //left padding
		dropCheckBox = new JCheckBox("--proxy-drop");
		req2.add(dropCheckBox, c2);
		c2.gridwidth = 3;
		c2.gridx = 0;
		c2.gridy ++;
		c2.insets = new Insets(0,0,0,0);  //no padding
		imputeRadioButton = new JRadioButton("--proxy-impute");
		req2.add(imputeRadioButton, c2);
		c2.gridwidth = 3;
		c2.gridx = 0;
		c2.gridy ++;
		c2.insets = new Insets(0,20,0,0);  //left padding
		dosageCheckBox = new JCheckBox("--proxy-dosage");
		req2.add(dosageCheckBox, c2);
		c0.gridy ++;
		body.add(req2, c0);
		
		//holds the optional flags
		JPanel opt = new JPanel();
		opt.setBorder(new TitledBorder("Optional"));
		opt.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 1;
		//add window
		windowCheckBox = new JCheckBox("--proxy-window");
		windowCheckBox.addActionListener(validateBodyAL);
		windowField= new JTextField(10);
		windowField.getDocument().addDocumentListener(validateBodyDL);
		bundel(windowCheckBox, windowField);
		temp = new JPanel();
		temp.setLayout(new GridBagLayout());
		c1 = new GridBagConstraints();
		c1.fill = GridBagConstraints.HORIZONTAL;
		c1.weightx = 0;
		temp.add(windowCheckBox, c1);
		c1.weightx = 0.5;
		c1.gridx = 1;
		temp.add(windowField, c1);
		c1.gridx = 2;
		c1.weightx = 1;
		//add this for padding
		temp.add(new JLabel(), c1);
		//add it to opt
		c.gridy ++;
		opt.add(temp, c);
		
		//add kb
		kbCheckBox = new JCheckBox("--proxy-kb");
		kbCheckBox.addActionListener(validateBodyAL);
		kbField = new JTextField(10);
		kbField.getDocument().addDocumentListener(validateBodyDL);
		bundel(kbCheckBox, kbField);
		//create local panel
		temp = new JPanel();
		temp.setLayout(new GridBagLayout());
		c1 = new GridBagConstraints();
		c1.fill = GridBagConstraints.HORIZONTAL;
		c1.weightx = 0;
		temp.add(kbCheckBox, c1);
		c1.weightx = 0.5;
		c1.gridx = 1;
		temp.add(kbField, c1);
		c1.gridx = 2; 
		c1.weightx = 1;
		//add this for padding
		temp.add(new JLabel(), c1);
		//add it to opt
		c.gridy ++;
		opt.add(temp, c);
		
		//add r2
		r2CheckBox = new JCheckBox("--proxy-r2-filters");
		r2CheckBox.addActionListener(validateBodyAL);
		r2Field1 = new JTextField(4);
		r2Field1.getDocument().addDocumentListener(validateBodyDL);
		r2Field2 = new JTextField(4);
		r2Field2.getDocument().addDocumentListener(validateBodyDL);
		r2Field3 = new JTextField(4);
		r2Field3.getDocument().addDocumentListener(validateBodyDL);
		bundel(r2CheckBox, new JTextField[] {r2Field1, r2Field2, r2Field3});
		//create local panel
		temp = new JPanel();
		temp.setLayout(new GridBagLayout());
		c1 = new GridBagConstraints();
		c1.fill = GridBagConstraints.HORIZONTAL;
		c1.weightx = 0;
		temp.add(r2CheckBox, c1);
		c1.weightx = 0.5;
		c1.gridx = 1;
		temp.add(r2Field1, c1);
		c1.gridx ++;
		temp.add(r2Field2, c1);
		c1.gridx ++;
		temp.add(r2Field3, c1);
		c1.gridx = 2;
		c1.weightx = 1;
		//add this for padding
		temp.add(new JLabel(), c1);
		//add it to opt
		c.gridy ++;
		opt.add(temp, c);
		
//		add kb
		snpFilterCheckBox = new JCheckBox("--proxy-snp-filter");
		snpFilterCheckBox.addActionListener(validateBodyAL);
		snpFilterField = new JTextField(10);
		snpFilterField.getDocument().addDocumentListener(validateBodyDL);
		bundel(snpFilterCheckBox, snpFilterField);
		//create local panel
		temp = new JPanel();
		temp.setLayout(new GridBagLayout());
		c1 = new GridBagConstraints();
		c1.fill = GridBagConstraints.HORIZONTAL;
		c1.weightx = 0;
		temp.add(snpFilterCheckBox, c1);
		c1.weightx = 0.5;
		c1.gridx = 1;
		temp.add(snpFilterField, c1);
		c1.gridx = 2; 
		c1.weightx = 1;
		//add this for padding
		temp.add(new JLabel(), c1);
		//add it to opt
		c.gridy ++;
		opt.add(temp, c);
		
		c0.gridy++;
		body.add(opt, c0);
		return body;
	}

	@Override
	protected void isBodyValid() {
		validBody = true;
		if((snpRadioButton.isSelected() && !snpField.getText().matches("[\\d\\w]+"))
			|| (windowCheckBox.isSelected() && !windowField.getText().matches("\\d+"))
			|| (kbCheckBox.isSelected() && !kbField.getText().matches("\\d+"))
			|| (r2CheckBox.isSelected() && !r2Field1.getText().matches("\\d*\\.?\\d+")
					&& !r2Field2.getText().matches("\\d*\\.?\\d+")
					&& !r2Field3.getText().matches("\\d*\\.?\\d+"))){
			validBody = false;
		}
		
		okForm();
	}

	@Override
	protected String processBody() {
		String ans = new String();
		if(snpRadioButton.isSelected()){
			ans += " --proxy-assoc " + snpField.getText();
		}
		if(allRadioButton.isSelected()){
			ans += " --proxy-assoc all" + " " + FileInfo.quote(allField.getText().trim());
		}
		if(windowCheckBox.isSelected()){
			ans += " --proxy-window " + windowField.getText();
		}
		
		if(kbCheckBox.isSelected()){
			ans += " --proxy-kb " + kbField.getText();
		}
		
		if(r2CheckBox.isSelected()){
			ans += " --proxy-r2-filters " + r2Field1.getText() + " " + r2Field2.getText() + " " + r2Field3.getText();
		}
		
	
		ans.trim();
		return ans;
	}

}
