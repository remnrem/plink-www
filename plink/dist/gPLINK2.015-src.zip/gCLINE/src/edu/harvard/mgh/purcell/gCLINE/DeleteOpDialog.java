package edu.harvard.mgh.purcell.gCLINE;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.HashSet;
import java.util.Vector;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;

import edu.harvard.mgh.purcell.gCLINE.data.FileInfo;
import edu.harvard.mgh.purcell.gCLINE.data.Record;

/**
 * Dialog to delete a given operation and the files associated with it.
 * @author Kathe Todd-Brown
 */
@SuppressWarnings("serial")
public class DeleteOpDialog extends JDialog {
	/**
	 * A JCheckBox array that holds the 
	 * deletion options for the selected opertaions.
	 */
	private JCheckBox [] operations;
	/**
	 * A JCheckBox array that holds the 
	 * deletion options for the selected output files.
	 */
	private Vector <JCheckBox> outfiles;
	/**
	 * A JCheckBox array that holds the 
	 * deletion options for the selected input files.
	 */
	private Vector <JCheckBox> infiles;
	/**
	 * The Record that the operations are attached to.
	 */
	private Record data;
	/**
	 * An ActionListener that deletes the files and operations
	 * that are selected in the check boxes.
	 */
	ActionListener deleteFileOp = new ActionListener(){
		public void actionPerformed(ActionEvent event){
			File temp;
			if(data.isRemote() == false){
				//delete the output files
				for(JCheckBox tempBox: outfiles){
					if(tempBox != null && tempBox.isSelected()){
						temp = new File(data.getLocalFolder(), tempBox.getText());
						if(temp.delete()==false){
							data.frame.messanger.createError("Failed deletion of ["+
									tempBox.getText() + 
									"] You will need to manually check the" +
									"deletion of " +
									"this file.","deleteFileOp@DeleteOpDialog.java");
						}
					}
					
				}
				//delete the input files
				for(JCheckBox tempBox:infiles){
					if(tempBox.isSelected()){
						temp = new File(data.getLocalFolder(), tempBox.getText());
						if(temp.delete()==false){
							data.frame.messanger.createError("Failed deletion of ["+
									tempBox.getText() + 
									"] You will need to manually check the" +
									"deletion of " +
									"this file.","deleteFileOp@DeleteOpDialog.java");
						}
					}
					
				}
			}
			//remote the operations
			for(int i = 0; i < operations.length; i++){
				if(operations[i].isSelected()){
					data.removeOperation(operations[i].getText());
				}
			}
			
			dispose();
		}};
	/**
	 * Creat a Panel that has all the operation
	 * names with the check box to flag confirmation
	 * of deletion
	 * @param opNames A String array that is the operation
	 * names
	 * @return A JPanel that contains all the string operations.
	 */
	private JPanel createOpPanel(String [] opNames){
		JPanel ans = new JPanel();
		ans.setLayout(new BoxLayout(ans, BoxLayout.PAGE_AXIS));
		ans.setBorder(new TitledBorder("Operations to Delete"));
		
		int numOps = opNames.length;
		
		operations = new JCheckBox[numOps];
		
		//populate the operations names
		for(int i = 0; i < numOps; i ++){
			operations[i] = new JCheckBox(opNames[i]);
			operations[i].setSelected(true);
			ans.add(operations[i]);
		}
		
		return ans;
	}
	/**
	 * Find files 
	 * attached to all the operaitons and initalize 
	 * the appropreate panels.
	 * @param opNames A String array that holds all the operations names
	 * that we are interested in.
	 * @param inFiles A boolean that flags the input vs output files.
	 * @return A JPanel containing the files you wish to delete.
	 */
	private JPanel createFilePanel(String [] opNames, boolean inFiles){
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, 
				BoxLayout.PAGE_AXIS));
		//put the right title in it
		if(inFiles)
			panel.setBorder(new TitledBorder("Input files to Delete"));
		else
			panel.setBorder(new TitledBorder("Output files to Delete"));
		
		//create a hash set of the files we are interested in
		//...this allows us to avoid double listing a file if it shows
		//...up in multiple operatoins
		HashSet <String> files = new HashSet <String>();
		
		Vector <FileInfo> temp = new Vector <FileInfo>();
		
		//populate the infiles
		for(int i = 0; i < opNames.length; i++){
			//get the right file set
			if(inFiles)
				temp = data.getOp(opNames[i]).getInputFiles();
			else
				temp = data.getOp(opNames[i]).getOutputFiles();
			//add the files to the hash set
			for(FileInfo f: temp)
				files.add(f.toString());
		}
		
		//process the file info to checkboxes
		if(inFiles)
			infiles = new Vector<JCheckBox>();
		else
			outfiles = new Vector <JCheckBox>();
		//go through all the fiels you have lined up
		for(String file: files){
			JCheckBox tempBox = new JCheckBox(file);
			if(inFiles)
				infiles.add(tempBox);
			else
				outfiles.add(tempBox);
			
			//add them to the panel
			panel.add(tempBox);
		}
		
		return panel;
	}
	/**
	 * Create a JPanel that holds the buttons for this
	 * dialog.
	 * @return a JPanle that holds the buttosn for this
	 * dialog.
	 */
	private JPanel createButtonsPanel(){
		JPanel buttonPanel = new JPanel();
		
		//set up the ok button
		JButton ok = new JButton("Delete Selection");
		ok.addActionListener(deleteFileOp);
		buttonPanel.add(ok);
		
		//set up the cancel button
		JButton cancel = new JButton("Cancel");
		cancel.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				DeleteOpDialog.this.dispose();
			}
		});
		buttonPanel.add(cancel);
		
		return buttonPanel;
		
	}
	/**
	 * Create a deletion dialog for a select number
	 * of operatoins.
	 * @param givenFrame A StartFrame that this dialog will
	 * be attached to and will provide the error manager.
	 * @param d A Record that contains these operations.
	 * @param opNames A String array is the operation
	 * names that we want to delete.
	 */
	public DeleteOpDialog(StartFrame givenFrame,
			Record d, String [] opNames){
		//intialize stuff
		super(givenFrame, "Delete Operations");
		data = d;
		//set up the dialog
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		getContentPane().setLayout(new GridLayout(4,1));
		//add the operation panel
		getContentPane().add(new JScrollPane(createOpPanel(opNames)));
		//add the file panels if we can delete files
		if(data.isRemote() == false){
			getContentPane().add(new JScrollPane(createFilePanel(opNames, true)));
			getContentPane().add(new JScrollPane(createFilePanel(opNames, false)));
		}
		//add the button panels
		getContentPane().add(createButtonsPanel());
		//show it off
		pack();
		setVisible(true);
	}
	
}
