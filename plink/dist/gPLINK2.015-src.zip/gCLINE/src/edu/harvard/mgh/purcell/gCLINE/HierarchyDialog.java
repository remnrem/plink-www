package edu.harvard.mgh.purcell.gCLINE;

import java.util.HashSet;
import java.util.Vector;

import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;

import edu.harvard.mgh.purcell.gCLINE.data.FileInfo;
import edu.harvard.mgh.purcell.gCLINE.data.OperationInfo;
import edu.harvard.mgh.purcell.gCLINE.data.Record;

/**
 * 
 * @author Kathe Todd-Brown
 *
 */
@SuppressWarnings("serial")
public class HierarchyDialog extends JDialog {

	JTree ancesters;
	JTree decendents;
	Record data;
	
	String opName;
	String fileName;
	
	private String myArrayString(String [] info){
		String ans = "<html> ";
		
		if(info.length > 0)
			ans = ans + info[0];
		
		for(int i =1; i < info.length; i++){
			ans = ans + " <br> " + info[i];
		}
		ans = ans + " </html>";
		//System.out.println(ans);
		return ans;
	}
	
	private void createTree(){
		//create the top node for both trees and fill
		//...them with logical nonsence
		DefaultMutableTreeNode childTop = new DefaultMutableTreeNode("");
		DefaultMutableTreeNode parentTop = new DefaultMutableTreeNode("");
		//fill either as an operation or file depending
		//...on what is not null
		if(opName != null){
			//set the operation names in the trees
			childTop = new DefaultMutableTreeNode(opName);
			parentTop = new DefaultMutableTreeNode(opName);
			//populate the trees
			childrenOp(opName, childTop);
			parentOp(opName, parentTop);
		} else if(fileName != null){
			childTop = new DefaultMutableTreeNode(fileName);
			parentTop = new DefaultMutableTreeNode(fileName);
			childrenFile(new String [] {fileName}, childTop);
			parentFile(new String [] {fileName}, parentTop);
		}
		//set the trees to their top nodes
		ancesters = new JTree(parentTop);
		decendents = new JTree(childTop);
	}
	
	@SuppressWarnings("static-access")
	private String [] getOutFiles(String opName){
		
		Vector<FileInfo> temp = data.getOp(opName).getOutputFiles();
		String [] ans = new String [temp.size()];
		for(int i = 0; i < ans.length; i++){
			ans[i] = temp.get(i).toString();
		}
		return ans;
	}
	
	@SuppressWarnings("static-access")
	private String [] getInFiles(String opName){
		Vector<FileInfo> temp = data.getOp(opName).getInputFiles();
		String [] ans = new String [temp.size()];
		for(int i = 0; i < ans.length; i++){
			ans[i] = temp.get(i).toString();
		}
		return ans;
	}
	
	private void childrenOp(String op, DefaultMutableTreeNode parent){
		String [] outfiles = getOutFiles(op);
		
		DefaultMutableTreeNode temp = new DefaultMutableTreeNode(myArrayString(outfiles));
		childrenFile(outfiles, temp);
		parent.add(temp);
		
	}
	
	private void parentOp(String op, DefaultMutableTreeNode parent){
		String [] outfiles = getInFiles(op);
		DefaultMutableTreeNode temp = new DefaultMutableTreeNode(myArrayString(outfiles));
		parentFile(outfiles, temp);
		parent.add(temp);
		
		
		
	}
	
	@SuppressWarnings("static-access")
	private String [] getChildOp(String file){
		Vector <OperationInfo> allOp = data.getAllOp();
		HashSet <String> ansHash = new HashSet<String>();
		
		for(OperationInfo op: allOp){
			Vector<FileInfo> infiles = op.getInputFiles();
			for(FileInfo temp:infiles){
				if((temp.toString()).equals(file)){
					ansHash.add(op.getName());
					break;
				}
			}
		}
		String [] ans = new String [ansHash.size()];
		int i =0;
		for(String name: ansHash){
			ans[i] = name;
			i++;
		}
		
		return ans;
	}
	
	@SuppressWarnings("static-access")
	private String [] getParentOp(String file){
		Vector <OperationInfo> allOp = data.getAllOp();
		HashSet <String> ansHash = new HashSet<String>();
		
		for(OperationInfo op: allOp){
			Vector<FileInfo> outfiles = op.getOutputFiles();
			for(FileInfo temp:outfiles){
				if((temp.toString()).equals(file)){
					ansHash.add(op.getName());
					break;
				}
			}
		}
		String [] ans = new String [ansHash.size()];
		int i =0;
		for(String name: ansHash){
			ans[i] = name;
			i++;
		}
		
		return ans;
	}
	
	private void childrenFile(String [] files, DefaultMutableTreeNode parent){

		HashSet <String> allOp = new HashSet <String>();
		for(int i = 0; i < files.length; i ++){
			String [] childOp = getChildOp(files[i]);
			for(int j = 0; j < childOp.length; j++){
				allOp.add(childOp[j]);
			}
		}
		if(allOp == null
				|| allOp.size() == 0)
			return;
		
		for(String opName: allOp){
			DefaultMutableTreeNode temp = new DefaultMutableTreeNode(opName);
			childrenOp(opName, temp);
			parent.add(temp);
			
		}
	}
	private void parentFile(String [] files, DefaultMutableTreeNode parent){

		HashSet <String> allOp = new HashSet <String>();
		for(int i = 0; i < files.length; i ++){
			String [] parentOp = getParentOp(files[i]);
			for(int j = 0; j < parentOp.length; j++){
				allOp.add(parentOp[j]);
			}
		}
		if(allOp == null
				|| allOp.size() == 0)
			return;
		for(String opName: allOp){
			DefaultMutableTreeNode temp = new DefaultMutableTreeNode(opName);
			parentOp(opName, temp);
			parent.add(temp);
			
		}
	}
	
	/**
	 * Main constructor. Note that either the file or op string parameters is null.
	 * @param title a String that is the title of the dialog.
	 * @param mf a Mainframe that this dialog is attached to
	 * @param op a string identifying the operation that is the root
	 * @param file a string that identifies the file that is the root
	 */
	public HierarchyDialog(String title, StartFrame mf,
			Record d,
			String op, String file){
		//create the dialog and attach it to mf
		super(mf, title);
		//set the data structure we are working with
		data = d;
		//set the operation and file name, one of which
		//...is null
		opName = op;
		fileName = FileInfo.fileName(file);
		
		//create the conent
		createTree();
		
		//set the row height to 0 so that it is
		//...computed for each row individually
		ancesters.setCellRenderer(new MyRenderer());
		ancesters.setRowHeight(0);
		decendents.setCellRenderer(new MyRenderer());
		decendents.setRowHeight(0);
		
		//layout the ancesters and decendents in different tabs
		JTabbedPane tabs = new JTabbedPane();
		tabs.add("Ancestors", new JScrollPane(ancesters));
		tabs.add("Descendents", new JScrollPane(decendents));
		getContentPane().add(tabs);
		
		//show everything off!
		pack();
		setVisible(true);
	}
	
	class MyRenderer extends DefaultTreeCellRenderer {
	    //there are some undesirable side effects that
		//...we are avoiding with this. The direct leaves
		//...of selected nodes went white-on-white and 
		//...now there is just a box border instead
	    public MyRenderer() {
	        super();
	        this.setBackgroundSelectionColor(this.getBackgroundNonSelectionColor());
	        this.setTextSelectionColor(this.getTextNonSelectionColor());
	       
	    }
	}
}
