package edu.harvard.mgh.purcell.gPLINK2.forms;

import javax.swing.JPanel;

import edu.harvard.mgh.purcell.gPLINK2.GPLINK;
import edu.harvard.mgh.purcell.gPLINK2.baseForm.Form;

/**
 * Create a form that will provide basic summery
 * statistics for a file set.
 * @author Kathe Todd-Brown
 *
 */
@SuppressWarnings("serial")
public class Basic extends Form {
	/**
	 * The name of this form
	 */
	public static String name = "Validate Fileset";
	/**
	 * Create a form that will allow the user to select
	 * which fileset they want to validate and what they
	 * want to call the output files.
	 * @param p The GPLINK this is attached to.
	 */
	public Basic(GPLINK p) {
		super(p, name);
		validBody = true;
		okForm();
		pack();
		setVisible(true);
	}

	@Override
	protected JPanel createBody() {
		return new JPanel();
	}

	@Override
	protected String processBody() {
		String cmd = "{insert PLINK command here}";
		return cmd;
	}

	@Override
	protected void isBodyValid() {
		//nothing here
	}

}
