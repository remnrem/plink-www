package edu.harvard.mgh.purcell.gPLINK2.forms;

import javax.swing.JLabel;
import javax.swing.JPanel;

import edu.harvard.mgh.purcell.gPLINK2.GPLINK;
import edu.harvard.mgh.purcell.gPLINK2.baseForm.Form;

@SuppressWarnings("serial")
public class IndHetz extends Form {
	public static String name = "Individual heterozygosity";
	public IndHetz(GPLINK mf) {
		super(mf, name);
		validBody = true;
		pack();
		setVisible(true);
	}

	@Override
	protected JPanel createBody() {
		isBodyValid();
		JPanel body = new JPanel();
		body.add(new JLabel("Individual heterozygosity (--het)"));
		return body;
	}

	@Override
	protected String processBody() {
		return "--het";
	}

	@Override
	protected void isBodyValid() {
		//this is always valid
	}

}
