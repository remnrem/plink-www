package edu.harvard.mgh.purcell.gPLINK2.baseForm;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import java.io.File;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.filechooser.FileFilter;

import org.apache.log4j.Logger;

import edu.harvard.mgh.purcell.gCLINE.data.FileInfo;
import edu.harvard.mgh.purcell.gCLINE.general.GCFileChooser;
import edu.harvard.mgh.purcell.gCLINE.general.GCFileChooser.FileChoosenEvent;
import edu.harvard.mgh.purcell.gCLINE.general.GCFileChooser.FileChoosenListener;
import edu.harvard.mgh.purcell.gPLINK2.GPLINK;
import edu.harvard.mgh.purcell.gPLINK2.PLINK_Execute;

public abstract class Form extends JDialog {
	/**
	 * Optionally log messages.
	 */
	private static Logger logger = Logger.getLogger(Form.class);
	/**
	 * The GPLINK instance that this form is
	 * attached to.
	 */
	public GPLINK parent;
	/**
	 * The InputPane for this form.
	 * This is made public so that the merge form
	 * can access certain functions.
	 */
	public InputPane input;
	/**
	 * The OutputPane for this form.
	 */
	protected OutputPane output;
	private String filter = "";
	
	public void resetFilter(){
		filter = "";
	}
	
	public void addFilter(String newParam){
		filter += " " + newParam;
	}
	
	private String threshold = "";
	
	public void resetThreshold(){
		threshold = "";
	}
	
	public void addThreshold(String newParam){
		threshold += " " + newParam;
	}
	
	/**
	 * Create the body for this form.
	 * @return A JPanel that holds the body
	 * of this form.
	 */
	protected abstract JPanel createBody();
	
	/**
	 * Flag if the body of the form is filled
	 * out correctly.
	 */
	protected boolean validBody = false;
	
	/**
	 * The ok button on the form, this is
	 * a class variable because it is en/disabled
	 * in okForm()
	 */
	private JButton ok;
	private JButton cancel;
	protected JButton filterButton;
	protected JButton thresholdButton;
	protected ActionListener validateBodyAL = new ActionListener(){
		public void actionPerformed(ActionEvent e) {
			isBodyValid();
		}
	}; 
	protected DocumentListener validateBodyDL = new DocumentListener(){
		public void changedUpdate(DocumentEvent e) {}
		public void insertUpdate(DocumentEvent e) {
			isBodyValid();
		}
		public void removeUpdate(DocumentEvent e) {
			isBodyValid();
		}
	};
	/**
	 * Create the commandline based on the fields
	 * of this form.
	 * @return A String that is the PLINK command
	 * for this from. Note that this includes the
	 * any noted plink prefixes and the plink
	 * path.
	 */
	protected abstract String processBody();
	/**
	 * Check to see if the body is correctly filled
	 * out. If it is then the forms validBody boolean
	 * flag is set to true, otherwise it is set to false.
	 */
	protected abstract void isBodyValid();
	/**
	 * Enable and disable the ok button to reflect
	 * if the form is correctly or incorrectly filled
	 * out.
	 *
	 */
	protected void okForm(){
		logger.info("(okForm()) Entering okForm");
		if(input.validInput 
				&& output.validOutput 
				&& this.validBody)
			ok.setEnabled(true);
		else
			ok.setEnabled(false);
	}
	
	public void closeButtons(){
		ok.setEnabled(false);
		cancel.setEnabled(false);
		filterButton.setEnabled(false);
		thresholdButton.setEnabled(false);
	}
	
	public void openButtons(){
		ok.setEnabled(true);
		cancel.setEnabled(true);
		filterButton.setEnabled(true);
		thresholdButton.setEnabled(true);
		isBodyValid();
	}
	
	/**
	 * Create a JPanel that holds the ok/cancel
	 * buttons for this form.
	 * @return A JPanel that has the ok/cancel/threshold/filter
	 * buttons that will be located at the end of the form.
	 */
	private JPanel createButtonPane(){
		JPanel ans = new JPanel();
		
		filterButton = new JButton("Filter");
		filterButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new FilterDialog(Form.this);
			}
		});
		
		thresholdButton = new JButton("Threshold");
		thresholdButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new ThresholdDialog(Form.this);
			}
		});
		
		ok = new JButton("OK");
		ok.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				new PLINK_Execute(parent, process());
				Form.this.dispose();
			}
		});
		ok.setEnabled(false);
		
		cancel = new JButton("Cancel");
		cancel.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				logger.info("(createButtonPane())Cancel button activated");
				Form.this.dispose();
			}
		});
		
		ans.add(filterButton);
		ans.add(thresholdButton);
		ans.add(ok);
		ans.add(cancel);
		return ans;
	}
	/**
	 * Process forms in general.
	 * @return A String that is the command line to be run.
	 */
	private String process(){
		String cmd = parent.data.getPlinkPrefix()
		+ " " + FileInfo.quote(parent.data.getPlinkPath())
		+ " " + filter
		+ " " + threshold
		+ " " + input.process() 
		+ " " + processBody()
		+ " " + output.process();
		
		return cmd;
	}
	
	/**
	 * 
	 * @param p
	 * @param name
	 */
	public Form(GPLINK p, String name){
		super(p, name);
		parent = p;
		input = new InputPane(parent, this);
		output = new OutputPane(this, 
				parent.data.OP_LOG_EXT, 
				parent.data.getHomeFiles(), 
				parent.data.getHomeFolder());
		createBody();

		this.getContentPane().setLayout(new BoxLayout(getContentPane(), BoxLayout.PAGE_AXIS));
		getContentPane().add(input);
		getContentPane().add(new JScrollPane(createBody()));
		getContentPane().add(output);
		getContentPane().add(createButtonPane());
	}
	
	static public JPanel bundel(final JToggleButton toggle, 
			final JTextField text, final JButton button){
		toggle.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e) {
				text.setEnabled(toggle.isSelected());
				button.setEnabled(toggle.isSelected());
			}
		});
		
		text.setEnabled(toggle.isSelected());
		button.setEnabled(toggle.isSelected());
		JPanel ans = new JPanel();
		ans.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.BOTH;
		ans.add(toggle, c);
		c.gridx = 1;
		c.weightx = 1;
		ans.add(text, c);
		c.weightx = 0;
		c.gridx = 2;
		ans.add(button, c);
		return ans;
	}
	
	static public JPanel bundel(final JToggleButton toggle,
			final JTextField text){
		toggle.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e) {
				text.setEnabled(toggle.isSelected());
			}
		});
		
		text.setEnabled(toggle.isSelected());
		JPanel ans = new JPanel();
		ans.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		ans.add(toggle, c);
		c.gridx = 1;
		ans.add(text, c);
		return ans;
	}
	
	static public  void bundel(final JToggleButton toggle, 
			final JTextField [] texts, final BrowseButton [] buttons){
		toggle.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e) {
				boolean selected = toggle.isSelected();
				for(JTextField f : texts)
					f.setEnabled(selected);
				for(BrowseButton b: buttons)
					b.setEnabled(selected);
			}
		});
		boolean selected = toggle.isSelected();
		for(JTextField f : texts)
			f.setEnabled(selected);
		for(BrowseButton b: buttons)
			b.setEnabled(selected);
	}
	
	static public void bundel(final JToggleButton toggle, 
			final JTextField [] texts){
		toggle.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e) {
				boolean selected = toggle.isSelected();
				for(JTextField f : texts)
					f.setEnabled(selected);
			}
		});
		boolean selected = toggle.isSelected();
		for(JTextField f : texts)
			f.setEnabled(selected);
	}
	
	static public JPanel bundel(JTextField text, JButton button){
		JPanel ans = new JPanel();
		ans.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		//c.anchor = GridBagConstraints.LINE_START;
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 1;
		ans.add(text, c);
		c.weightx = 0;
		c.gridx = 2;
		ans.add(button, c);
		return ans;
	}
	
	@SuppressWarnings({ "serial", "unused" })
	public class BrowseButton extends JButton{
		
		private String suffex;
		private String suffexDisc;
		private JTextField target;
		private GCFileChooser pick;
		
		public BrowseButton(JTextField givenTarget){
			this(givenTarget, null, null);
		}
		
		public BrowseButton(JTextField givenTarget, 
				String givenSuffex, 
				String givenSuffexDisc){
			super("Browse");
			target = givenTarget;
			suffex = givenSuffex;
			suffexDisc = givenSuffexDisc;
			addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					FileFilter temp = null;
					
					if(suffex != null){
						temp = new FileFilter (){
							@Override
							public boolean accept(File f) {
								return f.getAbsolutePath().endsWith(suffex);
							}
							@Override
							public String getDescription() {
								return suffexDisc;
							}};
					}
					
					pick = new GCFileChooser(
							Form.this, 
							temp, 
							!parent.data.isRemote(), 
							false,
							parent.data.getConn(), 
							parent.data.getHomeFolder());
					pick.addFileChoosenListener(new FileChoosenListener(){
						public void fileChoosenOccures(FileChoosenEvent evt) {
							target.setText(pick.fileName);
						}});
					pick.showChooser();
				}
			});
		}
	}
}
