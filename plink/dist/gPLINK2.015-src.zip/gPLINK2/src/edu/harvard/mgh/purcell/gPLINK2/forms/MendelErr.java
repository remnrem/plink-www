package edu.harvard.mgh.purcell.gPLINK2.forms;

import javax.swing.JPanel;

import edu.harvard.mgh.purcell.gPLINK2.GPLINK;
import edu.harvard.mgh.purcell.gPLINK2.baseForm.Form;

@SuppressWarnings("serial")
public class MendelErr extends Form {
	public static String name = "Mendel Error Rates";
	
	public MendelErr(GPLINK mf) {
		super(mf, name);
		pack();
		setVisible(true);
	}

	@Override
	protected JPanel createBody() {
		isBodyValid();
		return new JPanel();
	}

	@Override
	protected void isBodyValid() {
		validBody = true;
	}

	@Override
	protected String processBody() {
		return " --mendel";
	}

}
