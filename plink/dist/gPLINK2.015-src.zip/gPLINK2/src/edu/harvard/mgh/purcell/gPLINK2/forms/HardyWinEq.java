package edu.harvard.mgh.purcell.gPLINK2.forms;

import javax.swing.JPanel;

import edu.harvard.mgh.purcell.gPLINK2.GPLINK;
import edu.harvard.mgh.purcell.gPLINK2.baseForm.Form;

/**
 * Create a form that checks the hardy weinburg
 * equalibrium of a given data set.
 * @author Kathe Todd-Brown
 */
@SuppressWarnings("serial")
public class HardyWinEq extends Form {
	/**
	 * The name of the form.
	 */
	public static String name = "Hardy Weinberg";
	/**
	 * Create a hardy-Weinburg form.
	 * @param mf The GPLINK instance this is attached to.
	 */
	public HardyWinEq(GPLINK mf) {
		super(mf, name);
		validBody = true;
		pack();
		setVisible(true);
	}

	@Override
	protected JPanel createBody() {
		return new JPanel();
	}

	@Override
	protected void isBodyValid() {
		//nothing here since it is always true
	}

	@Override
	protected String processBody() {
		return "--hardy";
	}

}
