package swingTerminal;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class LoginDialog extends JDialog {
	
	JTextField host, user, port;
	
	JButton login;
	
	public LoginDialog(TerminalFrame parent){
		super(parent, "Login");
		
		host = new JTextField(20);
		user = new JTextField(10);
		port = new JTextField(5);
		
		login = new JButton("Login");
		
		getContentPane().add(new JLabel("Hostname:"));
		getContentPane().add(host);
		getContentPane().add(new JLabel("Username:"));
		getContentPane().add(user);
		getContentPane().add(new JLabel("Port:"));
		getContentPane().add(port);
		getContentPane().add(login);
	}
}
