
package swingTerminal;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.swing.JFrame;
import javax.swing.JTextArea;

import com.sshtools.common.authentication.PasswordAuthenticationDialog;
import com.sshtools.j2ssh.SshClient;
import com.sshtools.j2ssh.authentication.AuthenticationProtocolState;
import com.sshtools.j2ssh.authentication.PasswordAuthenticationClient;
import com.sshtools.j2ssh.session.SessionChannelClient;
import com.sshtools.j2ssh.transport.ConsoleKnownHostsKeyVerification;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class TerminalFrame extends JFrame {
//	 A buffered reader so we can request information from the user
	  private static BufferedReader reader =
	        new BufferedReader(new InputStreamReader(System.in));
	  
	
	JTextArea display;
	
	private void getConnection(){
		try {
	    	SshClient ssh 
	    	  = new SshClient();

	    	

	    	System.out.print("Host to connect: ");

	    	String hostname = reader.readLine();

	    	ssh.connect(hostname, new ConsoleKnownHostsKeyVerification());
		
    	 /** 
    	  * Create a PasswordAuthenticationClient instance, set the properties
    	  * and pass to the SessionClient to authenticate
    	  */
    	  /*PasswordAuthenticationClient auth = new PasswordAuthenticationClient();
    	  
    	  System.out.print("Username: ");
    	  String username = reader.readLine();
    	  auth.setUsername(username);
    	  
    	  System.out.print("Password: ");
    	  String password = reader.readLine();
    	  auth.setPassword(password);
    	  
    	  int result = ssh.authenticate(auth);
    	  */
	    	
    	  /***
    	  * Create a PasswordAuthenticationDialog instance and call the
    	  * showAuthenticationMethod so the user can graphically
    	  * enter their username and password
    	  */
    	  
    	  PasswordAuthenticationClient pwd = 
    	              new PasswordAuthenticationClient();
    	  			
    	  PasswordAuthenticationDialog dialog = 
    	              new PasswordAuthenticationDialog(this);
    	  			
    	  pwd.setAuthenticationPrompt(dialog);

    	  int result;
    	  result = ssh.authenticate(pwd);
    	  
    	  /***
    	   * Check the results.
    	   */
    	  
    	  if(result==AuthenticationProtocolState.FAILED)
		     System.out.println("The authentication failed");

		  if(result==AuthenticationProtocolState.PARTIAL)
		     System.out.println("The authentication succeeded but another"
			                   + "authentication is required");

		  if(result==AuthenticationProtocolState.COMPLETE)
		     System.out.println("The authentication is complete");
    	  
		  SessionChannelClient session = ssh.openSessionChannel();
		  
		  session.executeCommand("ls");
		  /**
		  * Reading from the session InputStream
		  */
		  InputStream in = session.getInputStream();
		  byte buffer[] = new byte[255];
		  int read;
		  while((read = in.read(buffer)) > 0) {
		     String out = new String(buffer, 0, read);
		     System.out.println(out);
		  }
		  session.close();
		  
		  ssh.disconnect();
	    } catch(Exception e) {
	      e.printStackTrace();
	    }
	}
	
	public TerminalFrame(){
		super("Terminal");
		/***
		 * turn off the logging
		 */
		Logger  logger = Logger.getLogger("com.sshtools");
		logger.setLevel(Level.FATAL);
		
		display = new JTextArea(10, 80);
		
		getConnection();
		
		this.getContentPane().add(display);
	}
	
	public static void main(String [] arg0){
		TerminalFrame tester = new TerminalFrame();
		tester.pack();
		tester.setVisible(true);
	}
}
