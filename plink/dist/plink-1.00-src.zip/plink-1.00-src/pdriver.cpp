

//////////////////////////////////////////////////////////////////
//                                                              //
//           PLINK (c) 2005-2007 Shaun Purcell                  //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 2.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////

#include <iomanip>

#include "plink.h"
#include "options.h"
#include "helper.h"
#include "phase.h"

void Plink::proxyWrapper()
{

  if (!par::SNP_major) 
    Ind2SNP();
  

  /////////////////////////////////////////////////////
  // Use 'pos' slot in Locus to store genotyping
  // rate information, as we need access to this often

  for (int l=0 ; l<nl_all; l++)
    locus[l]->pos = genotypingRate(*this,l);
  
  string f = par::output_file_name;
  string f2 = par::output_file_name;

  if ( par::proxy_impute )
    {
      f += ".proxy.impute";
      f2 += ".proxy.impute.dosage";
    }
  else if ( par::proxy_error )
    {
      f += ".proxy.genocheck";
    }
  else if ( par::proxy_all && ! par::proxy_full_report )
    {
      if ( par::proxy_CC )
	{
	  if ( par::qt )
	    f += ".qassoc.proxy";
	  else
	    f += ".assoc.proxy";
	}
      else
	f += ".tdt.proxy";
    }
  else 
    f += ".proxy.report";
  
  haplo->HTEST.open(f.c_str(),ios::out);
  haplo->HTEST.precision(4);
  
  if ( par::proxy_record_dosage )
    {
      OUTFILE.open(f2.c_str(),ios::out);
      OUTFILE.precision(4);
    }

  printLOG("Proxy SNP genotyping threshold ( P-GENO > "+dbl2str(par::proxy_geno)+" )\n");
  printLOG("Proxy SNP MAF threshold ( P-MAF >= " + dbl2str(par::proxy_maf) +" )\n");
  printLOG("Proxy kb threshold ( P-KB <= " + dbl2str(par::proxy_kb) +" )\n");
  
  if ( par::proxy_impute ) 
    {
      int reference_panel = 0;
      for ( int i = 0 ; i < n ; i++ )
	if ( sample[i]->missing )
	  reference_panel++;
      if ( reference_panel == 0 )
	error("No reference panel for imputation (i.e. individuals with missing phenotypes)\n");
	  printLOG("Imputation reference panel of " 
		     + int2str(reference_panel) + " individuals\n");
    }
  
  if ( ( ! par::proxy_impute ) && ( ( !par::proxy_all ) || par::proxy_full_report ) ) 
    {
      printLOG("Minimum proxy haplotype frequency ( P-MHF >= "
	       +dbl2str(par::proxy_mhf)+" )\n");
      printLOG("Proxy r-squared threshold ( P-RSQ >= " + dbl2str(par::proxy_r2) +" )\n");
      printLOG("Maximum of " + int2str(par::proxy_maxhap) + " SNPs per subhaplotype\n");
    }
  
  printLOG("Writing haplotype-based proxy tests to [ " + f + " ] \n");
  if ( par::proxy_record_dosage )
    printLOG("Writing dosage imputation information to [ " + f2 + " ]\n");
  
  // Either condsider all markers, with reduced output (i.e. 
  // just the haplotype based test for that SNP, or a single 
  // marker with extended outout
  
  if ( par::proxy_all )
    {
      
      set<int> plocus;
	  
      if ( par::proxy_all_list ) 
	{
	  // read list of SNPs to use as reference SNP
	  // for proxy
	  
	  ifstream PLIST;
	  checkFileExists(par::proxy_all_list_file);
	  PLIST.open(par::proxy_all_list_file.c_str(), ios::in);
	  while ( ! PLIST.eof() )
	    {
	      string marker ;
	      PLIST >> marker;
	      plocus.insert( getMarkerNumber(*this,marker) );
	    }
	  PLIST.close();
	  
	}
      
      // And we might want a full report for each?
      // Turn off 'all' mode in that case to get 
      // verbose output
      
      if ( par::proxy_full_report ) 
	par::proxy_all = false;
      else
	{
	  if ( par::proxy_impute )
	    haplo->HTEST << setw(4) << "CHR" << " " 
			 << setw(par::pp_maxsnp) << "SNP" << " "
			 << setw(4) << "NPRX" << " "
			 << setw(8) << "INFO" << " "
			 << setw(8) << "TOTAL_N" << " "
			 << setw(8) << "OBSERVD" << " "
			 << setw(8) << "IMPUTED" << " "
			 << setw(8) << "OVERLAP" << " "
			 << setw(8) << "CONCORD" << "\n";
	  else
	    {
	      //haplo->HTEST.setf(ios::scientific);
	      haplo->HTEST << setw(4) << "CHR" << " " 
			     << setw(par::pp_maxsnp) << "SNP" << " "
			     << setw(12) << "BP" << " "
			     << setw(4) << "A1" << " "
			     << setw(4) << "A2" << " "
			     << setw(10) << "GENO" << " " 
			     << setw(4) << "NPRX" << " "
			     << setw(8) << "INFO" << " ";
	      
	      if ( par::proxy_CC )
		{
		  if ( par::qt ) 
		    haplo->HTEST << setw(8) << "F" << " "
				   << setw(8) << "BETA" << " ";
		  else
		    haplo->HTEST << setw(8) << "F_A" << " "
				   << setw(8) << "F_U" << " "
				   << setw(8) << "OR" << " ";		      
		}
	      else if ( par::proxy_TDT )
		haplo->HTEST << setw(8) << "T" << " "
			       << setw(8) << "U" << " "
			       << setw(8) << "OR" << " ";
	      
	      haplo->HTEST << setw(8) << "P" << "\n";
	      
	    }
	}
      
      
      ////////////////////////////////////////
      // Set-up cache for LD values
      
      proxyLD.clear();
      
      
	  
      ////////////////////////////////////////
      // Iterate over all SNPs specified 
      
      for ( int l = 0 ; l < nl_all ; l++ ) 
	{
	  
	  // Skip if not on list
	  if ( par::proxy_all_list ) 
	    if ( plocus.find(l) == plocus.end() )
	      continue;
	  
	  if ( ! par::silent )
	    {
	      cout << l+1 << " of " << nl_all << " performed         \r";
	      cout.flush();
	    }
	  
	  

	    ///////////////////////////////////
	    // Perform actual proxy-based test
	    
	    performProxyTests(l);
	    

	    ///////////////////////////////////
            // Clear the LD cache occassionally
	      
	    if ( proxyLD.size() > 50000 )
	      proxyLD.clear();
	    
	}
      
      if ( ! par::silent )
	cout << "\n";	  
    }
  else
    {
      int l = getMarkerNumber(*this,par::proxy_assoc_snp);
      if ( l < 0 )
	error("Cannot find proxy SNP [ " + par::proxy_assoc_snp + " ]\n");
      
      performProxyTests(l);
      
    }
  
  haplo->HTEST.close();

  if ( par::proxy_record_dosage )
    OUTFILE.close();

}
