

//////////////////////////////////////////////////////////////////
//                                                              //
//           PLINK (c) 2005-2006 Shaun Purcell                  //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 2.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////

#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <map>
#include <algorithm>
#include <bitset>
#include <limits>
#include <errno.h>
#include "plink.h"
#include "options.h"
#include "helper.h"

extern ofstream LOG;

void Plink::readDataLongFormat()
{
  
  
  //////////////////////
  // Check files exist
  
  checkFileExists(par::lpedfile);
  checkFileExists(par::mapfile);
  checkFileExists(par::lfamfile);


  ///////////////////////////////////////////////
  // .map file
  
  vector<bool> include;
  vector<int> include_pos(0);
  int nl_actual=0;
  
  // Read in MAP file: this function also allocates 
  // slots for SNP-major mode

  readMapFile(include,
	      include_pos,
	      nl_actual);
  
  
  
  ///////////////////////////////////////////////
  // .fam
  
  readFamFile(par::lfamfile);
  

  // Allocate space for individual-major mode, set to 
  // missing by default

  if ( ! par::SNP_major)
    {
      for (int i=0; i<sample.size(); i++)
	{
	  sample[i]->one.resize(nl_actual,true);
	  sample[i]->two.resize(nl_actual,false);
	}
    }
  else
    {
      for (int l=0; l<SNP.size(); l++)
	{
	  SNP[l]->one.resize(sample.size(),true);
	  SNP[l]->two.resize(sample.size(),false);
	}
    }

  
  ///////////////////////////////////////////////
  // .lgen
  
  FILE * PED;
  
  PED = fopen64(par::lpedfile.c_str(),"r");
  if ( PED == NULL )
    error("Problem opening LGEN file, errno = "+int2str(errno));
  
  
  // We can now read any number of individual/genotype lines, in any
  // order; we also do not assume that all genotypes are given --
  // these will be missing by default

  map<string,int> imap;
  map<string,int> iperson;

  for (int i=0; i<include.size(); i++)
    {
      if ( include[i] ) 
	{
	  int k = include_pos[i];
	  imap.insert( make_pair ( locus[k]->name , k ) );
	}
    }
  
    for (int i=0; i<sample.size(); i++)
    {
      iperson.insert( make_pair 
		      ( sample[i]->fid + "_" + sample[i]->iid , 
			i ) );
    }


    // Whether or not we want to look at a locus is in the include[] vector
    // The genomic position of locus i is k=include_pos[i] -> locus[k]

    bool fatal = false;
    string fmsg = "";
  
    while( ! feof(PED) )
      {
	
	string fid = "";
	string iid = "";
	string snp = "";
	string one = "";
	string two = "";
	
	int f = 0;
	
	if ( readString( PED , fid ) ) f++;
	
	if ( fid == "" ) 
	  continue;

	if ( readString( PED , iid ) ) f++;
	if ( readString( PED , snp ) ) f++;
	if ( readString( PED , one ) ) f++;
	if ( readString( PED , two ) ) f++;
       	

// 	cout << f << " " << "[" << fid << "] "
// 	     << "[" << iid << "] "
// 	     << "[" << snp << "] "
// 	     << "[" << one << "] "
// 	     << "[" << two << "] \n";

	
	map<string,int>::iterator peri 
	  = iperson.find( fid+"_"+iid );      
	
	Individual * person = 
	  peri != iperson.end() ?
	  sample[peri->second] : NULL ; 
	
	map<string,int>::iterator im = imap.find(snp);
	
	int k = 
	  im != imap.end() ?
	  im->second : -1;
	
	// Ignore this genotype?

	if ( ( ! person ) || k < 0 ) 
	  continue;

	int ip = peri->second;	
	Locus * loc = locus[k];

	/////////////////////////////////////////
	// Add allele names to list, if needed
	
	// If allele is not missing...
	if (one!=par::missing_genotype && two!=par::missing_genotype)
	  {
	    // ...and not already listed
	    if (one!=loc->allele1 && one!=loc->allele2)
	      {
		// ...then add to first empty slot
		if(loc->allele1=="") loc->allele1=one;
		else if(loc->allele2=="") loc->allele2=one;
		else {
		  // .. or show an error if no empty slots
		  if (!fatal)
		    fmsg = "Locus " + 
		      loc->name + " has >2 alleles:\n       individual " 
		      + person->fid + " " + person->iid + " has genotype [ " + one +" "+two+" ]\n"
		      + "       but we've already seen [ " + loc->allele1 + " ] and [ " + loc->allele2 + " ]\n";
		  fatal=true;
		  
		}
	      }
	  }
	      
	// Repeat for second allele, if different
	if (two!=one)
	  {
	    // If allele is not missing...
	    if (one!=par::missing_genotype)
	      // ...and not already listed
	      if (two!=loc->allele1 && two!=loc->allele2)
		{
		  // ...then add to first empty slot
		  if(loc->allele1=="") loc->allele1=two;
		  else if(loc->allele2=="") loc->allele2=two;
		  else {
		    if (!fatal)
		      fmsg = "Locus " + 
			loc->name + " has >2 alleles:\n       individual " 
			+ person->fid + " " + person->iid + " has genotype [ " + one +" "+two+" ]\n"
			+ "       but we've already seen [ " + loc->allele1 + " ] and [ " + loc->allele2 + " ]\n";
		    fatal=true;
		  }
		}
	  }
	      
	
	/////////////////////////////
	// Add specific genotypes
	
	if (par::SNP_major)
	  {
	    
	    // 00 hom
	    if (one==loc->allele1 && two==loc->allele1)
	      {
		SNP[k]->one[ip] = false;
		SNP[k]->two[ip] = false;
	      }
	    
	    
	    // 01 het
	    else if (one!=par::missing_genotype && 
		     two!=par::missing_genotype && 
		     one!=two)	    
	      {
		SNP[k]->one[ip] = false;
		SNP[k]->two[ip] = true;
	      }
	    
	    // 11 hom
	    else if (one==loc->allele2 && two==loc->allele2)
	      {
		SNP[k]->one[ip] = true;
		SNP[k]->two[ip] = true;
	      }
	    
	    // 10 missing
	    else if (one==par::missing_genotype || two==par::missing_genotype)
	      {
		SNP[k]->one[ip] = true;
		SNP[k]->two[ip] = false;
	      }
	  }
	else
	  {
	    
	    // 00 hom
	    if (one==loc->allele1 && two==loc->allele1)
	      {
		person->one[k]=false;
		person->two[k]=false;
	      }
	    
	    
	    // 01 het
	    else if (one!=par::missing_genotype && 
		     two!=par::missing_genotype && 
		     one!=two)	    
	      {
		person->one[k]=false;
		person->two[k]=true;		  
	      }
	    
	    // 11 hom
	    else if (one==loc->allele2 && two==loc->allele2)
	      {
		person->one[k]=true;
		person->two[k]=true;		  
	      }
	    
	    // 10 missing
	    else if (one==par::missing_genotype || two==par::missing_genotype)
	      {
		person->one[k]=true;
		person->two[k]=false;		  
	      }
	  }
      }
    

    
    fclose(PED);
  
}


