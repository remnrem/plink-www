

//////////////////////////////////////////////////////////////////
//                                                              //
//           PLINK (c) 2005-2007 Shaun Purcell                  //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 2.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////


#ifndef __NLIST_H__
#define __NLIST_H__

#include <string>
#include <vector>
#include <iostream>

#include "helper.h"

using namespace std;
class NList{
    
  vector<string> tokenize(string);
  vector<int> expandNumberList(vector<int> &);
  int maxcat;
  bool negmode; // exclude list from 1..maxcat

  string firstWord;
  string lastWord;

 public:

  NList(int n, bool nmode = true)
    { 
      maxcat = n; 
      negmode = ! nmode;
    }

  vector<int> deparseNumberList(string);
  vector<int> deparseStringList(string, map<string,int> *);
  
};

#endif
