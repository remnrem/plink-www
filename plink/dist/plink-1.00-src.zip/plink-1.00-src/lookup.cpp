

//////////////////////////////////////////////////////////////////
//                                                              //
//           PLINK (c) 2005-2006 Shaun Purcell                  //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 2.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////


#include <iostream>
#include <sstream>

#include "plink.h"
#include "helper.h"
#include "options.h"
#include "sockets.h"

using namespace std;

#define  PORT_NUM    8222
#define  IP_ADDR    "155.52.206.11"         // temporary for tedium.dyndns.org

void Plink::lookup()
{

#ifdef SKIP
  printLOG("Web-lookup not implemented on this system...\n");
  return;
#else

  printLOG("PLINK-SNP (WGAS SNP annotation courtesy of Patrick Sullivan)\n");

  vector<string> tokens;
  
  if ( par::lookup_gene)
    {
      string cmd = "GENEWIN "+par::lookup_gene_name + " 250000";
      //string cmd = "GENE "+par::lookup_gene_name;

      tokens = socketConnection( this , 
				 IP_ADDR,
				 PORT_NUM,
				 cmd );

    }
  else if ( par::lookup_single_snp )
    {
      string cmd = "SNPWIN "+par::lookup_snp + " 500000";
      //string cmd = "SNP "+par::lookup_snp;

      tokens = socketConnection( this , 
				 IP_ADDR,
				 PORT_NUM,
				 cmd );      
    }
  else
    {
      string query = "";
      int c = 0;
      // Read list, append to query and send
      checkFileExists(par::lookup_snp);
      ifstream S(par::lookup_snp.c_str(),ios::in);
      while(!S.eof())
	{
	  string snp;
	  S >> snp;
	  if (snp=="")
	    continue;
	  query += "SNP " + snp + " ";
	  c++;
	  if ( c>100 ) 
	    error("Please do not send large batch queries to PLINK-SNP");
	}
      S.close();      

      tokens = socketConnection( this , 
				 IP_ADDR,
				 PORT_NUM,
				 query );      

    }
   
  
  if ( tokens.size() == 0 ) 
    return;

  if ( par::lookup_to_file )
    {

      ofstream OUT;
      string f = par::output_file_name;
      if ( par::lookup_gene ) 
	f += ".snp.list";
      else
	f += ".snp.annot";

      int start = 0;
      
      if ( par::lookup_gene )
	{
	  if ( tokens[0] == "-1") 
	    {
	      printLOG("\n\nCould not find gene " 
		       + par::lookup_gene_name 
		       + " in database\n");
	      return;
	    }
	  
	  printLOG("\n\nFound " 
		   + tokens[0] + " SNPs in " 
		   + par::lookup_gene_name + "\n");
	  start=1;

	  if ( tokens[0] == "0" )
	    return;

	}

      printLOG("\nWriting SNP details to [ " + f + " ]\n");
      
      OUT.open( f.c_str(), ios::out );
      for (int i=start; i<tokens.size(); i++)
	{
	  if (tokens[i]=="\\n")
	    OUT << "\n";
	  else if ( tokens[i]=="\\t")
	    OUT << "\t";
	  else
	    OUT << tokens[i] << " ";	  
	}      
      OUT.close();
    }
  else
    {
      printLOG("\n\n");
      for (int i=0; i<tokens.size(); i++)
	{
	  if (tokens[i]=="\\n")
	    printLOG("\n");
	  else if ( tokens[i]=="\\t")
	    printLOG("\t");
	  else
	    printLOG(tokens[i]+" ");
	}
    }

  return;

#endif

}

