

//////////////////////////////////////////////////////////////////
//                                                              //
//           PLINK (c) 2005-2006 Shaun Purcell                  //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 2.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////


#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <cmath>
#include <algorithm>
#include <errno.h>
#include <stdio.h>
#include <time.h>

#include "helper.h"
#include "crandom.h"
#include "options.h"
#include "plink.h"
#include "perm.h"
#include "dcdflib.h"
#include "ipmpar.h"

#define FPMIN 1.0e-30

extern ofstream LOG;
extern Plink * PP;

template <class T>
bool from_string(T& t, 
                 const std::string& s, 
                 std::ios_base& (*f)(std::ios_base&))
{
  std::istringstream iss(s);
  return !(iss >> f >> t).fail();
}

vector<bool> nvec_bool()
{ 
  vector<bool> t(0);
  return t;
}

inline bool is_rare(Locus * loc) {
  if (loc->freq < 0 
      || loc->freq < par::min_af 
      || (1-loc->freq) < par::min_af)
    return true;
  else
    return false;
};

void display(matrix_t & m) 
{
  if (par::silent) return;
  cout << "\n";
  for (int i=0; i< m.size(); i++)
    {
      cout << i << ")\t";
      for (int j=0; j<m[i].size(); j++)
	cout << m[i][j] << " ";	
      cout << "\n";
    }
  cout << "\n";
}

void display(vector_t & m) 
{
  if (par::silent) return;
  cout << "\n";
  for (int i=0; i< m.size(); i++)
    cout << i << ")\t" << m[i] << "\n";
  cout << "\n";
  cout << "\n";
}

void display(vector<int> & m) 
{
  if (par::silent) return;
  cout << "\n";
  for (int i=0; i< m.size(); i++)
    cout << i << ")\t" << m[i] << "\n";
  cout << "\n";
  cout << "\n";
}


CArgs::CArgs(int _n , char *argv[] )
{
  n = _n;
  a.push_back(argv[0]);
  parsed.resize(n);
  for (int i=0; i<n; i++) parsed[i]=false;
  for (int i=1 ; i < n ; i++ )
    a.push_back(argv[i]);
}


void CArgs::fromScript(string f)
{
  checkFileExists(f);
  ifstream INP(f.c_str());
  string buff;
  
  while( INP >> buff )
    {
      a.push_back(buff);
      parsed.push_back(false);
      n++;
      if (INP.eof()) continue;      
    }
  INP.close();
}

void CArgs::fromPriorLog(string f)
{

  checkFileExists(f);
  ifstream INP(f.c_str());
  string buff;

  // Points to note:
  //  1) check whether any flag has already been given:
  //    if it has, then do not add the flag (i.e. allow
  //    the possibility of over-writing values).  This
  //    will automatically take care of the multiple rerun
  //    issue, and will allow for a different naming, via
  //    the --out command which would be the most common use

  // Read log file up to where commands start

  while (1)
    {
      vector<string> tokens = tokenizeLine(INP);
      
      if ( tokens.size() == 3 &&
	   tokens[0] == "Options" && 
	   tokens[2] == "effect:" )
	break;

      if (INP.eof()) break;      
	    
    }

  while( 1 ) 
    {
      vector<string> tokens = tokenizeLine(INP);

      if ( tokens.size()==0 )
	break;
      
      // Are we over-riding this command / do we 
      // want to skip it? 

      if ( find(tokens[0]) )
	continue;
      
      for (int t=0; t<tokens.size(); t++)
	{
	  a.push_back(tokens[t]);
	  parsed.push_back(false);
	  n++;
	}
      if (INP.eof()) break;      
    }
  INP.close();
}

bool CArgs::find(string s)
{
    for (int i=0 ; i < n ; i++ )
      if (a[i] == s) { parsed[i]=true; return true; }
    return false;
}  

string CArgs::value(string s)
{
  for (int i=0 ; i < n ; i++ )
    if (a[i] == s && (i+1 < n) ) { parsed[i+1]=true; return a[i+1]; }
  error("Missing an argument for "+s);
} 

int CArgs::value_int(string s)
{
  for (int i=0 ; i < n ; i++ )
    if (a[i] == s && (i+1 < n) ) 
      { 
	int x = getInt(a[i+1],s);
	parsed[i+1]=true; 
	return x; 
      }
  error("Missing an argument for "+s); 
} 

double CArgs::value_double(string s)
{
  for (int i=0 ; i < n ; i++ )
    if (a[i] == s && (i+1 < n) ) 
      { 
	double x = getDouble(a[i+1],s);
	parsed[i+1]=true; 
	return x; 
      }
  error("Missing an argument for "+s);
} 

vector<string> CArgs::value(string s, int c)
{
  vector<string> r(0);
  
  for (int i=0 ; i < n ; i++ )
    if (a[i] == s && (i+1 < n) ) 
      {
	for (int j=1;j<=c;j++) 
	  {
	    if ( (i+j) < a.size() )
	      {
		parsed[i+j]=true;
		r.push_back(a[i+j]);
	      }
	    else
	      error("Not enough arguments given for option: "+s+" ");
	  } 
      }

  if (r.size() != c) error("Not enough arguments given for option: "+s+" ");
  return r;
} 

vector<string> parse2str(string s)
{
  vector<string> y;
  string t="";

  for (int i=0 ; i < s.length() ; i++)
    if (s[i] == ',' || i == s.length()-1 )
      {
	if (i == s.length()-1) t += s[i];
	y.push_back(t);
	t = "";
      }
    else
      t += s[i];

  return y;
}

vector<int> parse2int(string s)
{
  vector<string> v = parse2str(s);
  vector<int> y;
  for (int i=0; i<v.size(); i++)
    y.push_back( atoi( v[i].c_str() ) );
  return y;
}

int getInt(string s, string a)
{
  int x;
  if(from_string<int>(x,s,std::dec))
    {
      return x;
    }
  else
    {
      error("Not valid integer argument for : "+a+" [ "+s+" ]");
    }
}

double getDouble(string s, string a)
{
  double x;
  if(from_string<double>(x,s,std::dec))
    {
      return x;
    }
  else
    {
      error("Not valid numeric argument for : "+a+" [ "+s+" ]");
    }

}


void CArgs::check_unused_options(Plink & P)
{
  bool okay = true;
  for (int i=1; i<n; i++)  // argv[0] is command line
    if (!parsed[i]) 
      {
	P.printLOG("** Unused command line option: " + a[i] + " \n");
	okay=false;
      }
  if (!okay) error("Problem parsing the command line arguments.");

  // Otherwise, all is okay, but print a record of the options used to CERR
  // All options always start with "--"
  P.printLOG("Options in effect:");
  for (int i=1; i<n; i++)
    {
      if (a[i].substr(0,2)=="--") P.printLOG("\n\t"+a[i]) ;
      else P.printLOG(" "+a[i]); 
    }
  P.printLOG("\n\n");
}


void checkDupes(Plink & P)
{
  
  set<string> people;
  vector<Individual*>::iterator person = P.sample.begin();
  string errmsg;
  while (person != P.sample.end() )
    {
      string str = (*person)->fid + "_" + (*person)->iid;
      if ( people.find(str) != people.end() )
	errmsg += "Duplicate individual found: [ " + (*person)->fid + " " + (*person)->iid + " ]\n";
      else
	people.insert(str);
      person++;
    }

  if (errmsg.size()>0)
    {
      P.printLOG(" *** WARNING *** DUPLICATE INDIVIDUAL IDS FOUND *** \n");
      P.printLOG(errmsg+"\n");
    }
  people.clear();

  set<string> markers;
  vector<Locus*>::iterator loc = P.locus.begin();
  errmsg="";
  while (loc != P.locus.end() )
    {
      if ( markers.find( (*loc)->name ) != markers.end() )
	errmsg += "Duplicate marker name found: [ " + (*loc)->name + " ]\n";
      else
	markers.insert( (*loc)->name );
      loc++;
    }
  
  if (errmsg.size()>0)
    {
      P.printLOG(" *** WARNING *** DUPLICATE MARKERS FOUND *** \n");
      P.printLOG(errmsg+"\n");
    }
  
  markers.clear();
  
}

void error(string msg)
{
  cerr << "\nERROR: " << msg << "\n";
  LOG << "\nERROR: " << msg << "\n";  
  LOG.close();

  if (par::gplink)
    {
      ofstream GP((par::output_file_name+".gplink").c_str(),ios::out);
      GP << "1\n";
      GP.close();
    }
  
  PP->cleanUp();

  exit(1);
}

void shutdown()
{
  time_t curr=time(0);
  string tdstamp = ctime(&curr);

  if (!par::silent) cout << "\nAnalysis finished: " + tdstamp +"\n";
  LOG << "\nAnalysis finished: " + tdstamp +"\n";

  if (PP->warnings)
    {
      if (!par::silent) cout << "*** One or more WARNINGS were issued (see this LOG file) ***\n";
      LOG << "*** One or more WARNINGS were issued (see this LOG file) ***\n";
    }

  LOG.close();

  if (par::gplink)
    {
      ofstream GP((par::output_file_name+".gplink").c_str(),ios::out);
      GP << "0\n";
      GP.close();
    }
  
  PP->cleanUp();

  exit(0);
}

bool realnum(double d)
{
  double zero = 0;
  if (d != d || d == 1/zero || d == -1/zero) 
    return false;
  else
    return true;
}

void affCoding(Plink & P)
{
  // Create affection coding
  for (int i=0; i<P.n; i++)  
    {
      if ( P.sample[i]->phenotype == 2 ) 
	P.sample[i]->aff = true;      
      else
	P.sample[i]->aff = false;
    }
}

#define MISSING1(i,l) ( P.SNP[l]->one[i] && ( ! P.SNP[l]->two[i] ) ) 
#define MISSING2(i,l) ( P.sample[i]->one[l] && ( ! P.sample[i]->two[l] ) ) 

double genotypingRate(Plink & P, int l)
{

  // Because we do not store genotyping rate, provide this 
  // convenience function; 

  // Do *not* distinguish between obligatory and non-obligatory
  // missingness -- for the purpose of proxy-assoc, it is all the
  // same.

  int m = 0;

  if ( par::SNP_major ) 
    {
      for (int i=0;i<P.sample.size();i++)
	if ( MISSING1(i,l) ) m++;	 
    }  
  else
    {
      for (int i=0;i<P.sample.size();i++)
	if ( MISSING2(i,l) ) m++;	 
    }  
  
  return (double)m / (double)P.n ;
  
}

vector<string> listPossibleHaplotypes(Plink & P, vector<int> S)
{
  
  vector<string> str;  
  unsigned int h=0;
  int ns = S.size();
  int nh = (int)pow((double)2,ns);
  vector<vector<bool> > hap;

  while(h<nh)
    {
      vector<bool> m1;
      
      unsigned int p=1;
      for (int s=0;s<ns;s++)
	{
	  if ( h & p ) m1.push_back(false);
	  else m1.push_back(true);
	  p <<= 1;
	}
      
      // Add to list of haplotypes
      hap.push_back(m1);
      
      // Consider next haplotype
      h++;     

   }

  for (int h=0; h<hap.size(); h++)     
    {
      string hstr;
      for (int s=0;s<ns;s++)
        if (!hap[h][s]) hstr += P.locus[S[s]]->allele1;
        else if (P.locus[S[s]]->allele2=="") hstr += "0";
	else hstr += P.locus[S[s]]->allele2;
      str.push_back(hstr);
    }
  return str;

}


bool readString(FILE * fp, string & s)
{
  
  bool done = false;
  s="";
  while (1)
    {
      char ch = fgetc(fp);
      if ( ch==' ' || ch == '\t' )
	{
	  if (done)
	    return true;
	}
      else if ( ch=='\n' || ch=='\r' || feof(fp) ) 
	{
	  if (done)
	    return true;	  
	  else
	    return false;
	}
      else
	{
	  s += ch;
	  done = true;
	}
    }
}


void removeMissingPhenotypes(Plink & P)
{
  vector<bool> del(P.sample.size());
  for (int i=0; i<P.sample.size(); i++)
    del[i] = P.sample[i]->missing;
  
  int n_removed = P.deleteIndividuals(del);

  if ( n_removed > 0 )
    P.printLOG(int2str(n_removed)+
	       " individuals removed because of missing phenotypes\n");  
}


string genotypeToFile(Plink & P, int i, int l)
{
  
  // Return a genotype in suitable text format to be 
  // written to most output files
  
  string a1 = par::recode_12 ? "1" : P.locus[l]->allele1;
  string a2 = par::recode_12 ? "2" : P.locus[l]->allele2;

  bool s1 = par::SNP_major ? P.SNP[l]->one[i] : P.sample[i]->one[l];
  bool s2 = par::SNP_major ? P.SNP[l]->two[i] : P.sample[i]->two[l];

  if      ( (!s1) && (!s2) )  
    return par::recode_delimit+a1+par::recode_indelimit+a1;
  else if ( (!s1) && s2 ) 
    return par::recode_delimit+a1+par::recode_indelimit+a2;
  else if (  s1   && s2 ) 
    return par::recode_delimit+a2+par::recode_indelimit+a2;
  else 
    return par::recode_delimit + par::missing_genotype
      + par::recode_indelimit+par::missing_genotype;

  return "?";
}


string genotype(Plink & P, int i, int l)
{
  string delimit = "/";
  string g;
  Locus * loc = P.locus[l];

  if (par::SNP_major)
    {
      CSNP * s = P.SNP[l];
      if      ( (!s->one[i]) && (!s->two[i]) )  
	g = loc->allele1 + delimit + loc->allele1;
      else if ( (!s->one[i]) && s->two[i]) 
	g = loc->allele1 + delimit + loc->allele2;
      else if (  s->one[i]   && s->two[i]) 
	g = loc->allele2 + delimit + loc->allele2;
      else g = par::missing_genotype + delimit + par::missing_genotype;
    }
  else
    {
      Individual * person = P.sample[i];

      if      ( (!person->one[l]) && (!person->two[l]) )  
	g = loc->allele1 + delimit + loc->allele1;
      else if ( (!person->one[l]) && person->two[l]) 
	g = loc->allele1 + delimit + loc->allele2;
      else if (  person->one[l]   && person->two[l]) 
	g = loc->allele2 + delimit + loc->allele2;
      else g = par::missing_genotype + delimit + par::missing_genotype;
    }
  return g;
}


string genotype(Plink & P, Individual * person, int l)
{
  string delimit = "/";
  string g;
  Locus * loc = P.locus[l];
  
  if      ( (!person->one[l]) && (!person->two[l]) )  
    g = loc->allele1 + delimit + loc->allele1;
  else if ( (!person->one[l]) && person->two[l]) 
    g = loc->allele1 + delimit + loc->allele2;
  else if (  person->one[l]   && person->two[l]) 
    g = loc->allele2 + delimit + loc->allele2;
  else g = par::missing_genotype + delimit + par::missing_genotype;
  
  return g;
}

void permute(vector<long int> &a)
{
    // generate random permutation of 0..n-1
    // where n is a.size();

    const long int n = a.size( );
    
    for( long int i = 0; i < n; i++ )
        a[ i ] = i;
    
    for( long int j = 1; j < n; j++ )
    {
        long int pos = CRandom::rand(j+1);
        long int tmp = a[ j ];

        a[ j ] = a[ pos ];
        a[ pos ] = tmp;
    }
}


void permute(vector<int> &a)
{
  
  // Generate a random permutation of 0 
  // to n-1 where n is a.size();
  
  const int n = a.size( );
  
  for( int i = 0; i < n; i++ )
    a[ i ] = i;
  
  for( int j = 1; j < n; j++ )
    {
      int pos = CRandom::rand(j+1);
      int tmp = a[ j ];
      
      a[ j ] = a[ pos ];
      a[ pos ] = tmp;
    }
}


long double factorial(int x) {
    int i;
    long double result = 1;
    for (i = 2; i <= x; i++)
        result *= i;
    return result;
}


int getChromosomeCode(string chr)
{

  for (int i=0; i<par::chr_code.size(); i++)
    {
      if ( chr == par::chr_code[i] )
	return i;
    }
  return 0; // unmapped
}

int getMarkerChromosome(Plink & P, string m)
{
  for (int i=0;i<P.locus.size();i++)
    if (P.locus[i]->name==m) return P.locus[i]->chr;
  return -1;
}

int getMarkerNumber(Plink & P, string m)
{
  for (int i=0;i<P.locus.size();i++)
    if (P.locus[i]->name==m) return i;
  return -1;  
}

bool seeChromosome(Plink & P, int c)
{
  for (int l=0;l<P.locus.size();l++)
    {
      if (P.locus[l]->chr==c) 
	return true;
      else if (P.locus[l]->chr>c)
	return false;
    }
  return false;  
}

vector<int> getChromosomeMarkerRange(Plink & P, int c)
{
  vector<int> m(2);
  m[0] = -1; // first
  m[1] = -1; // last
  
  for (int i=0;i<P.locus.size();i++)
    {
      if (P.locus[i]->chr==c) 
	{
	  if (i<=m[0] || m[0]==-1) m[0]=i;
	  if (i>=m[1] || m[1]==-1) m[1]=i;	  
	}      
    }
  return m;  
}

vector<int> getWindowRange(Plink &P, int s)
{
  vector<int> m(2);
  m[0] = s; // first SNP
  m[1] = s; // last SNP
  
  // move backwards
  int x=s;
  int chr=P.locus[s]->chr;
  int bp=P.locus[s]->bp;
  int win = (int)(par::window * 1000); // half window size in bases
  int nl = P.locus.size() - 1;

  while ( 1 ) 
    {
      if ( x==0 ) break;
      // Move one position, until on different chromosome, or outside window
      x--;
      if ( P.locus[x]->chr != chr ) { x++; break; }
      if ( bp - P.locus[x]->bp > win ) { x++; break; }
    }
  m[0]=x;
  x=s;
  while ( 1 ) 
    {
      if ( x== nl ) break;
      x++;
      if ( P.locus[x]->chr != chr ) { x--; break; }
      if ( P.locus[x]->bp - bp > win ) { x--; break; }
    }
  m[1]=x;
  return m;
}

vector<int> getChromosomeRange(Plink & P)
{
  vector<int> m(2);
  m[0] = -1; // first chromosome
  m[1] = -1; // last chromosome
  
  for (int i=0;i<P.locus.size();i++)
    {
      if (P.locus[i]->chr<=m[0] || m[0]==-1) m[0]=P.locus[i]->chr;
      if (P.locus[i]->chr>=m[1] || m[1]==-1) m[1]=P.locus[i]->chr;	  
    }
  return m;  
}

std::string int2str(int n)
{
  std::ostringstream s2( std::stringstream::out );
  s2 << n;
  return s2.str();
}

std::string dbl2str(double n)
{
  std::ostringstream s2;
  s2 << n;
  return s2.str();
}

void NoMem()
{
  cerr << "*****************************************************\n"
       << "* FATAL ERROR    Exhausted system memory            *\n"
       << "*                                                   *\n"
       << "* You need a smaller dataset or a bigger computer...*\n"
       << "*                                                   *\n"
       << "* Forced exit now...                                *\n"
       << "*****************************************************\n\n";
  exit(1);
}

double normdist(double z)
{
 double sqrt2pi = 2.50662827463;
 double t0, z1, p0 ;
 t0 = 1 / (1 + 0.2316419 * fabs(z));
 z1 = exp(-0.5 * z*z ) / sqrt2pi;
 p0 = z1 * t0
    * (0.31938153 +
    t0 * (-0.356563782 +
    t0 * (1.781477937 +
    t0 * (-1.821255978 +
    1.330274429 * t0))));
 return z >= 0 ? 1 - p0 : p0 ;
}

std::string itoa(int value, int base) {
	enum { kMaxDigits = 35 };
	std::string buf;
	buf.reserve( kMaxDigits ); // Pre-allocate enough space.
	
	// check that the base if valid
	if (base < 2 || base > 16) return buf;
	
	int quotient = value;
	
	// Translating number to string with base:
	do {
		buf += "0123456789abcdef"[ std::abs( quotient % base ) ];
		quotient /= base;
	} while ( quotient );
	
	// Append the negative sign for base 10
	if ( value < 0 && base == 10) buf += '-';
	
	std::reverse( buf.begin(), buf.end() );
	return buf;	
}

void checkFileExists(string f)
{

  ifstream inp;
  
  inp.open(f.c_str(), ifstream::in);
  if(inp.fail())
    {
      inp.clear(ios::failbit);
      inp.close();
      string msg = "No file [ " + f + " ] exists.";
      error(msg);
    }
  inp.close();
  return;

}


vector<string> tokenizeLine(ifstream & F1)
{
  char cline[par::MAX_LINE_LENGTH];
  F1.getline(cline,par::MAX_LINE_LENGTH,'\n');
  string sline = cline;
  string buf; 
  stringstream ss(sline); 
  vector<string> tokens; 
  while (ss >> buf)
    tokens.push_back(buf);
  return tokens;
}


double chiprobP(double x, double df)
{

  if ( ! realnum(x) ) return -9;

  double p, q;
  int st = 0; // error variable
  int w = 1; // function variable
  double bnd = 1; // boundary function

  // NCP is set to 0
  cdfchi(&w,&p,&q,&x,&df,&st,&bnd);

  // Check status
  if (st != 0 ) return -9;

  // Return p-value
  return q;


//   double zero = 0;
//   if (x<0 || x != x || x == -1/zero || x == 1/zero ) return -9;
//   else if (x==0) return 1;
//   else if (x>500) return 0;
  
//   double df2 = df/2;
//   double x2 = x/2;
//   return 1-gammp(df2, x2);
  
}

double inverse_chiprob(double q, double df)
{

  if ( ! realnum(q) ) return -9;
  else if (q>=1) return 0;

  double x;
  double p = 1 - q;
  int st = 0; // error variable
  int w = 2; // function variable
  double bnd = 1; // boundary function

  // NCP is set to 0
  cdfchi(&w,&p,&q,&x,&df,&st,&bnd);

  // Check status
  if (st != 0 ) return -9;

  // Return p-value
  return x;
  
}


double gammp(double a, double x)
{
  double gamser, gammcf, gln;
                                                                                           
  if (x<0 || a<=0) error("Invalid arguments in routine gammp");
  if (x < (a+1))
    {
      gser(&gamser,a,x,&gln);
      return gamser;
    } else
      {
        gcf(&gammcf,a,x,&gln);
        return 1-gammcf;
      }
}

#define ITMAX 100
#define CHIEPS 3.0e-7

void gser(double *gamser, double a, double x, double *gln)
{

  int n;
  double sum, del, ap;
                                                                                           
  *gln = gammln(a);
  if(x<=0)
    {
      if (x<0) error("x less than 0 in routine gser");
      *gamser=0;
      return;
    } else
      {
        ap = a;
        del=sum=1/a;
        for (n=1; n<=ITMAX; n++)
          {
            ++ap;
            del *= x/ap;
            sum += del;
            if (fabs(del)<fabs(sum)*CHIEPS)
              {
                *gamser=sum*exp(-x+a*log(x)-(*gln));
                return;
              }
          }
        error("a too large, ITMAX too small in routine gser");
        return;
      }
}

void gcf(double *gammcf, double a, double x, double *gln)
{
  double gammln(double xx);
  int i;
  double an, b, c, d, del, h;
                                                                                           
  *gln=gammln(a);
  b=x+1-a;
  c=1/FPMIN;
  d=1/b;
  h=d;
  for (i=1; i<=ITMAX; i++)
    {
      an = -i*(i-a);
      b += 2;
      d = an*d+b;
      if (fabs(d) < FPMIN) d=FPMIN;
      c=b+an/c;
      if (fabs(c) < FPMIN) c=FPMIN;
      d=1/d;
      del=d*c;
      h*=del;
      if (fabs(del-1) < CHIEPS) break;
    }
  if (i > ITMAX) error("a too large, ITMAX too small in gcf");
  *gammcf=exp(-x+a*log(x)-(*gln))*h;
}

double gammln(double xx)
{
  double x, y, tmp, ser;
  static double cof[6]={76.18009172947146, -86.50532032941677,
                        24.01409824083091, -1.231739572450155,
                        0.1208650973866179e-2, -0.5395239384953e-5};
  int j;
 
  y=x=xx;
  tmp=x+5.5;
  tmp -= (x+0.5)*log(tmp);
  ser=1.000000000190015;
  for (j=0; j<=5; j++) ser += cof[j]/++y;
  return -tmp+log(2.5066282746310005*ser/x);
}


// Inverse normal distribution

/*
 * Lower tail quantile for standard normal distribution function.
 *
 * This function returns an approximation of the inverse cumulative
 * standard normal distribution function.  I.e., given P, it returns
 * an approximation to the X satisfying P = Pr{Z <= X} where Z is a
 * random variable from the standard normal distribution.
 *
 * The algorithm uses a minimax approximation by rational functions
 * and the result has a relative error whose absolute value is less
 * than 1.15e-9.
 *
 * Author:      Peter J. Acklam
 * Time-stamp:  2002-06-09 18:45:44 +0200
 * E-mail:      jacklam@math.uio.no
 * WWW URL:     http://www.math.uio.no/~jacklam
 *
 * C implementation adapted from Peter's Perl version
 */


/* Coefficients in rational approximations. */

static const double a[] =
  {
    -3.969683028665376e+01,
    2.209460984245205e+02,
    -2.759285104469687e+02,
    1.383577518672690e+02,
    -3.066479806614716e+01,
     2.506628277459239e+00
  };

static const double b[] =
  {
    -5.447609879822406e+01,
    1.615858368580409e+02,
    -1.556989798598866e+02,
    6.680131188771972e+01,
    -1.328068155288572e+01
  };

static const double c[] =
  {
    -7.784894002430293e-03,
    -3.223964580411365e-01,
    -2.400758277161838e+00,
    -2.549732539343734e+00,
    4.374664141464968e+00,
     2.938163982698783e+00
  };

static const double d[] =
  {
    7.784695709041462e-03,
    3.224671290700398e-01,
    2.445134137142996e+00,
    3.754408661907416e+00
  };

#define LOW 0.02425
#define HIGH 0.97575

double ltqnorm(double p)
{
  double q, r;

  errno = 0;

  if (p < 0 || p > 1)
    {
      errno = EDOM;
      return 0.0;
    }
  else if (p == 0)
    {
      errno = ERANGE;
      return -HUGE_VAL /* minus "infinity" */;
    }
  else if (p == 1)
    {
      errno = ERANGE;
      return HUGE_VAL /* "infinity" */;
    }
  else if (p < LOW)
    {
      /* Rational approximation for lower region */
      q = sqrt(-2*log(p));
      return (((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) /
	((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1);
    }
  else if (p > HIGH)
    {
      /* Rational approximation for upper region */
      q  = sqrt(-2*log(1-p));
      return -(((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) /
	((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1);
    }
  else
    {
      /* Rational approximation for central region */
      q = p - 0.5;
      r = q*q;
      return (((((a[0]*r+a[1])*r+a[2])*r+a[3])*r+a[4])*r+a[5])*q /
	(((((b[0]*r+b[1])*r+b[2])*r+b[3])*r+b[4])*r+1);
    }
}

double pT(double T, double df)
{

  if ( ! realnum(T) ) 
    return -9; 

  T = abs(T);
  
  double p, q;
  int st = 0;      // error variable
  int w = 1;       // function variable
  double bnd = 1;  // boundary function

  // NCP is set to 0
  cdft(&w,&p,&q,&T,&df,&st,&bnd);
  
  // Check status
  if (st != 0 ) return -9;
  
  // Return two-sided p-value
  return 2*q;
  
  // Old NR routine
//  double p = betai(0.5*df,0.5,df/(df+T*T)); 
//  if ( p <= 1e-20 ) p = 1e-20;
//  else if (p>=1) p=1;
//  return p;
  
}

double pF(const double F, const int df1, const int df2)
{
  return betai(0.5*df2,0.5*df1,(double)df2/(double)(df2+df1*F));
}


double betai(const double a, const double b, const double x)
{
  double bt;
  
  if (x < 0.0 || x > 1.0) error("Internal error: bad x in routine betai");
  if (x == 0.0 || x == 1.0) bt=0.0;
  else
    bt=exp(gammln(a+b)-gammln(a)-gammln(b)+a*log(x)+b*log(1.0-x));
  if (x < (a+1.0)/(a+b+2.0))
    return bt*betacf(a,b,x)/a;
  else
    return 1.0-bt*betacf(b,a,1.0-x)/b;
}


double betacf(const double a, const double b, const double x)
{
  const int MAXIT = 100;
  const double EPS = 3e-7;

  int m,m2;
  double aa,c,d,del,h,qab,qam,qap;
  
  qab=a+b;
  qap=a+1.0;
  qam=a-1.0;
  c=1.0;
  d=1.0-qab*x/qap;
  if (fabs(d) < FPMIN) d=FPMIN;
  d=1.0/d;
  h=d;
  for (m=1;m<=MAXIT;m++) {
    m2=2*m;
    aa=m*(b-m)*x/((qam+m2)*(a+m2));
    d=1.0+aa*d;
    if (fabs(d) < FPMIN) d=FPMIN;
    c=1.0+aa/c;
    if (fabs(c) < FPMIN) c=FPMIN;
    d=1.0/d;
    h *= d*c;
    aa = -(a+m)*(qab+m)*x/((a+m2)*(qap+m2));
    d=1.0+aa*d;
    if (fabs(d) < FPMIN) d=FPMIN;
    c=1.0+aa/c;
    if (fabs(c) < FPMIN) c=FPMIN;
    d=1.0/d;
    del=d*c;
    h *= del;
    if (fabs(del-1.0) <= EPS) break;
  }
  if (m > MAXIT) error("Internal error in betacf() function (please report)");
  return h;
}


bool Plink::obligMissing(int i, int l)
{
  int2 p;
  p.p1 = l;
  p.p2 = sample[i]->sol; 
  return ( oblig_missing.find(p) != oblig_missing.end() );
}


bool Plink::missingGenotype(int i, int l)
{  
  bool s1 = par::SNP_major ? SNP[l]->one[i] : sample[i]->one[l];
  bool s2 = par::SNP_major ? SNP[l]->two[i] : sample[i]->two[l];
  return ( s1 && ! s2 );
}


void Plink::prettyPrintLengths()
{

  par::pp_maxfid = 4;
  par::pp_maxiid = 4;
  par::pp_maxsnp = 4;
  
  for (int i=0;i<n;i++)
    {
      if (sample[i]->fid.length() > par::pp_maxfid)
	par::pp_maxfid = sample[i]->fid.length() + 2;

      if (sample[i]->iid.length() > par::pp_maxiid)
	par::pp_maxiid = sample[i]->iid.length() + 2;
    }	  
  

  for (int l=0;l<nl_all;l++)
    if (locus[l]->name.length() > par::pp_maxsnp)
      par::pp_maxsnp = locus[l]->name.length() + 2;
  
}


vector< vector<double> > inverse(vector< vector<double> > & m )
{
  double d;
  int i, j;
  
  if (m.size() == 0) error("Internal error: matrix with no rows (inverse function)");
  if (m.size() != m[0].size() ) error("Internal error: cannot invert non-square matrix");
  int n = m.size();

  // indx is an integer array
  vector<int> indx(n);

  vector<double> col(n);
  vector<vector<double> > y(n);
  for (int i=0; i<n; i++) y[i].resize(n); 
  vector<vector<double> > tm;
  tm = m;
  
  ludcmp(tm,indx,d);
  
  for (j=0; j<n; j++)
    {
      for (i=0; i<n; i++) col[i]=0;
      col[j]=1;
      lubksb(tm,indx,col);
      for (i=0; i<n; i++) y[i][j]=col[i];
    }
  
  return y;
  
}


vector<double> eigenvalues(vector<vector<double> > & a)
{

  // 'a' should be a square, symmetric matrix
  int n=a.size();
  vector<double> e(n);
  vector<double> d(n);
  tred2(a,d,e);
  vector<vector<double> > z; // dummy
  tqli(d,e,z);
  return d;
}

// Householder method to reduce real, symmetric matrix
// to tridiagonal form
// Modified to return only eigenvalues.
void tred2(vector<vector<double> > & a,
	   vector<double> & d,
	   vector<double> &e)
{
  int l,k,j,i;
  double scale,hh,h,g,f;

  int n=d.size();
  for (i=n-1;i>0;i--) {
    l=i-1;
    h=scale=0.0;
    if (l > 0) {
      for (k=0;k<l+1;k++)
	scale += fabs(a[i][k]);
      if (scale == 0.0)
	e[i]=a[i][l];
      else {
	for (k=0;k<l+1;k++) {
	  a[i][k] /= scale;
	  h += a[i][k]*a[i][k];
	}
	f=a[i][l];
	g=(f >= 0.0 ? -sqrt(h) : sqrt(h));
	e[i]=scale*g;
	h -= f*g;
	a[i][l]=f-g;
	f=0.0;
	for (j=0;j<l+1;j++) {
	  // Next statement can be omitted if eigenvectors not wanted
// 	  a[j][i]=a[i][j]/h;
	  g=0.0;
	  for (k=0;k<j+1;k++)
	    g += a[j][k]*a[i][k];
	  for (k=j+1;k<l+1;k++)
	    g += a[k][j]*a[i][k];
	  e[j]=g/h;
	  f += e[j]*a[i][j];
	}
	hh=f/(h+h);
	for (j=0;j<l+1;j++) {
	  f=a[i][j];
	  e[j]=g=e[j]-hh*f;
	  for (k=0;k<j+1;k++)
	    a[j][k] -= (f*e[k]+g*a[i][k]);
	}
      }
    } else
      e[i]=a[i][l];
    d[i]=h;
  }
  // Next statement can be omitted if eigenvectors not wanted
//   d[0]=0.0;
  e[0]=0.0;
  // Contents of this loop can be omitted if eigenvectors not
  //	wanted except for statement d[i]=a[i][i];
  for (i=0;i<n;i++) {
//     l=i;
//     if (d[i] != 0.0) {
//       for (j=0;j<l;j++) {
// 	g=0.0;
// 	for (k=0;k<l;k++)
// 	  g += a[i][k]*a[k][j];
// 	for (k=0;k<l;k++)
// 	  a[k][j] -= g*a[k][i];
//       }
//     }
    d[i]=a[i][i];
//     a[i][i]=1.0;
//     for (j=0;j<l;j++) a[j][i]=a[i][j]=0.0;
  }
}

// Modified to return only eigenvalues.
void tqli(vector<double> &d, vector<double>&e, 
	  vector<vector<double> > &z)
{
  int m,l,iter,i,k;
  double s,r,p,g,f,dd,c,b;
  double volatile temp;
  int n=d.size();
  for (i=1;i<n;i++) e[i-1]=e[i];
  e[n-1]=0.0;
  for (l=0;l<n;l++) {
    iter=0;
    do {
      for (m=l;m<n-1;m++) {
	dd=fabs(d[m])+fabs(d[m+1]);
	temp=fabs(e[m])+dd;
	if (temp == dd) break;
      }
      if (m != l) {
	if (iter++ == 30) error("Internal problem in tqli routine");
	g=(d[l+1]-d[l])/(2.0*e[l]);
	r=pythag(g,1.0);
	g=d[m]-d[l]+e[l]/(g+SIGN(r,g));
	s=c=1.0;
	p=0.0;
	for (i=m-1;i>=l;i--) {
	  f=s*e[i];
	  b=c*e[i];
	  e[i+1]=(r=pythag(f,g));
	  if (r == 0.0) {
	    d[i+1] -= p;
	    e[m]=0.0;
	    break;
	  }
	  s=f/r;
	  c=g/r;
	  g=d[i+1]-p;
	  r=(d[i]-g)*s+2.0*c*b;
	  d[i+1]=g+(p=s*r);
	  g=c*r-b;
	  // Next loop can be omitted if eigenvectors not wanted
	  /* for (k=0;k<n;k++) {
	     f=z[k][i+1];
	     z[k][i+1]=s*z[k][i]+c*f;
	     z[k][i]=c*z[k][i]-s*f;
	     } */
	}
	if (r == 0.0 && i >= l) continue;
	d[l] -= p;
	e[l]=g;
	e[m]=0.0;
      }
    } while (m != l);
  }
}



//////////////////////////////////////////////////
// As above, but with eigenvectors returned also

Eigen eigenvectors(vector<vector<double> > & a)
{
  // 'a' should be a square, symmetric matrix
  int n=a.size();

  Eigen E;
  E.set(n);

  vector<double> e(n,0);
  EV_tred2(a,E.d,e);
  EV_tqli(E.d,e,a);
  E.z = a;
  return E;
}


// Householder method to reduce real, symmetric matrix
// to tridiagonal form
// Modified to return both eigenvalues and eigenvectors
void EV_tred2(vector<vector<double> > & a,
              vector<double> & d,
              vector<double> &e)
{
  int l,k,j,i;
  double scale,hh,h,g,f;

  int n=d.size();
  for (i=n-1;i>0;i--) {
    l=i-1;
    h=scale=0.0;
    if (l > 0) {
      for (k=0;k<l+1;k++)
        scale += fabs(a[i][k]);
      if (scale == 0.0)
        e[i]=a[i][l];
      else {
        for (k=0;k<l+1;k++) {
          a[i][k] /= scale;
          h += a[i][k]*a[i][k];
        }
        f=a[i][l];
        g=(f >= 0.0 ? -sqrt(h) : sqrt(h));
        e[i]=scale*g;
        h -= f*g;
        a[i][l]=f-g;
        f=0.0;
        for (j=0;j<l+1;j++) {
          a[j][i]=a[i][j]/h;
          g=0.0;
          for (k=0;k<j+1;k++)
            g += a[j][k]*a[i][k];
          for (k=j+1;k<l+1;k++)
            g += a[k][j]*a[i][k];
          e[j]=g/h;
          f += e[j]*a[i][j];
        }
        hh=f/(h+h);
        for (j=0;j<l+1;j++) {
          f=a[i][j];
          e[j]=g=e[j]-hh*f;
          for (k=0;k<j+1;k++)
            a[j][k] -= (f*e[k]+g*a[i][k]);
        }
      }
    } else
      e[i]=a[i][l];
    d[i]=h;
  }

  d[0]=0.0;
  e[0]=0.0;

  for (i=0;i<n;i++) {
    l=i;
    if (d[i] != 0.0) {
      for (j=0;j<l;j++) {
        g=0.0;
        for (k=0;k<l;k++)
          g += a[i][k]*a[k][j];
        for (k=0;k<l;k++)
          a[k][j] -= g*a[k][i];
      }
    }
    d[i]=a[i][i];
    a[i][i]=1.0;
    for (j=0;j<l;j++) a[j][i]=a[i][j]=0.0;
  }
}

// Modified to return eigenvalues and eigenvectors
void EV_tqli(vector<double> &d, vector<double>&e,
             vector<vector<double> > &z)
{
  int m,l,iter,i,k;
  double s,r,p,g,f,dd,c,b;

  int n=d.size();
  for (i=1;i<n;i++) e[i-1]=e[i];
  e[n-1]=0.0;
  for (l=0;l<n;l++) {
    iter=0;
    do {
      for (m=l;m<n-1;m++) {
	dd=fabs(d[m])+fabs(d[m+1]);
	if (fabs(e[m])+dd == dd) break;
      }
      if (m != l) {
	if (iter++ == 30) error("Internal problem in tqli routine");
	g=(d[l+1]-d[l])/(2.0*e[l]);
	r=pythag(g,1.0);
	g=d[m]-d[l]+e[l]/(g+SIGN(r,g));
	s=c=1.0;
	p=0.0;
	for (i=m-1;i>=l;i--) {
	  f=s*e[i];
	  b=c*e[i];
	  e[i+1]=(r=pythag(f,g));
	  if (r == 0.0) {
	    d[i+1] -= p;
	    e[m]=0.0;
	    break;
	  }
	  s=f/r;
	  c=g/r;
	  g=d[i+1]-p;
	  r=(d[i]-g)*s+2.0*c*b;
	  d[i+1]=g+(p=s*r);
	  g=c*r-b;

	  for (k=0;k<n;k++) {
	    f=z[k][i+1];
	    z[k][i+1]=s*z[k][i]+c*f;
	    z[k][i]=c*z[k][i]-s*f;
	  }
	}
	if (r == 0.0 && i >= l) continue;
	d[l] -= p;
	e[l]=g;
	e[m]=0.0;
      }
    } while (m != l);
  }
}

/////////////////////////


// Romberg integration


double qromb(double func(const double), double a, double b)
{
        const int JMAX=20, JMAXP=JMAX+1, K=5;
        const double EPS=1.0e-10;
        double ss,dss;
        vector_t s(JMAX),h(JMAXP),s_t(K),h_t(K);
        int i,j;

        h[0]=1.0;
        for (j=1;j<=JMAX;j++) {
                s[j-1]=trapzd(func,a,b,j);
                if (j >= K) {
                        for (i=0;i<K;i++) {
                                h_t[i]=h[j-K+i];
                                s_t[i]=s[j-K+i];
                        }
                        polint(h_t,s_t,0.0,ss,dss);
                        if (fabs(dss) <= EPS*fabs(ss)) return ss;
                }
                h[j]=0.25*h[j-1];
        }
        error("Internal error: too many steps in routine qromb");
        return 0.0;
}

void polint(vector_t &xa, vector_t &ya, const double x, double &y, double &dy)
{
        int i,m,ns=0;
        double den,dif,dift,ho,hp,w;

        int n=xa.size();
        vector_t c(n),d(n);
        dif=fabs(x-xa[0]);
        for (i=0;i<n;i++) {
                if ((dift=fabs(x-xa[i])) < dif) {
                        ns=i;
                        dif=dift;
                }
                c[i]=ya[i];
                d[i]=ya[i];
        }
        y=ya[ns--];
        for (m=1;m<n;m++) {
                for (i=0;i<n-m;i++) {
                        ho=xa[i]-x;
                        hp=xa[i+m]-x;
                        w=c[i+1]-d[i];
                        if ((den=ho-hp) == 0.0) error("Error in routine polint");
                        den=w/den;
                        d[i]=hp*den;
                        c[i]=ho*den;
                }
                y += (dy=(2*(ns+1) < (n-m) ? c[ns+1] : d[ns--]));
        }

}

double trapzd(double func(const double), const double a, const double b, const int n)
{
        double x,tnm,sum,del;
        static double s;
        int it,j;

        if (n == 1) {
                return (s=0.5*(b-a)*(func(a)+func(b)));
        } else {
                for (it=1,j=1;j<n-1;j++) it <<= 1;
                tnm=it;
                del=(b-a)/tnm;
                x=a+0.5*del;
                for (sum=0.0,j=0;j<it;j++,x+=del) sum += func(x);
                s=0.5*(s+(b-a)*sum/tnm);
                return s;
        }

}


/////////////////////////

void svdvar(vector<vector<double> > & v,
	    vector<double> & w,
	    vector<vector<double> > & cvm)
{
  int i,j,k;
  double sum;
   
  int ma=w.size();
  vector<double> wti(ma);
  for (i=0;i<ma;i++) {
    wti[i]=0.0;
    if (w[i] != 0.0) wti[i]=1.0/(w[i]*w[i]);
  }
  for (i=0;i<ma;i++) {
    for (j=0;j<i+1;j++) {
      sum=0.0;
      for (k=0;k<ma;k++)
	sum += v[i][k]*v[j][k]*wti[k];
      cvm[j][i]=cvm[i][j]=sum;
    }
  }
}

void svbksb(vector<vector<double> > &u,
	    vector<double> &w,
	    vector<vector<double> > &v,
	    vector<double> &b, 
	    vector<double> &x)
{
  int jj,j,i;
  double s;
 
  int m=u.size();
  int n=u[0].size();
  vector<double> tmp(n);
  for (j=0;j<n;j++) {
    s=0.0;
    if (w[j] != 0.0) {
      for (i=0;i<m;i++) s += u[i][j]*b[i];
      s /= w[j];
    }
    tmp[j]=s;
  }
  for (j=0;j<n;j++) {
    s=0.0;
    for (jj=0;jj<n;jj++) s += v[j][jj]*tmp[jj]; 
    x[j]=s;
  }

}


vector<bool> vif_prune(vector<vector<double> > m , double threshold)
{
  
  // Number of variables
  int p = m.size();

  vector<bool> cur(p,true);
  
  // This only is needed if we have 2+ SNPs
  if (p<2) { 
    return cur;
  }

  vector<vector<double> > r = m;
  
  // Make 'm' a correlation matrix
  for (int i=0; i<p; i++)
    for (int j=0; j<p; j++)
      r[i][j] = m[i][j] / sqrt(m[i][i] * m[j][j]);

  // Number of excluded items
  int it = 0;
  
  
  // Any SNPs with zero variance should be automatically excluded
  for (int i=0; i<p; i++)
    if ( r[i][i] == 0 || !realnum(r[i][i]) )
      {
	cur[i] = false;
	it++;
      }
  
  // For any pair of perfectly correlated SNPs, exclude 1
  while(1)
    {
      
      bool done = true;
      for (int i=0; i<p-1; i++)
	{
	  if (cur[i]){
	    for (int j=i+1;j<p; j++)
	      {
		if (cur[j]) {
		  if ( fabs(r[i][j]) > par::prune_ld_r2 )
		    {
		      cur[i] = false;
		      it++;
		      done = false;
		      break;
		    }
		}
	      }
	  }
	}
      if (done) break;
    }
  
  // Skip VIF calculation?
  if (par::prune_ld_pairwise)
    return cur;

  // Calculate r^2 for each element versus all others
  // considering only the current non-pruned elements
  
  while (1)
    {
      
      // Build correlation matrix all included items
      vector<vector<double> > u;
      
      for (int i=0;i<p;i++)
	{
	  if ( cur[i] )
	    {
	      vector<double> mt;
	      
	      for (int j=0;j<p;j++)
		if ( cur[j] )
		  mt.push_back(r[i][j]);
	      
	      u.push_back(mt);
	    }
	}
      

      // Check enough markers left  
      if (u.size()<2) break;
      
      if (par::verbose)
	{
	  cout <<  " about to invert\n";
	  cout.precision(12);
	  for (int i=0; i<u.size(); i++)
	    {
	      for (int j=0; j<u[i].size(); j++)
		cout << u[i][j] << " ";
	      cout << "\n";
	      
	    }
	}
      
      // Get inverse
      u = svd_inverse(u);

      
      // Calculate VIFs
      double maxVIF = 0;
      int maxI;
      int cnt=0;
      for (int i=0;i<p;i++)
	if ( cur[i] )
	  {
	    
	    // r^2 = 1 - 1/x where x is diagonal element of inverted
	    // correlation matrix
	    // As VIF = 1 / ( 1 - r^2 ) , implies VIF = x

	    double vif = u[cnt][cnt];
	    
	    if ( maxVIF < vif )
	      {
		maxVIF = vif;
		maxI = i;
	      }
	    
	    cnt++;
	  }

      // How are we doing?
      if ( maxVIF > threshold ) 
	{
	  // exclude this item
	  cur[maxI] = false;	  
	}
      else
	{
	  break;
	}
      
      // Increase count of removed items
      it++;
      
      // Down to a single item or worse?
      if (it==p-1) break;
      
    }

  return cur;

}



void calcSetMeanVariance(vector<CSNP*> & pSNP,
			 vector<double> & mean,
			 vector<vector<double> > & variance,
			 vector<Individual*> & sample)
{

  int flagged_n = 0;

  int nss = pSNP.size();

  if (nss<1) 
    return;
  
  mean.resize(nss,0);

  vector<int> cnt(nss,0);
  variance.resize(nss);

  for (int j=0; j<nss; j++)
    variance[j].resize(nss,0);

  
  ////////////////////////////
  // Iterate over SNPs in SET
  
  vector<CSNP*>::iterator ps = pSNP.begin();
  int j=0;
  while ( ps != pSNP.end() )
    {
      
      ///////////////////////////
      // Iterate over individuals
      
      vector<Individual*>::iterator person = sample.begin();
      vector<bool>::iterator i1 = (*ps)->one.begin();
      vector<bool>::iterator i2 = (*ps)->two.begin();
            
      while ( person != sample.end() )
	{
	  
	  // Include this person in the calculation?
	  if (!(*person)->flag) 
	    {
	    person++;
	    i1++;
	    i2++;
	    continue;
	  }
	  
	  // Increase general, flagged sample size
	  // (only count once)
	  if (j==0)
	    flagged_n++;
	  
	  if ( *i1 )
	    {		      
	      if ( *i2 ) // 11 homozygote
		{
		  mean[j]++;
		  cnt[j]++;
		}
	    }
	  else 
	    {
	      cnt[j]++;
	      if ( ! *i2  ) // 00 homozygote
		mean[j]--;
	
	    }
	  
	  
	  // Next individual
	  person++;
	  i1++;
	  i2++;
	  
	  
	}
      
      // Next SNP in set
      ps++;
      j++;
      
    }
    
  
  // Having iterated over all individuals, we can now calculate the
  // mean values, perform mean-substitution of missing data, and
  // calculate the second order terms
  
  for (int j=0; j<nss; j++)
    {
      mean[j] /= (double)cnt[j];
    }
  
  
  /////////////////////////////////////
  // Iterate over pairs of SNPs in SET
  
  // First SNP 
  vector<CSNP*>::iterator ps1 = pSNP.begin();
  int j1=0;
  while ( ps1 != pSNP.end() )
    {
      
      // Second SNP
      vector<CSNP*>::iterator ps2 = ps1;
      int j2=j1;
      while ( ps2 != pSNP.end() )
	{
	  
	  ///////////////////////////
	  // Iterate over individuals
	  
	  vector<Individual*>::iterator person = sample.begin();
	  vector<bool>::iterator i1_1 = (*ps1)->one.begin();
	  vector<bool>::iterator i2_1 = (*ps1)->two.begin();
	  
	  vector<bool>::iterator i1_2 = (*ps2)->one.begin();
	  vector<bool>::iterator i2_2 = (*ps2)->two.begin();
	  
	  while ( person != sample.end() )
	    {
	      
	      // Include this person in the calculation?
	      if (!(*person)->flag) 
		{
		  person++;
		  i1_1++;
		  i2_1++;
		  i1_2++;
		  i2_2++;
		  continue;
		}


	      // Mean substitution
	      double v1=mean[j1], v2=mean[j2];
	      	      
	      // First SNP
	      if ( *i1_1 )
		{		      
		  if ( *i2_1 )    // 11 homozygote
		    {
		      v1 = 1;
		    }
		}
	      else 
		{
		  if ( ! *i2_1  ) // 00 homozygote
		    {
		      v1 = -1;
		    }
		  else
		    v1 = 0;       // 01 heterozygote
		}
	      
	      
	      // First SNP
	      if ( *i1_2 )
		{		      
		  if ( *i2_2 )    // 11 homozygote
		    {
		      v2 = 1;
		    }
		}
	      else 
		{
		  if ( ! *i2_2  ) // 00 homozygote
		    {
		      v2 = -1;
		    }
		  else
		    v2 = 0;       // 01 heterozygote
		}
	      
	      
	      // Contribution to covariance term
	      // Mean subsitution
	      variance[j1][j2] += ( v1 - mean[j1] ) * ( v2 - mean[j2] );
	    	    
	    		

	      // Next individual
	      person++;
	      i1_1++;
	      i2_1++;
	      i1_2++;
	      i2_2++;
	    }
	  
	  // Next second SNP
	  ps2++;
	  j2++;
	}
      
      // Next first SNP
      ps1++;
      j1++;
      
    }
  
  // Make symmetric covariance matrix

  for (int i=0; i<nss; i++)
    for (int j=i; j<nss; j++)
      {
	variance[i][j] /= (double)(flagged_n);
	variance[j][i] = variance[i][j];
      }

  return;
}



void svd(matrix_t & u, vector_t &w, matrix_t &v)
{
  const double eps = 1e-12;
  
  if (u.size() == 0) 
    error("Internal problem: matrix with no rows (inverse function)");
  if (u.size() != u[0].size() ) 
    error("Internal problem: Cannot invert non-square matrix");
  int n = u.size();
  
  if ( w.size() != n)
    error("Internal error: problem in SVD\n");
  
  if ( v.size() != n)
    error("Internal error: problem in SVD\n");
  
  svdcmp(u,w,v); 
  
  // Look for singular values
//   double wmax = 0;
//   for (int i=0; i<n; i++)
//     wmax = w[i] > wmax ? w[i] : wmax;
//   double wmin = wmax * eps;
//   for (int i=0; i<n; i++)
//     {
//       w[i] = w[i] < wmin ? 0 : 1/w[i];
//     }  
}

vector< vector<double> > svd_inverse(vector< vector<double> > & u )
{

  //  const double eps = 1e-12;
  const double eps = 1e-24; 
  
  if (u.size() == 0) 
    error("Internal problem: matrix with no rows (inverse function)");
  if (u.size() != u[0].size() ) 
    error("Internal problem: Cannot invert non-square matrix");
  int n = u.size();
  
  vector<double> w(n,0);
  
  vector<vector<double> > v(n);
  for (int i=0; i<n; i++) 
    v[i].resize(n,0);

  svdcmp(u,w,v); 
  
  // Look for singular values
  double wmax = 0;
  for (int i=0; i<n; i++)
    wmax = w[i] > wmax ? w[i] : wmax;
  double wmin = wmax * eps;
  for (int i=0; i<n; i++)
    {
      w[i] = w[i] < wmin ? 0 : 1/w[i];
    }
  

  // u w t(v)

  // row U * 1/w
  vector<vector<double> > r(n);
  for (int i=0; i<n; i++)
    {
      r[i].resize(n,0);
      for (int j=0; j<n; j++)
	u[i][j] = u[i][j] * w[j];
    }

  // [nxn].[t(v)] 
  for (int i=0; i<n; i++)
    for (int j=0; j<n; j++)
      for (int k=0; k<n; k++)
	r[i][j] += u[i][k] * v[j][k];
    
  return r;
}



// Matrix square root function

vector<vector<double> > msqrt(vector<vector<double> > & u)
{
  
  // Using SVD, square root is U . sqrt(D) . V_T

  //  msqrt <- function(m) {
  //  m <- svd(m)
  //  m$u %*% sqrt(diag(m$d)) %*% t(m$v) }

  const double eps = 1e-12;
  
  int n = u.size();
  vector<double> d(n,0);
  vector<vector<double> > v(n);
  for (int i=0; i<n; i++) 
    v[i].resize(n,0);
  
  svdcmp(u,d,v); 
  
  // Take square root of diagonal values
  for (int i=0; i<n; i++)
    d[i] = sqrt(d[i]);
  
  // Multiple to reconstruct original
  
  vector<vector<double> > r(n);
  for (int i=0; i<n; i++) 
    r[i].resize(n,0);
  
  vector<vector<double> > r2 = r;
  
  for (int i=0; i<n; i++) 
    for (int j=0; j<n; j++)     
      r[i][j] = u[i][j] * d[j];
  
  for (int i=0; i<n; i++) 
    for (int j=0; j<n; j++)     
      for (int k=0; k<n; k++)
	r2[i][j] += r[i][k] * v[j][k];
  
  return r2;
  
}



void ludcmp(vector<vector<double> > &a, vector<int> &indx, double &d)
{
  int i, imax = 0, j, k;
  double big, dum, sum, temp;
  int n = a.size();
  vector<double> vv(n);
  d=1;

  for (i=0; i<n; i++)
    {
      big=0;
      for (j=0; j<n; j++)
	if ((temp=fabs(a[i][j])) > big) big=temp;
      if (big==0) error("singular matrix in ludcmp");
      vv[i]=1/big;
    }
  
  for (j=0; j<n; j++)
    {
      for (i=0; i<j; i++)
	{
	  sum = a[i][j];
	  for (k=0; k<i; k++) sum -= a[i][k] * a[k][j];
	  a[i][j]=sum;
	}
      big=0;
      for (i=j; i<n; i++)
	{
	  sum=a[i][j];
	  for (k=0; k<j; k++)
	    sum -= a[i][k] * a[k][j];
	  a[i][j]=sum;
	  if ((dum=vv[i]*fabs(sum)) >= big)
	    {
	      big = dum;
	      imax = i;
	    }
	}
      if (j != imax)
	{
	  for (k=0; k<n; k++)
	    {
	      dum=a[imax][k];
	      a[imax][k]=a[j][k];
	      a[j][k]=dum;
	    }
	  d = -d;
	  vv[imax]=vv[j];
	}
      indx[j]=imax;
      if (a[j][j] == 0) a[j][j] = 1.0e-20;

      if (j != n-1)
	{
	  dum = 1/(a[j][j]);
	  for (i=j+1; i<n; i++) a[i][j] *= dum;
	}
    }
}

void lubksb(vector<vector<double> > &a, vector<int> &indx, vector<double> &b)
{

  int i, ii=0, ip, j;
  double sum;

  int n = a.size();

  for (i=0; i<n; i++)
    {
      ip=indx[i];
      sum=b[ip];
      b[ip]=b[i];
      if (ii != 0)
	for (j=ii-1; j<i; j++) sum -= a[i][j]*b[j];
      else if (sum != 0.0) ii=i+1;
      b[i]=sum;
    }
  for (i=n-1; i>=0; i--)
    {
      sum=b[i];
      for (j=i+1; j<n; j++) sum -= a[i][j]*b[j];
      b[i]=sum/a[i][i];
    }
}


void svdcmp(vector<vector<double> > & a, 
	    vector<double> & w, 
	    vector<vector<double> > &v)
{
  bool flag;
  int i,its,j,jj,k,l,nm;
  double anorm,c,f,g,h,s,scale,x,y,z;
  double volatile temp;

  int m=a.size();
  if (m==0) error("Internal problem in SVD function (no observations left?)");
  int n=a[0].size();

  vector<double> rv1(n);
  g=scale=anorm=0.0;
  for (i=0;i<n;i++) {
    l=i+2;
    rv1[i]=scale*g;
    g=s=scale=0.0;
    if (i < m) {
      for (k=i;k<m;k++) scale += fabs(a[k][i]);
      if (scale != 0.0) {
	for (k=i;k<m;k++) {
	  a[k][i] /= scale;
	  s += a[k][i]*a[k][i];
	}
	f=a[i][i];
	g = -SIGN(sqrt(s),f);
	h=f*g-s;
	a[i][i]=f-g;
	for (j=l-1;j<n;j++) {
	  for (s=0.0,k=i;k<m;k++) s += a[k][i]*a[k][j];
	  f=s/h;
	  for (k=i;k<m;k++) a[k][j] += f*a[k][i];
	}
	for (k=i;k<m;k++) a[k][i] *= scale;
      }
    }
    w[i]=scale *g;
    g=s=scale=0.0;
    if (i+1 <= m && i+1 != n) {
      for (k=l-1;k<n;k++) scale += fabs(a[i][k]);
      if (scale != 0.0) {
	for (k=l-1;k<n;k++) {
	  a[i][k] /= scale;
	  s += a[i][k]*a[i][k];
	}
	f=a[i][l-1];
	g = -SIGN(sqrt(s),f);
	h=f*g-s;
	a[i][l-1]=f-g;
	for (k=l-1;k<n;k++) rv1[k]=a[i][k]/h;
	for (j=l-1;j<m;j++) {
	  for (s=0.0,k=l-1;k<n;k++) s += a[j][k]*a[i][k];
	  for (k=l-1;k<n;k++) a[j][k] += s*rv1[k];
	}
	for (k=l-1;k<n;k++) a[i][k] *= scale;
      }
    }
    anorm=MAX(anorm,(fabs(w[i])+fabs(rv1[i])));
  }
  for (i=n-1;i>=0;i--) {
    if (i < n-1) {
      if (g != 0.0) {
	for (j=l;j<n;j++)
	  v[j][i]=(a[i][j]/a[i][l])/g;
	for (j=l;j<n;j++) {
	  for (s=0.0,k=l;k<n;k++) s += a[i][k]*v[k][j];
	  for (k=l;k<n;k++) v[k][j] += s*v[k][i];
	}
      }
      for (j=l;j<n;j++) v[i][j]=v[j][i]=0.0;
    }
    v[i][i]=1.0;
    g=rv1[i];
    l=i;
  }
  for (i=MIN(m,n)-1;i>=0;i--) {
    l=i+1;
    g=w[i];
    for (j=l;j<n;j++) a[i][j]=0.0;
    if (g != 0.0) {
      g=1.0/g;
      for (j=l;j<n;j++) {
	for (s=0.0,k=l;k<m;k++) s += a[k][i]*a[k][j];
	f=(s/a[i][i])*g;
	for (k=i;k<m;k++) a[k][j] += f*a[k][i];
      }
      for (j=i;j<m;j++) a[j][i] *= g;
    } else for (j=i;j<m;j++) a[j][i]=0.0;
    ++a[i][i];
  }
  for (k=n-1;k>=0;k--) {
    for (its=0;its<30;its++) {
      flag=true;
      for (l=k;l>=0;l--) {
	nm=l-1;
	temp=fabs(rv1[l])+anorm;
	if (temp == anorm) {
	  flag=false;
	  break;
	}
	temp=fabs(w[nm])+anorm;
	if (temp == anorm) break;
      }
      if (flag) {
	c=0.0;
	s=1.0;
	for (i=l;i<k+1;i++) {
	  f=s*rv1[i];
	  rv1[i]=c*rv1[i];
	  temp = fabs(f)+anorm;
	  if (temp == anorm) break;
	  g=w[i];
	  h=pythag(f,g);
	  w[i]=h;
	  h=1.0/h;
	  c=g*h;
	  s = -f*h;
	  for (j=0;j<m;j++) {
	    y=a[j][nm];
	    z=a[j][i];
	    a[j][nm]=y*c+z*s;
	    a[j][i]=z*c-y*s;
	  }
	}
      }
      z=w[k];
      if (l == k) {
	if (z < 0.0) {
	  w[k] = -z;
	  for (j=0;j<n;j++) v[j][k] = -v[j][k];
	}
	break;
      }
      if (its == 29) error("SVD function cannot converge: multicollinearity issues?");
      x=w[l];
      nm=k-1;
      y=w[nm];
      g=rv1[nm];
      h=rv1[k];
      f=((y-z)*(y+z)+(g-h)*(g+h))/(2.0*h*y);
      g=pythag(f,1.0);
      f=((x-z)*(x+z)+h*((y/(f+SIGN(g,f)))-h))/x;
      c=s=1.0;
      for (j=l;j<=nm;j++) {
	i=j+1;
	g=rv1[i];
	y=w[i];
	h=s*g;
	g=c*g;
	z=pythag(f,h);
	rv1[j]=z;
	c=f/z;
	s=h/z;
	f=x*c+g*s;
	g=g*c-x*s;
	h=y*s;
	y *= c;
	for (jj=0;jj<n;jj++) {
	  x=v[jj][j];
	  z=v[jj][i];
	  v[jj][j]=x*c+z*s;
	  v[jj][i]=z*c-x*s;
	}
	z=pythag(f,h);
	w[j]=z;
	if (z) {
	  z=1.0/z;
	  c=f*z;
	  s=h*z;
	}
	f=c*g+s*y;
	x=c*y-s*g;
	for (jj=0;jj<m;jj++) {
	  y=a[jj][j];
	  z=a[jj][i];
	  a[jj][j]=y*c+z*s;
	  a[jj][i]=z*c-y*s;
	}
      }
      rv1[l]=0.0;
      rv1[k]=f;
      w[k]=x;
    }
  }
}


double pythag(const double a, const double b)
{
  double absa,absb;
 
  absa=fabs(a);
  absb=fabs(b);
  if (absa > absb) return absa*sqrt(1.0+SQR(absb/absa));
  else return (absb == 0.0 ? 0.0 : absb*sqrt(1.0+SQR(absa/absb)));
}

double SQR(double a)
{
  return a*a;
}


string leftWindowEdge(Plink & P, int chr, int bp)
{
  // Get nearest SNP 
  Locus * marker = NULL;
  int distance = -1;
    
  vector<Locus*>::iterator loc = P.locus.begin();
  while ( loc != P.locus.end() )
    {
      if ( (*loc)->chr == chr) 
	if ( (*loc)->bp >= bp )
	  if ( (*loc)->bp - bp < distance || ! marker )
	    {
	      distance =  (*loc)->bp - bp;
	      marker = *loc;
	    }
      loc++;
    }

  if (!marker) 
    error("Could not place marker for left window edge");

  return marker->name;  

}


string rightWindowEdge(Plink & P, int chr, int bp)
{

  // Get nearest SNP 
  Locus * marker = NULL;
  int distance = -1;
  
  vector<Locus*>::iterator loc = P.locus.begin();
  while ( loc != P.locus.end() )
    {
      if ( (*loc)->chr == chr) 
	if ( (*loc)->bp <= bp )
	  if ( bp - (*loc)->bp < distance || ! marker )
	    {
	      distance =  bp - (*loc)->bp;
	      marker = *loc;
	    }
      loc++;
    }

  if (!marker) 
    error("Could not place marker for right window edge");

  return marker->name;  
}


void Plink::setMarkerRange()
{

  // If chromosome code >0, implies a specific chromosome
  if (par::run_chr>0 && !par::position_window)
    {
      // Get first and last markers on this chromosome
      vector<int> m = getChromosomeMarkerRange((*this),par::run_chr);
      if(m[0]==-1 || m[1]==-1) error("--chr {chromosome} not found:"+int2str(par::run_chr));
      par::run_start = m[0];
      par::run_end = m[1];
    }
  else if (par::position_window)
    {
      // Physical position specified (chromosome and range)
      par::m1 = leftWindowEdge(*this, par::run_chr, par::from_window);
      par::m2 = rightWindowEdge(*this, par::run_chr, par::to_window);
      par::run_start = getMarkerNumber( (*this), par::m1 );
      par::run_end = getMarkerNumber( (*this), par::m2 );	
    }
  else
    {
      // Two SNPs specified (or a SNP and a range)

      // If a specific range on one chromosome is specified
      par::run_start = getMarkerNumber((*this),par::m1);
      par::run_end = getMarkerNumber((*this),par::m2);
      
      if (par::run_start==-1) error("--from {marker} not found");
      if (par::run_end==-1) error("--to {marker} not found");    

      // Do we require a window around a specific SNP?
      if ( par::run_start == par::run_end && par::window > 0 )
	{
	  vector<int> m = getWindowRange( *this , par::run_start ); 
	  par::run_start = m[0];
	  par::run_end = m[1];
	}

  
      if (getMarkerChromosome((*this),par::m1) != getMarkerChromosome((*this),par::m2))
	{
	  string msg = "--from {marker} and --to {marker} must lie on same chromosome";
	  msg += "\nwhereas these lie on chromosomes "+int2str(getMarkerChromosome((*this),par::m1));	
	  msg += " and "+int2str(getMarkerChromosome((*this),par::m2));
	  error(msg);
	}
    }

  // Get order right
  if (par::run_start > par::run_end)
    {
      int tmp = par::run_start;
      par::run_start = par::run_end;
      par::run_end = tmp;
    }

  int ccode = locus[par::run_start]->chr;
  printLOG("Scan region on chromosome " + int2str(ccode)
	   + " from [ " + locus[par::run_start]->name 
	   + " ] to [ " + locus[par::run_end]->name 
	   + " ]\n");
  
}



void defineHorseChromosomes()
{

  // 31 autosomes + X + Y + etc

  par::chr_haploid.resize(31 + 2 + 1 );
  par::chr_sex.resize(31 + 2 + 1 );
  par::chr_Y.resize(31 + 2 + 1 );
  par::chr_code.resize(31 + 2 + 1 );

  for (int i=0; i<=31; i++)
    {
      par::chr_haploid[i] = par::chr_sex[i] = par::chr_Y[i] = false;
      par::chr_code[i] = int2str(i);
    }

  par::chr_sex[32] = true;
  par::chr_haploid[32] = false;
  par::chr_Y[32] = false;
  par::chr_code[32] = "X";
  
  par::chr_sex[33] = false;
  par::chr_haploid[33] = true;
  par::chr_Y[33] = true;
  par::chr_code[33] = "Y";
}

void defineDogChromosomes()
{

  // 38 autosomes + X + Y + XY + 0 missing code

  par::chr_haploid.resize(38 + 3 + 1 );
  par::chr_sex.resize(38 + 3 + 1 );
  par::chr_Y.resize(38 + 3 + 1 );
  par::chr_code.resize(38 + 3 + 1 );

  for (int i=0; i<=38; i++)
    {
      par::chr_haploid[i] = par::chr_sex[i] = par::chr_Y[i] = false;
      par::chr_code[i] = int2str(i);
    }

  par::chr_sex[39] = true;
  par::chr_haploid[39] = false;
  par::chr_Y[39] = false;
  par::chr_code[39] = "X";

  par::chr_sex[40] = false;
  par::chr_haploid[40] = true;
  par::chr_Y[40] = true;
  par::chr_code[40] = "Y";

  par::chr_sex[41] = false;
  par::chr_haploid[41] = false;
  par::chr_Y[41] = false;
  par::chr_code[41] = "XY";

  
}

void defineCowChromosomes()
{

  // 29 autosomes + X + Y + 0 missing code

  par::chr_haploid.resize(29 + 2 + 1 );
  par::chr_sex.resize(29 + 2 + 1 );
  par::chr_Y.resize(29 + 2 + 1 );
  par::chr_code.resize(29 + 2 + 1 );

  for (int i=0; i<=29; i++)
    {
      par::chr_haploid[i] = par::chr_sex[i] = par::chr_Y[i] = false;
      par::chr_code[i] =  int2str(i);
    }

  par::chr_sex[30] = true;
  par::chr_haploid[30] = false;
  par::chr_Y[30] = false;
  par::chr_code[30] = "X";
  
  par::chr_sex[31] = false;
  par::chr_haploid[31] = true;
  par::chr_Y[31] = true;
  par::chr_code[31] = "Y";

}

void defineHumanChromosomes()
{

  // 22 autosomes + X + Y + XY + M + 0 missing code

  par::chr_haploid.resize( 22 + 2 + 2 + 1 );
  par::chr_sex.resize(22 + 2 + 2 + 1 );
  par::chr_Y.resize(22 + 2 + 2 + 1 );
  par::chr_code.resize(22 + 2 + 2 + 1 );
  
  for (int i=0; i<=22; i++)
    {
      par::chr_haploid[i] = par::chr_sex[i] = par::chr_Y[i] = false;
      par::chr_code[i] =  int2str(i);
    }

  // X chromosome
  par::chr_sex[23] = true;
  par::chr_haploid[23] = false;
  par::chr_Y[23] = false;
  par::chr_code[23] = "X";
  
  // Y chromosome
  par::chr_sex[24] = false;
  par::chr_haploid[24] = true;
  par::chr_Y[24] = true;
  par::chr_code[24] = "Y";
  
  // XY chromosome
  par::chr_sex[25] = false;
  par::chr_haploid[25] = false;
  par::chr_Y[25] = false;
  par::chr_code[25] = "XY";

  // MT chromosome
  par::chr_sex[26] = false;
  par::chr_haploid[26] = true;
  par::chr_Y[26] = false;  
  par::chr_code[26] = "MT";

}

void sizeMatrix(matrix_t & m , int r, int c)
{
  m.clear();
  m.resize(r);
  for (int i=0; i<r; i++)
    m[i].resize(c,0);
}

void sizeTable(table_t & m , int r, int c)
{
  m.clear();
  m.resize(r);
  for (int i=0; i<r; i++)
    m[i].resize(c,0);
}

void multMatrix(vector<vector<double> > & a,
		vector<vector<double> > & b,
		vector<vector<double> > & c)
{

  int ar = a.size();
  int br = b.size();
  if (ar == 0 || br == 0)
    error("Internal error: multiplying 0-sized matrices");
  
  int ac = a[0].size();
  int bc = b[0].size();
  if ( ac != br )
    error("Internal error: non-conformable matrices in multMatrix()"); 
  
  int cr = ar;
  int cc = bc;

  c.clear();
  sizeMatrix(c,cr,cc);
  
  for (int i=0; i<ar; i++)
    for (int j=0; j<bc; j++)
      for (int k=0; k<ac; k++)
	c[i][j] += a[i][k] * b[k][j];

}


/*
// This function implements an exact SNP test of Hardy-Weinberg
// Equilibrium as described in Wigginton, JE, Cutler, DJ, and
// Abecasis, GR (2005) A Note on Exact Tests of Hardy-Weinberg
// Equilibrium. American Journal of Human Genetics. 76: 000 - 000
//
// Written by Jan Wigginton
*/

double SNPHWE(int obs_hets, int obs_hom1, int obs_hom2)
{
  
  if (obs_hom1 + obs_hom2 + obs_hets == 0 ) return 1;
  
  if (obs_hom1 < 0 || obs_hom2 < 0 || obs_hets < 0) 
    {
      error("Internal error: negative count in HWE test: "
	    +int2str(obs_hets)+" "
	    +int2str(obs_hom1)+" "
	    +int2str(obs_hom2));
    }

  int obs_homc = obs_hom1 < obs_hom2 ? obs_hom2 : obs_hom1;
  int obs_homr = obs_hom1 < obs_hom2 ? obs_hom1 : obs_hom2;

  int rare_copies = 2 * obs_homr + obs_hets;
  int genotypes   = obs_hets + obs_homc + obs_homr;

  double * het_probs = (double *) malloc((size_t) (rare_copies + 1) * sizeof(double));
  if (het_probs == NULL) 
    error("Internal error: SNP-HWE: Unable to allocate array" );
  
  int i;
  for (i = 0; i <= rare_copies; i++)
    het_probs[i] = 0.0;

  /* start at midpoint */
  int mid = rare_copies * (2 * genotypes - rare_copies) / (2 * genotypes);
  
  /* check to ensure that midpoint and rare alleles have same parity */
  if ((rare_copies & 1) ^ (mid & 1))
    mid++;
  
  int curr_hets = mid;
  int curr_homr = (rare_copies - mid) / 2;
  int curr_homc = genotypes - curr_hets - curr_homr;

  het_probs[mid] = 1.0;
  double sum = het_probs[mid];
  for (curr_hets = mid; curr_hets > 1; curr_hets -= 2)
    {
      het_probs[curr_hets - 2] = het_probs[curr_hets] * curr_hets * (curr_hets - 1.0)
	/ (4.0 * (curr_homr + 1.0) * (curr_homc + 1.0));
      sum += het_probs[curr_hets - 2];

      /* 2 fewer heterozygotes for next iteration -> add one rare, one common homozygote */
      curr_homr++;
      curr_homc++;
    }

  curr_hets = mid;
  curr_homr = (rare_copies - mid) / 2;
  curr_homc = genotypes - curr_hets - curr_homr;
  for (curr_hets = mid; curr_hets <= rare_copies - 2; curr_hets += 2)
    {
      het_probs[curr_hets + 2] = het_probs[curr_hets] * 4.0 * curr_homr * curr_homc
	/((curr_hets + 2.0) * (curr_hets + 1.0));
      sum += het_probs[curr_hets + 2];
      
      /* add 2 heterozygotes for next iteration -> subtract one rare, one common homozygote */
      curr_homr--;
      curr_homc--;
    }
  
  for (i = 0; i <= rare_copies; i++)
    het_probs[i] /= sum;

  /* alternate p-value calculation for p_hi/p_lo
   double p_hi = het_probs[obs_hets];
   for (i = obs_hets + 1; i <= rare_copies; i++)
     p_hi += het_probs[i];
   
   double p_lo = het_probs[obs_hets];
   for (i = obs_hets - 1; i >= 0; i--)
      p_lo += het_probs[i];
   
   double p_hi_lo = p_hi < p_lo ? 2.0 * p_hi : 2.0 * p_lo;
  */

  double p_hwe = 0.0;
  /*  p-value calculation for p_hwe  */
  for (i = 0; i <= rare_copies; i++)
    {
      if (het_probs[i] > het_probs[obs_hets])
	continue;
      p_hwe += het_probs[i];
    }
   
  p_hwe = p_hwe > 1.0 ? 1.0 : p_hwe;

  free(het_probs);

  return p_hwe;
}




// Convert dataset from Individual-major format to SNP-major

void Plink::Ind2SNP()
{
  printLOG("Converting data to SNP-major format\n");

  SNP.clear();
  
  vector<Individual*>::iterator person = sample.begin();
  
  // Initialise SNP positions per person
  while ( person != sample.end() )
    {
      (*person)->i1 = (*person)->one.end()-1;
      (*person)->i2 = (*person)->two.end()-1;
      person++;
    }
  
  // Copy, per SNP
  int l = 0;
  while ( l < nl_all  )
    {
 
      CSNP * newlocus = new CSNP;
      
      person = sample.begin();
       
      while ( person != sample.end() )
	{
	  // Add genotype to SNP-major storage
	  newlocus->one.push_back( *((*person)->i1) );
	  newlocus->two.push_back( *((*person)->i2) );
	  
	  // Shift one SNP back
	  (*person)->i1--;
	  (*person)->i2--;

	  // Remove individual-major storage
	  (*person)->one.pop_back();
	  (*person)->two.pop_back();
	  
	  // Advance to next person
	  person++;
	}
            
      // And add this new SNP to the main list
      SNP.push_back(newlocus);
      
      // Next SNP
      l++;
    }
 
  // We finally need to reverse the order of these 
  reverse(SNP.begin(), SNP.end());

  par::SNP_major = true;
}

// Convert dataset from SNP-major format to Individual-major
void Plink::SNP2Ind()
{
  
  printLOG("Converting data to Individual-major format\n");
    
  vector<Individual*>::iterator person = sample.begin();
  
  // Make sure these containers are empty
  while ( person != sample.end() )
    {
      (*person)->one.clear();
      (*person)->two.clear();
      person++;
    }
  
  ///////////////////////////////
  // Iterate over SNPs
  
  vector<CSNP*>::iterator s = SNP.begin();
 
  while ( s != SNP.end() )
    {
            
      /////////////////////////////
      // Iterate over individuals
      
      vector<bool>::iterator i1 = (*s)->one.begin();
      vector<bool>::iterator i2 = (*s)->two.begin();
      vector<Individual*>::iterator person = sample.begin();
      
      while ( person != sample.end() )
	{
	  
	  // Add SNP alleles
	  (*person)->one.push_back(*i1);
	  (*person)->two.push_back(*i2);
	  
 	  // Shift one SNP back
 	  i1++;
 	  i2++;
	  	  
 	  // Advance to next person
 	  person++;
 	}
      
      // For this SNP, remove SNP-major storage completely
      delete (*s);
      
      // Next SNP
      s++;      
    }
  
  SNP.clear();
  par::SNP_major = false;
}


 int Plink::deleteSNPs(vector<bool> & del)
 {
  
   
   // Remove SNPs that have T in vector 'del'
   // We expect this vector to be same length
   // current number of SNPs
   
   int original = SNP.size();


   //////////////////////////////////////////////
   // SNP-major mode

   if (par::SNP_major)
     {
       
       vector<CSNP*>::iterator s1 = SNP.begin();
       vector<CSNP*>::iterator s2 = SNP.begin();
       
       vector<bool>::iterator d = del.begin();
       int i = 0;
       while ( s1 != SNP.end() ) 
	 {
	   //cout << "i = " << i++ << "\n";
	   // Keep this SNP?
	   if ( ! *d ) 
	     {
	       *s2 = *s1;
	       s2++;
	     }
	   else
	     {
	       delete (*s1);
	     }

	   s1++;
	   d++;
	 }
       
       // Then erase the remaining SNPs
       SNP.erase(s2,SNP.end());
       
     }
  else
    {
      // Individual major-mode
      // copy remaining SNPs to a new list
  
      vector<Individual*>::iterator person = sample.begin();
      while ( person != sample.end() )
	{
	  
	  // Set individual iterator at start of SNP list
	  vector<bool>::iterator one1 = (*person)->one.begin();
	  vector<bool>::iterator two1 = (*person)->two.begin();

	  vector<bool>::iterator one2 = (*person)->one.begin();
	  vector<bool>::iterator two2 = (*person)->two.begin();

	  vector<bool>::iterator d = del.begin();

	  
	  while ( one1 != (*person)->one.end() )
	    {
	      
	      // Keep this marker
	      if ( ! * d ) 
		{  
		  *one2 = *one1;
		  *two2 = *two1;
		  
		  // Advance next saved SNP
		  one2++;
		  two2++;
		}

	      // Advance to next to-be-checked SNP
	      one1++;
	      two1++;
	      d++;
	    }
	  
	  // Then erase the remaining SNPs
	  (*person)->one.erase(one2,(*person)->one.end());
	  (*person)->two.erase(two2,(*person)->two.end());
	  
	  // Next individual
	  person++;	  
	}
    }

   
   ///////////////////////////////////////////////////
   // Second, remove deleted SNPs from the locus list

   vector<Locus*>::iterator loc1 = locus.begin();
   vector<Locus*>::iterator loc2 = locus.begin();
   vector<bool>::iterator d = del.begin();

   while ( loc1 != locus.end() )
     {    
       
       // Should we keep this SNP?
       if ( ! *d )
	 {
	   *loc2 = *loc1;
	   loc2++;
	 }
       else
	 delete (*loc1);

       loc1++;
       d++;
       
     }
       

   // Then erase the remaining SNPs
   // and the storage
   locus.erase(loc2,locus.end());

   // Keep track of the number of SNPs remaining
   nl_all = locus.size();
   
   // Return the number of SNPs we chucked
   return original - nl_all;

}




int Plink::deleteIndividuals(vector<bool> & del)
{


  // Remove SNPs that have T in vector 'del'
  // We expect this vector to be same length
  // current number of SNPs
  
  int original = sample.size();
  
  //////////////////////////////////////////////
  // SNP-major mode
  
  if (par::SNP_major)
    {
      
      // Erase genotype data (SNP-major order)
      // Consider each SNP in outer loop
      vector<CSNP*>::iterator s = SNP.begin();
      while ( s != SNP.end() )
	{ 
	  
	  vector<bool>::iterator one1 = (*s)->one.begin();
	  vector<bool>::iterator two1 = (*s)->two.begin();
	  
	  vector<bool>::iterator one2 = (*s)->one.begin();
	  vector<bool>::iterator two2 = (*s)->two.begin();
	  
	  vector<bool>::iterator d = del.begin();

	  // Consider each person
	  while ( one1 != (*s)->one.end() )
	    {
	      
	      // Keep this individual?
	      if ( ! *d ) 
		{
		  (*one2) = (*one1);
		  (*two2) = (*two1);

		  one2++;
		  two2++;
		}
	      
	      one1++;
	      two1++;
	      d++;
	    }
	 	  
	  // Erase old storage
	  (*s)->one.erase(one2,(*s)->one.end());
	  (*s)->two.erase(two2,(*s)->two.end());

	  // Next SNP
	  s++;
	}
    }

  /////////////////////////////////////////////
  // Whether SNP-major or individual-major
  // we still need to take care of the sample[]
  
  vector<Individual*>::iterator person1 = sample.begin();
  vector<Individual*>::iterator person2 = sample.begin();
  
  vector<bool>::iterator d = del.begin();
  
  while ( person1 != sample.end() )
    {
      // Keep this person
      if ( ! * d ) 
	{  
	  *person2 = *person1;
	  
	  // Advance next saved SNP
	  person2++;
	}
      else
	{
	  // Free storage
	  delete (*person1);	  
	}
      
      // Advance to next to-be-checked SNP
      person1++;
      d++;
    }
  
  // Erase pointers at end of vector
  sample.erase(person2,sample.end());
  
  // Adjust sample statistics
  n = sample.size();
  np = (int)((double)(n*(n-1))/(double)2);  
  
  return original - n; 
}



void Plink::filterOnCovariate()
{

  printLOG("Filtering individuals based on [ "+par::filter_filename+" ]\n");
  printLOG("Filtering criterion is [ " + int2str(par::filter_value) 
	   + " ] for covariate " + int2str(par::mult_filter) +"\n");

  // Swap q-match filename as covariate file
  string tmp_covar_file = par::covar_filename;
  int tmp_mult_covar = par::mult_covar;
  par::covar_filename = par::filter_filename;
  par::mult_covar = par::mult_filter;
  
  if (!readCovariateFile())
    error("Problem reading filter file [ " + par::filter_filename + " ]\n");

  // Put back the original covariate specificiation

  par::covar_filename = tmp_covar_file;
  par::mult_covar = tmp_mult_covar;
  

  // Screen-based on covariate
  // vector to record which individuals to be deleted
  
  vector<bool> indel(sample.size(),false);
  int n_removed1=0;
  for (int i=0; i<sample.size(); i++)
    {
      if ( (int)sample[i]->covar != par::filter_value )
	{
	  indel[i] = true;
	  n_removed1++;
	}
    }
  
  // And now remove these individuals, so that 
  // SNP-based statistics are calculated with 
  // these samples already excluded
  
  int n_removed = deleteIndividuals(indel);
  
  if (n_removed != n_removed1)
    error("Internal problem in filterOnCovariate, please contact SMP\n");
  printLOG(int2str(n_removed)+" individuals removed based on filter\n");
  
}



void Plink::filterOnCase()
{
  printLOG("Filtering cases only ... ");

  // Remove controls, missing
  vector<bool> indel(sample.size(),false);
  for (int i=0; i<sample.size(); i++)
    if ( (!sample[i]->aff) || sample[i]->missing ) 
      indel[i] = true;

  int n_original = sample.size();
  int n_removed = deleteIndividuals(indel);
  printLOG(int2str(n_original-n_removed)+" individuals remaining\n");
  
  // Reset number of individuals
  n = sample.size();
  np = (int)((double)(n*(n-1))/(double)2);
  
}

void Plink::filterOnControl()
{
  printLOG("Filtering controls only ... ");

  // Remove cases, missing
  vector<bool> indel(sample.size(),false);
  for (int i=0; i<sample.size(); i++)
    if ( sample[i]->aff || sample[i]->missing ) 
      indel[i] = true;

  int n_original = sample.size();  
  int n_removed = deleteIndividuals(indel);
  printLOG(int2str(n_original-n_removed)+" individuals remaining\n");
  
  // Reset number of individuals
  n = sample.size();
  np = (int)((double)(n*(n-1))/(double)2);
  
}

void Plink::filterOnMale()
{
  printLOG("Filtering males only ... ");
  
  vector<bool> indel(sample.size(),false);
  for (int i=0; i<sample.size(); i++)
    if ( sample[i]->sexcode != "1" )
      indel[i] = true;

  int n_original = sample.size();  
  int n_removed = deleteIndividuals(indel);
  printLOG(int2str(n_original-n_removed)+" individuals remaining\n");
  
  // Reset number of individuals
  n = sample.size();
  np = (int)((double)(n*(n-1))/(double)2);
  
}

void Plink::filterOnFemale()
{
  printLOG("Filtering females only ... ");
  
  vector<bool> indel(sample.size(),false);
  for (int i=0; i<sample.size(); i++)
    if ( sample[i]->sexcode != "2" )
      indel[i] = true;
  
  int n_original = sample.size();
  int n_removed = deleteIndividuals(indel);
  printLOG(int2str(n_original-n_removed)+" individuals remaining\n");
  
  // Reset number of individuals
  n = sample.size();
  np = (int)((double)(n*(n-1))/(double)2);
  
}

void Plink::filterOnFounder()
{
  printLOG("Filtering founders only ... ");
  
  vector<bool> indel(sample.size(),false);
  for (int i=0; i<sample.size(); i++)
    if ( ! sample[i]->founder )
      indel[i] = true;
  
  int n_original = sample.size();
  int n_removed = deleteIndividuals(indel);
  printLOG(int2str(n_original-n_removed)+" individuals remaining\n");
  
  // Reset number of individuals
  n = sample.size();
  np = (int)((double)(n*(n-1))/(double)2);
  
}

void Plink::filterOnNonFounder()
{
  printLOG("Filtering nonfounders only ... ");
  
  vector<bool> indel(sample.size(),false);
  for (int i=0; i<sample.size(); i++)
    if ( sample[i]->founder )
      indel[i] = true;
  
  int n_original = sample.size();
  int n_removed = deleteIndividuals(indel);
  printLOG(int2str(n_original-n_removed)+" individuals remaining\n");
  
  // Reset number of individuals
  n = sample.size();
  np = (int)((double)(n*(n-1))/(double)2);
  
}



void Plink::dummyLoader()
{

  // Create dummy dataset full of heterozygotes

  int L = par::dummy_nsnp;
  int N = par::dummy_nind;

  for (int l=0;l<L;l++)
    {
      Locus * loc = new Locus;
      loc->name = "snp"+int2str(l);
      loc->chr = 1;
      loc->allele1 = "A";
      loc->allele2 = "B";
      loc->bp = l ; 
      loc->pos = 0;

      locus.push_back(loc);

      CSNP * newset = new CSNP;

      newset->one.resize(N);
      newset->two.resize(N);

      for ( int i = 0 ; i < N ; i++ ) 
	{
	  
	  int g = 0;
	  if (CRandom::rand() > 0.5)
	    g++;
	  if (CRandom::rand() > 0.5)
	    g++;
	  
	  if ( g == 0 ) 
	    {
	      newset->one[i] = false;
	      newset->two[i] = false;
	    }
	  else if ( g == 1 ) 
	    {
	      newset->one[i] = false;
	      newset->two[i] = true;
	    }
	  else
	    {
	      newset->one[i] = true;
	      newset->two[i] = true;
	    }
	}

      SNP.push_back(newset);
    }
  
  for (int i=0;i<N;i++)
    {
      Individual * person = new Individual;
      person->fid = person->iid = "per"+int2str(i);
      person->missing = true;
      person->pat = "0";
      person->mat = "0";

      if ( CRandom::rand() > 0.5 ) 
	person->phenotype = 1;
      else
	person->phenotype = 2;

      person->sex = false;
      person->sexcode = "2";
      sample.push_back(person);      
    }

}


void Plink::alleleRecoding()
{
  
  vector<Locus*>::iterator loc = locus.begin();

  while( loc != locus.end() )
  {
  
    if ( par::recode_1234 )
	{
        if ( (*loc)->allele1 == "A" || (*loc)->allele1 == "a" )
             (*loc)->allele1 = "1";
        if ( (*loc)->allele1 == "C" || (*loc)->allele1 == "c" )
             (*loc)->allele1 = "2";
        if ( (*loc)->allele1 == "G" || (*loc)->allele1 == "g" )
             (*loc)->allele1 = "3";
        if ( (*loc)->allele1 == "T" || (*loc)->allele1 == "t" )
             (*loc)->allele1 = "4";

        if ( (*loc)->allele2 == "A" || (*loc)->allele1 == "a" )
             (*loc)->allele2 = "1";
        if ( (*loc)->allele2 == "C" || (*loc)->allele1 == "c" )
             (*loc)->allele2 = "2";
        if ( (*loc)->allele2 == "G" || (*loc)->allele1 == "g" )
             (*loc)->allele2 = "3";
        if ( (*loc)->allele2 == "T" || (*loc)->allele1 == "t" )
             (*loc)->allele2 = "4";

      }
     else if ( par::recode_ACGT )
      {
        if ( (*loc)->allele1 == "1" )
             (*loc)->allele1 = "A";
        if ( (*loc)->allele1 == "2" )
             (*loc)->allele1 = "C";
        if ( (*loc)->allele1 == "3" )
             (*loc)->allele1 = "G";
        if ( (*loc)->allele1 == "4" )
             (*loc)->allele1 = "T";

        if ( (*loc)->allele2 == "1" )
             (*loc)->allele2 = "A";
        if ( (*loc)->allele2 == "2" )
             (*loc)->allele2 = "C";
        if ( (*loc)->allele2 == "3" )
             (*loc)->allele2 = "G";
        if ( (*loc)->allele2 == "4" )
             (*loc)->allele2 = "T";
      }

    loc++;
  }

}

double chi2x2(table_t t)
{
  return chi2x2(t[0][0],t[0][1],t[1][0],t[1][1]);
}

double chi2x2(matrix_t t)
{
  return chi2x2(t[0][0],t[0][1],t[1][0],t[1][1]);
}

double chi2x2(double a, double b, double c, double d)
{
  double row1 = a + b;
  double row2 = c + d;
  double col1 = a + c;
  double col2 = b + d;

  if ( row1 * row2 * col1 * col2 == 0 ) 
    return 0;

  double total = col1 + col2;

  double E_a = ( row1 * col1 ) / total;
  double E_b = ( row1 * col2 ) / total;
  double E_c = ( row2 * col1 ) / total;
  double E_d = ( row2 * col2 ) / total;

  return ((a-E_a)*(a-E_a) ) / E_a +
    ((b-E_b)*(b-E_b))/E_b +
    ((c-E_c)*(c-E_c))/E_c +
    ((d-E_d)*(d-E_d))/E_d ;

}



string searchAndReplace(string str, 
			string searchString, 
			string replaceString)
{
  string::size_type pos = 0;
  while ( (pos = str.find(searchString, pos)) != string::npos ) 
    {
      str.replace( pos, searchString.size(), replaceString );
      pos++;
    }
  return str;
}
