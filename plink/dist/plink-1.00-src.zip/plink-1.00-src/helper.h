

//////////////////////////////////////////////////////////////////
//                                                              //
//           PLINK (c) 2005-2006 Shaun Purcell                  //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 2.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////



#ifndef __HELPER_H__
#define __HELPER_H__

#include <string>
#include <vector>
#include <cstdio>

#include "plink.h"

template<class T>
inline const T SQR(const T a) {return a*a;}
 
template<class T>
inline const T MAX(const T &a, const T &b)
        {return b > a ? (b) : (a);}
 
template<class T>
inline const T MIN(const T &a, const T &b)
        {return b < a ? (b) : (a);}
 
template<class T>
inline const T SIGN(const T &a, const T &b)
        {return b >= 0 ? (a >= 0 ? a : -a) : (a >= 0 ? -a : a);}
 
template<class T>
inline void SWAP(T &a, T &b)
        {T dum=a; a=b; b=dum;}


class Plink;
class Individual;
class CSNP;

using namespace std;

void sizeMatrix(matrix_t &, int,int);
void sizeTable(table_t & , int, int);
void multMatrix(matrix_t & a,
		matrix_t & b,
		matrix_t & c);


class Eigen
{
 public:
  void set(int n)
    {
      d.resize(n,0);
      sizeMatrix(z,n,n);
    }
  
  vector_t d; // eigenvalues
  matrix_t z; // eigenvectors
};


void NoMem();

vector<bool> nvec_bool();

class CArgs
{
 public:
  CArgs(int,char**);

  int count()
    { return n; }
  
  bool any()
    { return n > 1 ? true : false; }
  
  void fromScript(string);
  void fromPriorLog(string);
  bool find(string);
  string value(string);
  int value_int(string);
  double value_double(string);
    
  void check_unused_options(Plink &);

  vector<string> value(string,int);
  
  vector<string> a;
  
 private:
  int n;
  vector<bool> parsed;
};

vector<string> parse2str(string);
vector<int> parse2int(string);
string searchAndReplace(string,string,string);

template <class T>
bool from_string(T& t, 
		 const std::string& s, 
		 std::ios_base& (*f)(std::ios_base&));

void error(string);
void shutdown();
void checkDupes(Plink&);
bool readString(FILE *,string &);
bool realnum(double);

typedef vector<vector<double> > matrix_t;
typedef vector<double> vector_t;

void display(matrix_t &); 
void display(vector_t &); 
void display(vector<int> &); 

double genotypingRate(Plink &, int);
vector<string> listPossibleHaplotypes(Plink &, vector<int>);

int getInt(string,string);
double getDouble(string,string);

void permute(vector<long int>&);
void permute(vector<int>&);

vector<double> FDR_BH(vector<double>&);

void affCoding(Plink &);
void removeMissingPhenotypes(Plink & );

string genotype(Plink &, int i, int l);
string genotype(Plink & P, Individual *, int);
string genotypeToFile(Plink &, int i, int l);

long double factorial(int);

int getChromosomeCode(string);
int getMarkerChromosome(Plink &,string);
int getMarkerNumber(Plink &,string);
string leftWindowEdge(Plink & P, int bp, int chr);
string rightWindowEdge(Plink & P, int bp, int chr);
vector<int> getChromosomeMarkerRange(Plink &, int);
bool seeChromosome(Plink &,int);
vector<int> getChromosomeRange(Plink &);
vector<int> getWindowRange(Plink &P, int);

double SNPHWE(int obs_hets, int obs_hom1, int obs_hom2);

string int2str(int);
string dbl2str(double);

double normdist(double);
double ltqnorm(double);
std::string itoa(int, int);


void checkFileExists(string);
vector<string> tokenizeLine(ifstream&);

void defineDogChromosomes();
void defineCowChromosomes();
void defineHorseChromosomes();
void defineHumanChromosomes();

double chi2x2(double,double,double,double);
double chi2x2(table_t);
double chi2x2(matrix_t);
double chiprobP(double, double);
double inverse_chiprob(double, double); 
double gammp(double a, double x);
void gser(double *gamser, double a, double x, double *gln);
void gcf(double *gammcf, double a, double x, double *gln);
double gammln(double xx);

void lubksb(vector<vector<double> > &a, vector<int> &indx, vector<double> &b);
void ludcmp(vector<vector<double> > &a, vector<int> &indx, double &d);
vector< vector<double> > inverse(vector< vector<double> > & m );

vector<double> eigenvalues(vector<vector<double> > & a);
void tred2(vector<vector<double> >&,vector<double> &,vector<double> &);
void tqli(vector<double> &d, vector<double>&e, vector<vector<double> > &z);

Eigen eigenvectors(vector<vector<double> > & a);
void EV_tred2(vector<vector<double> >&,vector<double> &,vector<double> &);
void EV_tqli(vector<double> &d, vector<double>&e, vector<vector<double> > &z);

vector< vector<double> > svd_inverse(vector< vector<double> > & );
void svd(matrix_t &,vector_t &, matrix_t &);
void svdcmp(vector<vector<double> > &, 
	    vector<double> &, 
	    vector<vector<double> > &);
void svbksb(vector<vector<double> > &u,
	    vector<double> &w,
	    vector<vector<double> > &v,
	    vector<double> &b, 
	    vector<double> &x);
vector<vector<double> > msqrt(vector<vector<double> > & u);

double qromb(double func(const double), double a, double b);
void polint(vector_t &xa, vector_t &ya, const double x, double &y, double &dy);
double trapzd(double func(const double), const double a, const double b, const int n);

void svdvar(vector<vector<double> > & v,
	    vector<double> & w,
	    vector<vector<double> > & cvm);

vector<bool> vif_prune(vector<vector<double> > , double threshold);
void calcSetMeanVariance(vector<CSNP*> & pSNP,
			 vector<double> & mean,
			 vector<vector<double> > & variance,
			 vector<Individual*> & sample);

double pythag(const double a, const double b);

double betacf(const double a, const double b, const double x);
double betai(const double a, const double b, const double x);
double pF(const double F, const int df1, const int df2);
double pT(const double T, const double df);


#endif
