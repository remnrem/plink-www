


//////////////////////////////////////////////////////////////////
//                                                              //
//           PLINK (c) 2005-2006 Shaun Purcell                  //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 2.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////


#include "model.h"
#include "options.h"
#include "helper.h"
#include "phase.h"

#include <cmath>

Model::Model()
{    
  np = nind = 0;  
  haploid.resize(0);
  xchr.resize(0);
  sex_effect = false;
  all_valid = true;
  has_snps = true;
  testParameter = 1; // Permutation test parameter
  label.push_back("M"); // Intercept
  mAA = 0;
  mAB = 1;
  mBB = 2;
}

void Model::setDominant()
{
  mAA = 0;
  mAB = 1;
  mBB = 1;
}

void Model::setRecessive()
{
  mAA = 0;
  mAB = 0;
  mBB = 1;
}

void Model::addSexEffect()
{
  sex_effect = true;
}

void Model::hasSNPs(bool b)
{
  has_snps = b;
}

void Model::setMissing()
{
  
  // Fill in missing data with existing pattern 

  miss.clear();
  miss.resize(P->n,false);
  for (int i=0; i<P->n; i++)
    if ( P->sample[i]->missing ) miss[i] = true;
  
}

void Model::setMissing(vector<bool> & include)
{
  
  // Fill in missing data with existing pattern 
  if ( include.size() != P->n )
    error("A problem in setMissing()\n");

  miss.resize(P->n,false);
  for (int i=0; i<P->n; i++)
    if ( P->sample[i]->missing || ! include[i] ) miss[i] = true;
  
}


void Model::addAdditiveSNP(int a)
{

  if ( ! has_snps )
    error("Cannot add SNP to thie MODEL");

  additive.push_back(a);

  if ( par::chr_sex[P->locus[a]->chr] )
    xchr.push_back(true);
  else
    xchr.push_back(false);

  if ( par::chr_haploid[P->locus[a]->chr] )
    haploid.push_back(true);
  else
    haploid.push_back(false);

}

void Model::addDominanceSNP(int d)
{
  if ( ! has_snps )
    error("Cannot add SNP to thie MODEL");

  dominance.push_back(d);
}

void Model::addCovariate(int c)
{
  covariate.push_back(c);      
}

void Model::addHaplotypeDosage(set<int> & h)
{
  haplotype.push_back(h);
}

void Model::addInteraction(int a, int b)
{
  int2 i;
  i.p1 = a;
  i.p2 = b;
  interaction.push_back(i);
}

void Model::buildDesignMatrix()
{
  
  // Build X matrix (including intercept)
  // Iterate a person at a time, entering only 
  // valid rows into X (non-missing); also build Y
  // at the same time

  if ( has_snps && par::SNP_major )
    error("Internal error: must be individual-major to perform this...\n");

    
  ///////////////////////
  // Number of parameters
  
  // Standard variables
  // Note: 'additive' really means 'main effect' here, 
  //       i.e. which can also be coded recessive or dominant
  //       i.e. the distinction is between the 2df general model
  
  np = 1 
    + additive.size() 
    + dominance.size() 
    + haplotype.size()
    + covariate.size() 
    + interaction.size(); 
  
  // Sex effect?
  if ( sex_effect )
    np++;
  
  // QFAM variables
  //  if (par::QFAM_total) np++;
  //  else if (par::QFAM_between || par::QFAM_within1 || par::QFAM_within2) np +=2;
  
  if (par::QFAM_total
      || par::QFAM_between 
      || par::QFAM_within1 
      || par::QFAM_within2) 
    np++;

  
  ///////////////////////////
  // Consider each individual

  for (int i=0; i < P->n; i++)
    {
      
      Individual * person = P->sample[i];

      // Ignore if missing phenotype, or the user set this to missing
      if ( miss[i] ) continue;
    
      /////////////////////////////
      // 0) Intercept      
      // 1) Main effects of SNPs 
      // 2) Dominance effects of SNPs 
      // 3) Haplotypes
      // 4) Covariates
      // 5) Interactions of the above
      // 6) QFAM variables

      // Add intercept as first element
      vector_t trow(np);

      // Intercept
      trow[0] = 1;
      
      int c=1; 
      bool skip = false;

      // Additive effects (assuming individual-major mode)
      
      vector<int>::iterator s = additive.begin();
      int snp=0;
      while ( s != additive.end() )
	{

	  bool i1 = person->one[*s];
	  bool i2 = person->two[*s];
	  
	  if ( xchr[snp] )
	    {

	      /////////////////////////
	      // X chromosome coding
	      
	      double mA, mB;
	      if ( par::xchr_model == 1 )
		{
		  mA = 0.5; 
		  mB = 1.5;
		}
	      else if ( par::xchr_model == 2 )
		{
		  mA = 0;
		  mB = 2;
		}
	      else if ( par::xchr_model > 2 )
		{
		  mA = 0;
		  mB = 1;
		}
	      
	      
	      if ( person->sex ) // male
		{
		  if ( i1 ) 
		    {
		      if ( ! i2 ) 
			{
			  miss[i] = true;
			  skip = true;
			}
		      else
			trow[c++] = mA; 	      
		    }
		  else
		    {
		      if ( i2 )
			{
			  // This should not happen...
			  miss[i] = true;
			  skip = true;
			}		  
		      else
			trow[c++] = mB; 
		    }
		}
	      else // female x-chromosome
		{
		  if ( i1 ) 
		    {
		      if ( ! i2 ) 
			{
			  miss[i] = true;
			  skip = true;
			}
		      else
			trow[c++] = 0; 	      
		    }
		  else
		    {
		      if ( i2 )
			trow[c++] = 1; // het 
		      else
			trow[c++] = 2; // hom
		    }		  
		}
	      	      
	    }
	  else if ( haploid[snp] )
	    {

	      ///////////////////
	      // Haploid coding
	      
	      if ( i1 ) 
		{
		  if ( ! i2 ) 
		    {
		      miss[i] = true;
		      skip = true;
		    }
		  else
		    trow[c++] = 0; 	      
		}
	      else
		{
		  if ( i2 )
		    {
		      // This should not happen...
		      miss[i] = true;
                      skip = true;
		    }		  
		  else
		    trow[c++] = 1; 
		}
	      	    
	    }
	  else 
	    {

	      ///////////////////////
	      // Autosomal coding
	      
	      if ( i1 ) 
		{
		  if ( ! i2 ) 
		    {
		      miss[i] = true;
		      skip = true;
		    }
		  else
		    trow[c++] = mAA;
		}
	      else
		{
		  if ( i2 )
		    trow[c++] = mAB; // het 
		  else
		    trow[c++] = mBB; // hom
		}
	      
	    }
	  
	  s++;
	  snp++;
	}
      
      if (skip) continue;
      
      
      ////////////////////
      // Dominance effects
      
      s = dominance.begin();
      
      while ( s != dominance.end() )
	{
	  bool i1 = person->one[*s];
	  bool i2 = person->two[*s];
	  
	  if ( i1 ) 
	    {
	      if ( ! i2 ) 
		{
		  miss[i] = true;
		  skip = true;
		}
	      else
		trow[c++] = 0; 	      
	    }
	  else
	    {
	      if ( i2 )
		trow[c++] = 1; // het 
	      else
		trow[c++] = 0; // hom
	    }
	  
	  s++;
	}
      
      
      if (skip) continue;
      
      
      ////////////////////////////////////
      // Sex effect (automatically set for 
      // X chromosome models)
      
      if ( sex_effect ) 
	{
	  if ( P->sample[i]->sex )
	    trow[c++] = 1;
	  else 
	    trow[c++] = 0;
	}


      ////////////////////
      // Haplotype dosage
      
      for (int h=0; h<haplotype.size(); h++)
	trow[c++] = P->haplo->dosage(i,haplotype[h]);

      
      /////////////
      // Covariates
      
      for (int j=0; j<covariate.size(); j++)
	trow[c++] = P->sample[i]->clist[covariate[j]];
      

      ///////////////
      // Interactions
      
      for (int j=0; j<interaction.size(); j++)
	trow[c++] = trow[ interaction[j].p1 ] * trow[ interaction[j].p2 ];
     
      ///////////////
      // QFAM
      
//    if ( par::QFAM_total )
// 	trow[c++] = person->T;
//     else if ( par::QFAM_between || par::QFAM_within1 || par::QFAM_within2 ) 
// 	{
// 	  trow[c++] = person->family->B;
// 	  trow[c++] = person->W;
//	}

      if ( par::QFAM_total )
	trow[c++] = person->T;
      else if ( par::QFAM_between )
	trow[c++] = person->family->B;
      else if ( par::QFAM_within1 || par::QFAM_within2 ) 
	trow[c++] = person->W;
	
            
      ////////////////////////////
      // Add row to design matrix
      
      X.push_back(trow);
            
    }
      

  /////////////////////////////////////////////////
  // Set number of non-missing individuals

  nind = X.size();


  //////////////////////////////////
  // Apply a parameter list filter?
  
  if ( par::glm_user_parameters )
    {

      // Intercept always fixed in
      
      np = 1;
      vector<string> label2 = label;
      label.clear();
      label.push_back("M");
      int np2 = label2.size();
      
      for (int i=0; i< par::parameter_list.size(); i++)
	{
	  if ( par::parameter_list[i] >= 1 
	       && par::parameter_list[i] < np2 )
	    {
	      np++;
	      label.push_back(label2[ par::parameter_list[i] ]);
	    }
	}

     
      // For each individual

      for ( int i = 0 ; i < X.size() ; i++)
	{

	  vector_t X2(1);
	  
	  X2[0] = 1;
	  
	  for ( int j = 0 ; j < par::parameter_list.size() ; j++)
	    {
	    if ( par::parameter_list[j] >= 1 
		 && par::parameter_list[j] < np2 )
	      {
		X2.push_back(X[i][ par::parameter_list[j] ]);
	      }
	    }
	  X[i] = X2;
	}
    }


  /////////////////////////////////////////
  // VIF-based check for multicollinearity

  all_valid = checkVIF();


  ///////////////////////
  // Add Y variable also

  setDependent();

  // Now we are ready to perform the analysis

  if (par::verbose)
    {
      cout << "X design matrix\n";
      display(X);
      cout << "\n";
    }
      
}


vector<bool> Model::validParameters()
{  

  // Empty model?
  if (np==0 || nind==0) 
    {
      vector<bool> v(np,false);
      all_valid = false;
      return v;
    }
  

  // Display covariance matrix in verbose mode

  if ( par::verbose )
    {
      cout << "Covariance matrix of estimates\n";
      display(S);
      cout << "\n";
    }

  // Check for multicollinearity
  
  // For each term, see that estimate is not too strongly (r>0.99)
  // correlated with another, starting at last

  valid.resize(np);
  
  for (int i = 1; i<np; i++)
    {
      valid[i] = true;
      if ( S[i][i] < 1e-20 ) { valid[i] = all_valid = false; } 
      else if ( ! realnum(S[i][i]) ) { valid[i] = all_valid = false; }
    }

  if ( all_valid ) 
    for (int i = np-1; i>0; i--)
      {
	for (int j = i-1; j>=0; j--)
	  {	  
	    if ( S[i][j] / sqrt( S[i][i] * S[j][j] ) > 0.99999 )
	      {
		valid[i] = false;
		all_valid = false;
		break;
	      }
	  }
      }
  return valid;
}


double Model::getStatistic()
{
  if (all_valid)
    {
      return ( coef[testParameter] * coef[testParameter] ) 
	/ S[testParameter][testParameter];
    }
  else return 0;
}


// **********************************************
// *** Function to aid testing linear 
// *** hypotheses after estimating of a
// *** regression
// **********************************************

double Model::linearHypothesis(matrix_t & H, vector_t & h)
{
  
  // (H v - h)' (H S H')^-1 (H b - h) ~ X^2 with j df 
  // where H = constraint matrix (j x (p+1)
  //       h = null coefficient values
  //       S = estimated covariance matrix of coefficients

  //   return ( H*b - h ).transpose() 
  //     * ( H*v*H.transpose() ).inverse()
  //     * ( H*b - h ) ;
  
  int nc = h.size(); // # of constraints
  
  // 1. Calculate Hb-h  

  vector_t outer;
  outer.resize(nc,0);
  
  for (int r = 0; r < nc; r++)
    for (int c = 0; c < np; c++)
      outer[r] += H[r][c] * coef[c];
  
  for (int r = 0; r < nc; r++)
    outer[r] -= h[r];
  
  // 2. Calculate HVH'
  
  matrix_t tmp;
  sizeMatrix(tmp,nc,np);
  
  for (int r = 0; r < nc; r++)
    for (int c = 0; c < np; c++)
      for (int k = 0; k < np; k++)
	tmp[r][c] += H[r][k] * S[k][c];
  
  matrix_t inner;
  sizeMatrix(inner,nc,nc);
  
  for (int r = 0; r < nc; r++)
    for (int c = 0; c < nc; c++)
      for (int k = 0; k < np; k++)
	inner[r][c] += tmp[r][k] * H[c][k];

  inner = svd_inverse(inner);

  vector_t tmp2;
  tmp2.resize(nc,0);
  
  for (int c = 0; c < nc; c++)
    for (int k = 0; k < nc; k++)
      tmp2[c] += outer[k] * inner[k][c];

  double result = 0;
  
  for (int r = 0; r < nc; r++)
    result += tmp2[r] * outer[r];

  return result;
    
}


bool Model::checkVIF()
{

  // Calculate correlation matrix for X
  // Skip intercept

  int p = X.size();
  if (p<2) return false;

  int q = X[0].size() - 1; 	
  if ( q < 2 ) return true;

  vector_t m(q);
  matrix_t c;
  sizeMatrix(c,q,q);

  for (int i=0; i<p; i++)
    for (int j=0; j<q; j++)
      m[j] += X[i][j+1];

  for (int j=0; j<q; j++)
    m[j] /= (double)p;
  
  for (int i=0; i<p; i++)
    for (int j1=0; j1<q; j1++)
      for (int j2=j1; j2<q; j2++)
	c[j1][j2] += ( X[i][j1+1] - m[j1] ) * ( X[i][j2+1] - m[j2] );  
  
  for (int j1=0; j1<q; j1++)
    for (int j2=j1; j2<q; j2++)
      c[j1][j2] /= (double)(p-1);
  
  for (int j1=0; j1<q; j1++)
    for (int j2=j1+1; j2<q; j2++)
      {
	c[j1][j2] /= sqrt( c[j1][j1] * c[j2][j2] );
	c[j2][j1] = c[j1][j2];
	
 	if ( c[j2][j1] > 0.999 ) 
 	  {
	    if (par::verbose)
	      cout << "individual element > 0.999, skipping VIF\n";
	    return false;
	  }
      }		
  
  for (int j=0; j<q; j++)
    {
      if ( c[j][j] == 0 || ! realnum( c[j][j] ) )
	return false;
      c[j][j] = 1;
    }
  
  // Get inverse
  c = svd_inverse(c);
  
  if (par::verbose)
    {
      cout << "VIF on diagonals\n";
      display(c);
      cout << "\n";
    }

  // Calculate VIFs
  double maxVIF = 0;
  for (int j=0;j<q;j++)
    {
      
      // r^2 = 1 - 1/x where x is diagonal element of inverted
      // correlation matrix
      // As VIF = 1 / ( 1 - r^2 ) , implies VIF = x

      if ( c[j][j] > par::vif_threshold )
	return false;
    }
  
  
  return true;
  
}
