
//////////////////////////////////////////////////////////////////
//                                                              //
//           PLINK (c) 2005-2006 Shaun Purcell                  //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 2.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>

#include "plink.h"
#include "helper.h"
#include "options.h"
#include "perm.h"


void Plink::permTestRareDistribution(Perm & perm)
{

  printLOG("Testing for regions of rarer variants ( MAF < "
	   +dbl2str(par::rarer_maf_threshold)
	   +", within "
	   +int2str(int(par::rarer_dist_threshold/1000))
	   +" kb)\n");

  if ( par::SNP_major )
    SNP2Ind();
  


  ///////////////////////
  // Set up permutations

  perm.setTests(nl_all);
  perm.setPermClusters(*this);
  perm.originalOrder();

  ///////////////////////
  // Original

  vector_t original = testRareDistribution(perm, true);

  if (par::mperm_rank)
    perm.setOriginalRanking(original);

  //////////////////////
  // Begin permutations

  bool finished = false;
  while(!finished)
    {
      vector<double> pr(nl_all);
      perm.permuteInCluster();
      pr = testRareDistribution(perm,false);
      finished = perm.update(pr,original);
    } 
  
  if (!par::silent)
    cout << "\n\n";

  /////////////////////////////////////////////////////////////////////
  // Write results to file

  ofstream ASC;
  string f;

  if (par::adaptive_perm) f = par::output_file_name + ".rarer.perm";
  else f = par::output_file_name + ".rarer.mperm";

  ASC.open(f.c_str(),ios::out);
  ASC.precision(4);
  printLOG("Writing permutation association results to [ " + f + " ] \n");

  ASC << setw(4) << "CHR" << " "
      << setw(par::pp_maxsnp)<< "SNP" << " "
      << setw(12)<< "STAT" << " "
      << setw(12) << "EMP1" << " ";
  if (par::adaptive_perm)
    ASC << setw(12)<< "NP" << " ";
  else if ( par::mperm_rank )
    ASC << setw(12)<< "EMP3" << " "
        << setw(12)<< "RANK" << " ";
  else
    ASC << setw(12)<< "EMP2" << " ";
  ASC << "\n";
  
  
  for (int l=0; l<nl_all; l++)
    {
      
      // Skip?, if filtering p-values
      if ( par::pfilter && perm.pvalue(l) > par::pfvalue )
        continue;
      
      ASC << setw(4)  << locus[l]->chr << " "
          << setw(par::pp_maxsnp) << locus[l]->name << " ";
      
      ASC << setw(12) << original[l]  << " "
          << setw(12) << perm.pvalue(l) << " ";

      if (par::adaptive_perm)
        ASC << setw(12) << perm.reps_done(l) << " ";
      else if ( par::mperm_rank )
        ASC << setw(12) << perm.max_pvalue(l) << " "
            << setw(12) << perm.rank(l) << " ";
      else
        ASC << setw(12) << perm.max_pvalue(l) << " ";
      
      ASC << "\n";
  
    }
  
  ASC.close();

}



vector_t Plink::testRareDistribution(Perm & perm , bool display)
{
  
  /////////////////////////////////////////////////////////////////////
  // Write results to file

  ofstream OUT;
  
  if ( display )
    {
      string f = par::output_file_name + ".rarer";
      OUT.open(f.c_str(),ios::out);
      printLOG("Writing results to [ " + f + " ]\n");

      OUT << setw(4) << "CHR" << " "
	  << setw(par::pp_maxsnp) << "SNP" << " "
	  << setw(8) << "AFF" << " "
	  << setw(8) << "UNAFF" << " "
	  << setw(5) << "NSNP" << " " 
	  << setw(8) << "AFF2" << " "
	  << setw(8) << "UNAFF2" << " "
	  << setw(8) << "OR" << "\n";

    }

  vector<int> rcount_case(nl_all,0);
  vector<int> rcount_control(nl_all,0);
  
  iIndividual person = sample.begin();
  
  int tot_case = 0;
  int tot_control = 0;

  while ( person != sample.end() )
    {

      Individual * pperson = (*person)->pperson;
      
      if ( pperson->missing ) 
	continue;

      if ( pperson->aff ) 
	tot_case++;
      else
	tot_control++;
      
      //////////////////////////////////////////
      // Consider each SNP for this person
      
      for (int l=0; l<nl_all; l++)
	{
	  
	  //////////////////////////////////////////
	  // X-chromosome, haploid?
	  
	  if ( par::chr_sex[locus[l]->chr] ||
	       par::chr_haploid[locus[l]->chr] )
	    continue;
	  
	  //////////////////////////////////////////////
	  // Only consider alleles below a certain MAF
	  
	  if ( locus[l]->freq > par::rarer_maf_threshold )
	    continue;
	    

	  //////////////////////////////////////////
	  // Get and parse genotypes

	  bool one = (*person)->one[l];
	  bool two = (*person)->two[l];
	  
	  // Skip if missing

	  if ( one && !two )
	    continue;

	  if ( ! one ) 
	    {
	      if ( pperson->aff ) 
		rcount_case[l]++;
	      else
		rcount_control[l]++;
	    }

	  if ( ! two )
	  {
	    if ( pperson->aff ) 
	      rcount_case[l]++;
	    else
	      rcount_control[l]++;
	  }
	  
	} // Next SNP


      person++;


    } // Next Individual


  /////////////////////
  // Smooth over loci

  vector<double> r_case(nl_all);
  vector<double> r_control(nl_all);
  vector_t results(nl_all);
  vector_t oratio;
  vector<int> invlist;

  for (int l=0; l<nl_all; l++)  
    {
      
      double x1 = rcount_control[l];
      double x2 = rcount_case[l];
      double c1 = tot_control - x1;
      double c2 = tot_case - x2;

      int involved = 1;
      
      // pick this SNP, move forwards and backwards
      
      int l2 = l;
      while ( true ) 
	{
	  l2--;
	  if ( l2 < 0 ) break;
	  if ( locus[l2]->chr != locus[l]->chr ) break;
	  if ( locus[l]->bp - locus[l2]->bp > par::rarer_dist_threshold ) break;
	  x1 += rcount_control[l2];
	  x2 += rcount_case[l2];
	  c1 += tot_control - rcount_control[l2];
	  c2 += tot_case - rcount_case[l2];
	  involved++;
	}

      l2 = l;
      while ( true ) 
	{
	  l2++;
	  if ( l2 == nl_all ) break;
	  if ( locus[l2]->chr != locus[l]->chr ) break;
	  if ( locus[l2]->bp - locus[l]->bp > par::rarer_dist_threshold ) break;
	  x1 += rcount_control[l2];
	  x2 += rcount_case[l2];
	  c1 += tot_control - rcount_control[l2];
	  c2 += tot_case - rcount_case[l2];
	  involved++;
	}
      
      r_case[l] = x2;
      r_control[l] = x1;

      double ratio = ( x2*c1 ) / ( x1*c2 ) ;
      
      // Test statistic (1-sided) average chi-sq
      if ( ratio > 1 )
	results[l] = chi2x2(x2,x1,c2,c1) / (double)involved;
      else
	results[l] = 0;

      if ( display )
	{
	  oratio.push_back( ratio );
	  invlist.push_back( involved );
	}
    }



  if ( display )
    {
      
      for (int l=0; l<nl_all; l++)
	OUT << setw(4) << locus[l]->chr << " "
	    << setw(par::pp_maxsnp) << locus[l]->name << " "
	    << setw(8) << rcount_case[l] << " "
	    << setw(8) << rcount_control[l] << " "
	    << setw(4) << invlist[l] << " "
	    << setw(8) << r_case[l] << " "
	    << setw(8) << r_control[l] << " "
	    << setw(8) << oratio[l] << "\n";
      
      OUT.close();
    }
  
  
 
  return results;

}

