

//////////////////////////////////////////////////////////////////
//                                                              //
//           PLINK (c) 2005-2006 Shaun Purcell                  //
//                                                              //
// This file is distributed under the GNU General Public        //
// License, Version 2.  Please see the file COPYING for more    //
// details                                                      //
//                                                              //
//////////////////////////////////////////////////////////////////


#include <iostream>

#include "plink.h"
#include "helper.h"
#include "options.h"
#include "crandom.h"

using namespace std;

//////////////////////////////////////////////////////////////////////
// A simple routine to simulate a dataset of unlinked case/control SNPs

class SimParameters
{
public:
  int nsnp;
  double lfreq;
  double ufreq;
  double odds;
  double missing;
  string name;

  SimParameters()
  {
    name = "";
    nsnp = 0;
    missing = 0.01;
    lfreq = ufreq = odds = 0;
  }
};


vector_t instanceSNP(SimParameters & s)
{

  vector_t freqs(3);

  // Calculate actual population allele frequency for this SNP

  double freq = s.lfreq + CRandom::rand() * ( s.ufreq - s.lfreq ) ;

  // Get case and control allele frequencies given GRR, population frequency and disease frequency

  double f0, f1, f2;
  double g0 = freq * freq;
  double g1 = 2 * freq * ( 1-freq );
  double g2 = 1 - g0 - g1;

  f2 = par::simul_prevalence / ( g0 * s.odds * s.odds + g1 * s.odds + g2 );
  f0 = f2 * s.odds * s.odds;
  f1 = f2 * s.odds;

  // P(G|X)

  double d0 = g0 * f0;
  double d1 = g1 * f1;
  double d2 = g2 * f2;
  double dS = d0 + d1 + d2;
  d0 /= dS;
  d1 /= dS;
  d2 /= dS;

  double u0 = g0 * (1-f0);
  double u1 = g1 * (1-f1);
  double u2 = g2 * (1-f2);
  double uS = u0 + u1 + u2;
  u0 /= uS;
  u1 /= uS;
  u2 /= uS;

  freqs[0] = freq;
  freqs[1] = d0 + d1/2.0;
  freqs[2] = u0 + u1/2.0;

  return freqs;
}


void Plink::simulateSNPs()
{

  // Read in SNP parameters

  // Number of SNPs
  // Lower allele frequency for '1' (versus '2') allele
  // Upper allele frequency (population)
  // Odds ratio ('1' allele)

  checkFileExists(par::simul_file);
  printLOG("Reading simulation parameters from [ " + par::simul_file + " ]\n");

  printLOG("Writing SNP population frequencies to [ " + par::output_file_name + ".simfreq ]\n");
  
  ofstream SOUT( ( par::output_file_name+".simfreq").c_str(), ios::out);
  
  ifstream SIM;
  SIM.open( par::simul_file.c_str(), ios::in );
  
  vector<SimParameters> sp;

  while ( ! SIM.eof() )
    {
      SimParameters s;

      SIM >> s.nsnp
	  >> s.name
	  >> s.lfreq 
	  >> s.ufreq 
	  >> s.odds;
      
      if ( SIM.eof() )
	continue;

      sp.push_back(s);

    }

  SIM.close();

  // Make room for total number of SNPs, etc

  int tsnp = 0;
  
  for (int s=0; s<sp.size(); s++)
    tsnp += sp[s].nsnp;
  
  int nind = par::simul_ncases + par::simul_ncontrols;
      
  printLOG("Read " + int2str( sp.size() ) + " sets of SNPs, specifying " + int2str(tsnp) + " SNPs in total\n");
  printLOG("Simulating " + int2str( par::simul_ncases ) + " cases and " + int2str( par::simul_ncontrols ) + " controls\n");
  printLOG("Assuming a disease prevalence of " + dbl2str( par::simul_prevalence ) + "\n\n");

  int pos = 0;

  for (int s=0; s<sp.size(); s++)  
    for (int l=0;l<sp[s].nsnp;l++)
    {
      Locus * loc = new Locus;
      
      // Optionally add
      if ( sp[s].nsnp > 1 ) 
	loc->name = sp[s].name+"_"+int2str(l);
      else
	loc->name = sp[s].name;

      loc->chr = 1;
      loc->allele1 = "A";
      loc->allele2 = "B";
      loc->bp = ++pos; 
      loc->pos = 0;

      locus.push_back(loc);

      CSNP * newset = new CSNP;
      
      newset->one.resize(nind);
      newset->two.resize(nind);

      // Sample case and control population allele frequencies

      // Contains population, case, control frequencies

      vector_t f = instanceSNP(sp[s]);      
      
      SOUT << 1 << " "
	   << loc->name << "\t"
	   << f[0] << " " << f[0] << "\t" 
	   << sp[s].odds << "\n";

      for ( int i = 0 ; i < nind ; i++ ) 
	{

	  // Simple missingness

	  if ( CRandom::rand() < sp[s].missing ) 
	    {
		  newset->one[i] = true;
		  newset->two[i] = false;
	    }
	  else
	    {
	      
	      bool isCase = i < par::simul_ncases ? true : false;
	      
	      int g = 0;
	      if ( isCase ) 
		{
		  if (CRandom::rand() > f[1] )
		    g++;
		  if (CRandom::rand() > f[1] )
		    g++;
		}
	      else
		{
		  if (CRandom::rand() > f[2] )
		    g++;
		  if (CRandom::rand() > f[2] )
		    g++;
		}
	      
	      
	      if ( g == 0 ) 
		{
		  newset->one[i] = false;
		  newset->two[i] = false;
		}
	      else if ( g == 1 ) 
		{
		  newset->one[i] = false;
		  newset->two[i] = true;
		}
	      else
		{
		  newset->one[i] = true;
		  newset->two[i] = true;
		}
	      
	    }
	}
      
      SNP.push_back(newset);
    }
  
  
  // Phenotypes

  for (int i=0;i<nind;i++)
    {
      Individual * person = new Individual;
      person->fid = person->iid = "per"+int2str(i);
      person->missing = false;
      person->pat = "0";
      person->mat = "0";

      if ( i < par::simul_ncases ) 
	person->phenotype = 2;
      else
	person->phenotype = 1;

      person->sex = false;
      person->sexcode = "2";
      sample.push_back(person);      
    }
  
  SOUT.close();


}


