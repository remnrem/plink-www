package edu.harvard.mgh.purcell.gCLINE.data;

import java.awt.Component;
import java.awt.EventQueue;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import javax.swing.Icon;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;

import org.apache.log4j.Logger;

import edu.harvard.mgh.purcell.gCLINE.StartFrame;
import edu.harvard.mgh.purcell.gCLINE.general.ErrorManager;

/**
 * AutoUpadater extends Timer, automatically updating
 * the output files attached in OpView.
 * @author Kathe Todd-Brown
 *
 */
public class AutoUpdater extends Timer {
	/**
	 * A logger for this clas
	 */
	private Logger logger = Logger.getLogger(AutoUpdater.class);
	/**
	 * Window that this updater is attached to.
	 */
	private StartFrame frame;
	/**
	 * The file extention that this updater looks at to
	 * determine the exit status of the log.
	 */
	private String op_status_ext;
	/**
	 * Flags a completed operation
	 */
	public static String COMPLETE = "Complete";
	/**
	 * Flags a running operation
	 */
	public static String RUNNING = "Running";
	/**
	 * Flags a failed operation
	 */
	public static String ERROR = "Failed";
	
	/**
	 * A hash map that keeps all the operations and their current status
	 * completed, running, or failed.
	 */
	private HashMap<String, String> opStatis;
	
	/**
	 * This classes access to the general data
	 */
	private Record data;
	
	/**
	 * Error messages
	 */
	private ErrorManager errors;
	
	/**
	 * This runs every 5 seconds ideal but can be delayed if there isn't
	 * enough processor space.
	 * If the operation is still running then check for a .gplink file
	 * for the completion status. If a running operation is now completed
	 * get the current list of files in our project folder and compares
	 * them to the files listed as operations outputs. If there are files
	 * that are not in the output list but matches the operation root then
	 * it is added to the correct operation output.
	 */
	private TimerTask readLogs = new TimerTask(){
		@Override
		@SuppressWarnings("static-access")
		public void run() {
			logger.info("[readLogs] Entering...");
			
			//Error out if the operation status is null. This
			//...should never happen.
			if(opStatis == null){
				errors.createError("opStatis is null. Canceling the auto-updating", 
						"run@TimerTask@AutoUpdater.java");
				AutoUpdater.this.cancel();
				return;
			}
			Vector <String> allfiles = data.getHomeFiles();
			
			//download all log and gplink files
			if(data.isRemote()){
				//logger.info("(readLogs.run()) Starting to copy files.");
				int numFiles = allfiles.size();
				Vector <String> temp = new Vector <String>();
				for(int i = 0; i < numFiles; i ++){
					String file = allfiles.get(i);
					if(file.endsWith(data.OP_LOG_EXT)
							|| file.endsWith(op_status_ext)){
						if(!new File(data.getLocalFolder(), file).exists()){
							temp.add(data.getRemoteFolder() + file);
							logger.info("[run()@readLogs] [" +file + "] added to download queue.");
						}
					}
				}
				String [] filesToGet = new String[temp.size()];
				for(int i = 0; i < filesToGet.length; i ++){
					filesToGet[i] = temp.get(i);
				}
				
				//copy the file to the local project
				//Note that we are waiting to get all the files before
				//...moving on
				(frame.new Download(data, false, data.getLocalFolder(), 
						filesToGet)).run();
			}
			
			//The following for loop takes a while the first time around
			//...but most of the time you will be copying only 1 or 2 new
			//...operations at a time so it doesn't really take much more
			//...time.
			
			//Go through each operation and check the status
			for(OperationInfo op: data.getAllOp()){
				String s = op.getName();
				if(s != null && opStatis.get(s) == null){
					logger.info("[run()@readLogs] ["+ s + "] is being flagged as Running");
					opStatis.put(s, RUNNING);
				}
				//logger.info("[run()@readLogs] looking at the operation: [" +s + "] as " + opStatis.get(s));
				
				//Check that the operation is valid and is marked as running
				if(s != null && opStatis.get(s).equals(RUNNING)){
					logger.info("[run()@readLogs] [" +s + "] was running.");
					
					//the file that contanis the status of the operation
					File gplinkLog = new File(data.getLocalFolder(), s + op_status_ext);
					
					//if this file exist then the command/operation is done
					if(gplinkLog.exists()){
						//initalize the setting to fail
						String setting = "1";
						BufferedReader in;
						try {
							in = new BufferedReader(new FileReader(gplinkLog));
							setting = in.readLine();
							in.close();
						} catch (IOException e) {}
						
						for(String file: allfiles){
							if(file.startsWith(s + ".") )
								op.addFile(data.OUTFILE_KEY, file, "", "");
						}
						
						//0 is a sucessful completion
						if(setting != null && setting.equals("0")){
							opStatis.put(s, COMPLETE);
						} else {
							opStatis.put(s, ERROR);
						}
					} else{
						//the operation is still running
						opStatis.put(s, RUNNING);
						logger.info("[run()@readLogs] [" +s + "] is still running.");
					}
				}else {
					logger.info("[run()@readLogs] [" +s + "] is not flagged as running no files added.");
					
				}
			}
			if(frame != null && frame.folderViewer != null)
				EventQueue.invokeLater(frame.folderViewer.new UpdateJList(false));
			
			data.saveInfo();
			
			logger.info("[readLogs] ...Ending");

		}
		
		
	};
	
	/**
	 * runs the Timer's cancel and set the opStatis to null for
	 * garbage collection.
	 */
	@Override
	public void cancel(){
		super.cancel();
		opStatis = null;
	}
	
	public void addOp(String opName){
		opStatis.put(opName, RUNNING);
	}
	
	/**
	 * Create and start our unique timer. This will update the
	 * status of our operations on the operations viewer.
	 * @param d the current project
	 */
	@SuppressWarnings("static-access")
	public AutoUpdater(StartFrame f, Record d, 
			String givenExt, ErrorManager e,
			int sec) {
		super();
		
		logger.info("(AutoUpdater(Record, String, ErrorManager))Intailizing the update");
		
		op_status_ext = givenExt;
		///////////////////////////////////
		//*********Initalize***************
		///////////////////////////////////
		frame = f;
		data = d;
		errors = e;
		opStatis = new HashMap<String, String>();
		
		//go through all the operations in the project
		for (OperationInfo ops : data.getAllOp()) {
			opStatis.put(ops.getName(), RUNNING);
		}
		
		///////////////////////////////////////
		//***********set timer*****************
		////////////////////////////////////////
		readLogs.run();
		
		long interval = sec*1000;	//time in miliseconds, 5 seconds
		
		//run readLogs every 5 or 30 seconds but you can bump it since
		//...it's not critical if the processor is busy
		schedule(readLogs, 0, interval); 
		
	}

	/**
	 * Pull the operation name from the text in the operation
	 * node.
	 * @param s a string from the operaiton node in the form "name: discription"
	 * @return a string containing the name of the operaiton
	 */
	private String processOpName(String s){
		//the operation name and the discription are seperated by a :
		//...so split the string at the :
		s = s.split(":")[0];
		//if we have an html flag
		if(s.contains("<html>"))
			//cut it off
			s = s.substring(new String ("<html>").length(), s.length());
		//return the operation name
		return s;
	}
	

    
	/**
	 * Create a renderer to reflect that status of each operation 
	 * (completed, failed or running).
	 * @author Kathe Todd-Brown
	 *
	 */
	@SuppressWarnings("serial")
	public class MyRenderer extends DefaultTreeCellRenderer {
        Icon sucessIcon;
        Icon failIcon;
        Icon runningIcon;
        Icon fileInfoIcon;
        
        /**
         * Create a new renderer
         * @param sicon the icon that flags the sucess status
         * @param ficon the icon that flags the failed status
         * @param ricon the icon that flags the running status
         */
        public MyRenderer(Icon sicon, Icon ficon, Icon ricon,
        		Icon fileIcon) {
        	sucessIcon = sicon;
            failIcon = ficon;
            runningIcon = ricon;
            fileInfoIcon = fileIcon;
        }

       /**
        * Set the icon of each node.
        */
        public Component getTreeCellRendererComponent(  JTree tree, 
        		Object value, boolean sel, boolean expanded, boolean leaf, 
        		int row, boolean hasFocus) {

            super.getTreeCellRendererComponent( tree, value, sel, expanded,
            		leaf, row, hasFocus);
            
            if (isRunningOp(value)) {
            	setIcon(runningIcon);
            } else if (isCompleteOp(value)) {
            	 setIcon(sucessIcon);
            } else if (isFailedOp(value)) {
            	setIcon(failIcon);
            } else if(leaf == false 
            		&& isFile(value)){
            	setIcon(fileInfoIcon);
            }
            return this;
        }

        private boolean isFile(Object value){
        	return (value != null 
        			&& !value.toString().equals("Input files")
        			&& !value.toString().equals("Output files"));
        }
        
        private boolean isRunningOp(Object value) {
        	if(opStatis != null
        			&& opStatis.get(processOpName(value.toString())) != null
        			&& opStatis.get(processOpName(value.toString()))
        					.equals(AutoUpdater.RUNNING))
        		return true;
            return false;
        }
        
        protected boolean isCompleteOp(Object value) {
        	if(opStatis != null
        			&& opStatis.get(processOpName(value.toString())) != null
        			&& opStatis.get(processOpName(value.toString()))
        					.equals(AutoUpdater.COMPLETE))            
            	return true;
            return false;
        }
        
        protected boolean isFailedOp(Object value) {
        	if(opStatis != null
        			&& opStatis.get(processOpName(value.toString())) != null
        			&& opStatis.get(processOpName(value.toString()))
        					.equals(AutoUpdater.ERROR))           
            	return true;
            return false;
        }
    }
	
}
